
SDN-14-Financial-08-FinCen-09-Phang-Bessent

- https://rentry.co/sh8dzcwu

- 2026-11-01

- Senator Widen may be able to leverage the Secretary Bassent  / Patel Minnesota FinCEN major announcement

- going after money laundering terrorists AND money laundering traffickers

- 2010s - 20220s...

- just say'n

SDN-14-Financial-08-FinCen-01

- https://rentry.co/woiv3h2m

- 2026-10-30

- Bassent / Patel Minnesota FinCEN major announcement, going after money laundering terrorists, a series of SDN chapters 01 - 09.

SDN-14-Financial-08-FinCen-02-Banks

- https://rentry.co/bhfyp6ic

- 2026-10-30

SDN-14-Financial-08-FinCen-03-Epstein

- https://rentry.co/dy7tv96n

- 2026-10-31

SDN-14-Financial-08-FinCen-04-Loopholes

- https://rentry.co/imzym2zt

- 2026-10-30

SDN-14-Financial-08-FinCen-05-Lawsuits

- https://rentry.co/byz9tmod

- 2026-10-30

SDN-14-Financial-08-FinCen-06-Lake-Michagin-Yatchs

- https://rentry.co/p6foosvv

- 2026-10-31

SDN-14-Financial-08-FinCen-07-Interlochen-1967

- https://rentry.co/8ibrizgp

- 2026-10-31

SDN-14-Financial-08-FinCen-08-Interlochen-1994

- https://rentry.co/mv8ebmrv

- 2026-10-31

SDN-18-Miss-Teen-Pageants-02

- https://rentry.co/y6aq3oew

- 2026-10-27

Miss Switzerland Raped 1993

House Judiciary Committee

A new report released by Democrats on the House Judiciary Committee.

> ...plus corroboration from other people who were at the pageant.

...

Epstein and Trump and 11 Women

The report, titled "Epstein and Trump," compiles accounts from 11 women to allege links between Donald Trump and Jeffrey Epstein's sex trafficking network, demanding that the Department of Justice appoint an independent special counsel.

...

Report Summary

A former Miss Switzerland told House Democrats Trump raped her in 1993.

Now their report is demanding an independent special counsel.

...
