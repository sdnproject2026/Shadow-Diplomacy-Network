# Government Investigations

## Defense Contracting Conflicts

## Purpose

This article is designed to outline an investigative framework for examining defense contracting conflicts, federal procurement decisions, Department of Defense financing, and potential self-enrichment involving presidential family members, private investment entities, and federal awards.

## Synopsis

This article is designed as an investigative reference report detailing federal procurement integrity, Pentagon financing oversight, and congressional inquiries into defense industry investments. Its primary purpose is to systematically present specific target companies, financial metrics, investigative methods, and statutory accountability mechanisms.

## Introduction and Context

### Defense Contracting Conflicts

- Focuses on presidential conflicts, federal procurement integrity, and defense technology financing involving Donald Trump, Donald Trump Jr., Eric Trump, 1789 Capital, and American Ventures.

## Conceptual Framework

### Financial and Entity Overview

Examines reported figures including Approximately $3.2 Billion in federal awards and specific financial arrangements like the Vulcan Elements Reported $620 Million Pentagon Loan.

### Defense Technology Sectors

Details specific investment areas including artificial intelligence, drone and autonomous systems, military software, critical minerals, domestic manufacturing, and missile-defense technology.

## Investigative Authorities

Outlines roles for the Department of Defense Inspector General, Senate Oversight (Elizabeth Warren, Richard Blumenthal, Tammy Duckworth, Andy Kim), House Oversight Committee (Robert Garcia), and Senate Investigations and Oversight.

## Investigative Methods

Catalogs specific record requests (contract databases, underwriting files, ethics reviews) and potential legal violations including procurement fraud, false statements, false claims, and non-disclosure of beneficial ownership.

## Timeline

Maps critical oversight events spanning from January 2026 to November 2026, highlighting formal requests to the DoD IG and reporting by the Washington Post and Reuters.

## Investigative Questions

Formulates key evaluative questions regarding loan procedures, timing of investments versus awards, disclosure of conflicts, and differential treatment of competitors.

## Evidentiary Support

Cites primary congressional inquiry letters (Warren, Garcia, Blumenthal, Duckworth), investigative reporting (Washington Post, Reuters), and official institutional oversight portals (DoD IG, GAO, CRS).

## Conclusion and Synthesis

Synthesizes the investigative process by connecting private investment timelines directly to federal award dates, procurement scoring, inspector general audits, and administrative or legal remedies.

## Scope and Limitations

Notes explicit legal boundaries, emphasizing that presidential family members are not automatically subject to every federal conflict-of-interest statute applicable to executive-branch employees, and that inspectors general make administrative findings rather than independent criminal determinations.

## Summary

In short, this article explores and presents defense procurement conflicts by organizing investment entities, Pentagon financing data, oversight inquiries, and legal mechanisms into an accessible analytical framework for investigators and the reader.

## Defense Contracting Conflicts

Donald Trump Jr., Eric Trump, 1789 Capital, American Ventures, Defense Technology, Federal Awards, and Pentagon Financing

### Donald Trump

Presidential Conflicts and Federal Procurement

- Investigate whether presidential authority or administration relationships influenced federal awards to companies connected to Trump family investment interests.

- Examine whether the administration's procurement and financing decisions created actual or apparent conflicts of interest.

- Determine whether federal officials involved in procurement had financial, political, or personal relationships with investors or beneficiaries.

- Investigate whether presidential family members or affiliated investment firms received advance information concerning federal procurement opportunities.

- Examine whether political access was marketed to prospective investors as a commercial advantage.

- Determine whether government contracts, loans, grants, or subsidies were awarded through ordinary competitive procedures.

- Review whether procurement decisions were influenced by political relationships rather than documented national-security and performance requirements.

### Donald Trump Jr. and 1789 Capital

- Investigate investments made by 1789 Capital in companies receiving federal contracts.

- Examine whether political access was marketed to prospective investors.

- Review relationships between portfolio companies and federal procurement officials.

- Investigate potential conflicts involving defense technology, artificial intelligence, drones, and government financing.

- Determine whether companies received federal awards after investment or involvement by Trump-connected investors.

- Examine whether portfolio companies disclosed relevant financial and political relationships.

- Review whether investors were informed about the potential effects of presidential and administration relationships on company valuations.

- Investigate whether federal contracts were used to increase the value of private investment holdings.

### Eric Trump and American Ventures

- Investigate American Ventures and family investment activities.

- Examine investments in companies receiving federal awards or government financing.

- Review whether family investment structures created potential conflicts involving defense procurement.

- Examine relationships between company executives, federal officials, and procurement decision-makers.

- Investigate whether federal awards or loans were disclosed accurately to investors and the public.

## Persons of Interest

### - Donald Trump

- presidential authority and federal procurement decisions.

### - Donald Trump Jr.

- 1789 Capital and defense technology investments.

### - Eric Trump

- American Ventures and family investment activities.

### - Elizabeth Warren

- Pentagon procurement and financing inquiries.

### - Richard Blumenthal

- defense contracting and government ethics oversight.

### - Tammy Duckworth

- defense procurement oversight.

### - Andy Kim

- Pentagon contracting scrutiny.

### - Robert Garcia

- House Oversight investigations.

### - Stephen Feinberg

- Deputy Secretary of Defense, identified in the report in connection with Warren's July questioning.

- Department of Defense Inspector General.

- Government Accountability Office.

## Federal Awards

Approximately $3.2 Billion

- Examine the reported approximately $3.2 billion in federal awards involving companies linked to Trump sons.

- Obtain the complete list of companies and subsidiaries included in the reported figure.

- Identify each federal agency responsible for an award.

- Distinguish contracts, grants, loans, loan guarantees, and other forms of government assistance.

- Determine the dates, amounts, procurement procedures, and award criteria for each transaction.

- Identify the beneficial owners and investors of each recipient company.

- Establish whether Trump-family investment interests existed before or after the relevant award decisions.

- Determine whether federal officials disclosed or addressed potential conflicts.

- Examine whether award recipients received preferential treatment compared with competitors.

- Verify the reported total against primary federal procurement and financial records.

## Reported $620 Million Pentagon Loan

### Vulcan Elements

- Investigate the reported $620 million Department of Defense loan to Vulcan Elements.

- Identify the statutory and programmatic authority for the financing.

- Examine the loan application, underwriting, approval process, and disbursement schedule.

- Identify all investors, beneficial owners, and related investment interests.

- Examine whether Trump Jr.-linked investment relationships existed.

- Determine whether Pentagon officials involved in the loan had relevant political or financial relationships.

- Review whether the loan was awarded on terms consistent with comparable federal financing.

- Examine collateral, repayment obligations, default provisions, and taxpayer exposure.

- Determine whether the loan was structured to benefit a private investor or company beyond its stated national-security purpose.

### Defense Technology and Procurement

Investigate federal spending and investment relationships involving:

- Artificial intelligence.

- Drone and autonomous systems.

- Defense technology.

- Military software and data systems.

- Critical minerals and strategic materials.

- Domestic manufacturing and supply-chain projects.

- Missile-defense and related national-security technology.

- Companies receiving Department of Defense contracts, loans, or other federal support.

For each company:

- Identify investors and beneficial owners.

- Identify federal contracts and financing.

- Establish the timing of investment and government awards.

- Identify procurement officials and decision-makers.

- Examine competitive bidding and waiver records.

- Review contract modifications and follow-on awards.

- Examine whether political access was represented as an investment advantage.

- Determine whether conflicts were disclosed and addressed.

### Department of Defense Inspector General

- Investigate allegations of waste, fraud, abuse, and misconduct within the Department of Defense.

- Examine procurement and loan-award procedures.

- Obtain relevant government records and interview personnel within its authority.

- Identify deficiencies in internal controls.

- Recommend administrative corrective action.

- Refer evidence of potential criminal conduct to appropriate authorities.

- Distinguish administrative findings from criminal determinations; the Inspector General does not independently determine criminal guilt.

## Senate Oversight

### - Elizabeth Warren

- investigate procurement conflicts and Pentagon financing.

### - Richard Blumenthal

- participate in defense contracting and government ethics oversight.

### - Tammy Duckworth

- participate in defense procurement oversight.

### - Andy Kim

- participate in scrutiny of Pentagon contracts and loans.

## House Oversight

### - Robert Garcia

- investigate federal contracts benefiting Trump-connected companies.

- Examine corporate relationships and presidential family financial interests.

- Obtain records of federal awards and administration communications.

- Investigate potential use of presidential authority to benefit private businesses.

## Senate Investigations

- Examine foreign sovereign wealth investments involving Trump family associates.

- Investigate federal procurement and defense industry conflicts.

- Review government subsidies and regulatory concessions benefiting major political donors.

- Examine political fundraising arrangements involving federal contractors.

## Investigative Methods

- Department of Defense contract-award records.

- Federal Procurement Data System and related procurement databases.

- Loan applications, underwriting files, approval memoranda, and disbursement records.

- Company ownership records and beneficial-ownership disclosures.

- Investment agreements, fund disclosures, and portfolio-company records.

- Communications among investors, procurement officials, political appointees, and Pentagon leadership.

- Conflict-of-interest disclosures and ethics reviews.

- Procurement scoring, bid evaluations, sole-source justifications, and contract modifications.

- Inspector General interviews and investigative findings.

- GAO reviews of procurement and federal financing.

- Comparison of award recipients with similarly situated competitors.

## Legal and Accountability Issues

- Procurement fraud, if supported by evidence and applicable statutory elements.

- False statements in federal contracting or loan applications.

- False claims involving federal funds.

- Conflicts of interest involving government officials subject to applicable ethics laws.

- Improper use of federal resources.

- Fraudulent investor representations.

- Concealment of beneficial ownership or material financial relationships.

- Congressional obstruction or contempt where lawful subpoenas are defied.

Presidential family members are not automatically subject to every federal conflict-of-interest statute applicable to ordinary executive-branch employees. Investigators must identify the particular legal duty, transaction, official action, and evidence before alleging a violation.

## Timeline

### 2026-01

- Elizabeth Warren, Richard Blumenthal, and Andy Kim raise concerns about Pentagon contracts and loans benefiting companies connected to Donald Trump Jr.

- Warren requests information concerning conflicts of interest in Department of Defense procurement.

### 2026-03

- Warren and Blumenthal question the Department of Defense's response concerning Trump Jr.-linked companies.

### 2026-05

- Robert Garcia requests a Pentagon Inspector General investigation into possible conflicts involving Trump family-connected defense investments.

### 2026-06

- Warren raises concerns about the reported $620 million Pentagon loan to Vulcan Elements.

- Warren presses the Department of Defense concerning potential conflicts in defense financing.

### 2026-07

- Warren questions Deputy Defense Secretary Stephen Feinberg concerning defense contracts and potential conflicts.

- Washington Post reporting details investments by Trump sons in defense technology companies and resulting government business.

### 2026-08-05

- Warren, Garcia, Blumenthal, and Duckworth formally request a Department of Defense Inspector General investigation into approximately $3.2 billion in federal awards involving companies linked to Trump sons.

### 2026-09-28

- Reuters reports that congressional Democrats are preparing investigations into Trump family business dealings if they gain control of either chamber.

- Potential subjects include 1789 Capital, defense contracts, corporate donors, cryptocurrency, and Affinity Partners.

### 2026-11-04

- Federal contracting and defense-industry conflicts remain identified congressional investigative priorities in the supplied report.

## Investigative Questions

1. Which companies are included in the reported $3.2 billion in federal awards?

2. How much of the reported amount represents contracts, loans, grants, or guarantees?

3. What direct or indirect financial interests do Trump family members hold in the recipient companies?

4. Did investments precede government awards?

5. Were political relationships marketed to investors?

6. Were procurement officials aware of relevant family investment relationships?

7. Was the Vulcan Elements loan awarded through ordinary procedures?

8. Were comparable companies treated differently?

9. Did any officials disclose or recuse themselves from decisions involving potential conflicts?

10. What did the Pentagon Inspector General determine, and what records remain outstanding?

### Sources

- Warren, Garcia, Blumenthal, Duckworth - August 5, 2026 Pentagon investigation request

  https://www.warren.senate.gov/newsroom/press-releases/warren-garcia-blumenthal-duckworth-urge-dod-watchdog-to-investigate-3-2-billion-in-government-awards-to-companies-tied-to-trump-sons/

- House Oversight Democrats - Pentagon investigation request

  https://oversightdemocrats.house.gov/news/press-releases/ranking-member-robert-garcia-senator-elizabeth-warren-senator-richard-blumenthal-and-senator-tammy-duckworth-urge-dod-watchdog-to-investigate-32-billion-in-government-awards-to-companies-tied-to-trump-sons

- Warren - January 23, 2026 defense contracting inquiry

  https://www.warren.senate.gov/newsroom/press-releases/warren-blumenthal-kim-sound-alarm-on-potential-for-donald-trump-jr-linked-companies-to-profit-off-department-of-defense-contract-awards-loans/

- Reuters - September 28, 2026, planned congressional investigations

  https://www.reuters.com/legal/government/democrats-probe-lucrative-trump-family-business-deals-if-they-win-midterms-2026-09-28/

- Washington Post - July 13, 2026, defense investments involving Trump's sons

  https://www.washingtonpost.com/technology/interactive/2026/07/13/trumps-sons-invest-heavily-defense-fathers-administration-pours-money/

- Department of Defense Inspector General

  https://www.dodig.mil/

- US Government Accountability Office

  https://www.gao.gov/

- Congressional Research Service

  https://crsreports.congress.gov/

 

----

----

