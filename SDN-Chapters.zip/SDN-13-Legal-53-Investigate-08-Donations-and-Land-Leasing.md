# Government Investigations

## Donations and Land Leasing

SoftBank, Masayoshi Son, the $50 Million Donation, Federal Land Lease, and Potential Government Favoritism

# Purpose

This article is designed to outline an investigative framework for examining potential government favoritism, conflicts of interest, and quid pro quo arrangements involving corporate donations to presidential projects and subsequent federal land leasing decisions.

# Synopsis

This article is designed as an investigative reference report focusing on presidential library fundraising, federal property management, and ethics oversight. Its primary purpose is to systematically present the connections between corporate financial contributions, executive branch decision-making, congressional inquiries, and constitutional safeguards.

## Introduction and Context

Focuses on presidential library fundraising, federal land leases, data-center developments, and potential government favoritism involving Donald Trump, SoftBank, and Masayoshi Son.

## Conceptual Framework

### Transaction Breakdown

- Details the specific $50 Million Donation to Trump's presidential library fund alongside the March 2026 Federal Land Lease and Data-Center Arrangement.

### Constitutional and Ethical Framework

- Analyzes potential conflicts, the Foreign Emoluments Clause, foreign state funding rules, and federal leasing standards.

## Congressional Oversight

Highlights investigative roles for Elizabeth Warren, Richard Blumenthal, Melanie Stansbury, the House Oversight Committee, and Senate Investigations and Oversight.

## Investigative Methods and Records

Catalogs essential record types, including library fund transfer logs, corporate records, property appraisals, environmental reviews, and White House visitor logs.

## Timeline

Maps key events from January 2026 (donation) to March 2026 (lease announcement) and August/September 2026 (congressional releases and reporting), profiling figures like Donald Trump, Masayoshi Son, Elizabeth Warren, and agency inspectors general.

## Investigative Questions

Formulates key evaluative questions regarding the timing of communications, competitive bidding, fair market value, special waivers, and foreign entity involvement.

## Evidentiary Support

Cites primary press releases from Senator Elizabeth Warren, investigative reporting (Reuters, Washington Post, Associated Press), and federal oversight portals (GAO, CRS, agency IGs).

## Conclusion and Synthesis

Synthesizes the analysis by establishing a methodology to determine whether corporate library contributions and federal property transactions were independent events or evidence of improper influence.

## Scope and Limitations

Distinguishes private corporate contributions from benefits provided directly by foreign governments, noting that investigators must verify the precise source and nature of any funding before asserting that constitutional restrictions apply.

## Summary

In short, this article explores and presents the investigation into presidential library donations and federal land leases by structuring the timeline, corporate relationships, oversight tools, and legal standards into an accessible analytical guide.

## Donations and Land Leasing

### Donald Trump

Presidential Library Fundraising

- Investigate SoftBank's reported $50 million donation to Trump's presidential library fund.

- Establish the date the donation was solicited, committed, transferred, and accepted.

- Identify the donor entity, source of funds, intermediaries, and any conditions attached to the contribution.

- Examine communications between SoftBank, Masayoshi Son, presidential representatives, and federal officials.

- Investigate whether the donation was discussed in connection with federal land leasing, data-center development, or other government decisions.

- Determine whether any presidential or administration official promised, implied, or provided preferential access or treatment.

- Examine whether the donation was disclosed accurately and whether applicable reporting and governance requirements were followed.

- Investigate whether other corporate donations to presidential projects coincided with federal procurement, leasing, licensing, or regulatory decisions.

### SoftBank and Masayoshi Son

- Examine SoftBank's reported $50 million contribution to Trump's presidential library fund.

- Establish the corporate entity responsible for the contribution.

- Identify the source of funds and the individuals who approved the donation.

- Review communications between Masayoshi Son and administration officials.

- Examine the timing of the donation relative to the subsequent federal land lease arrangement.

- Investigate whether SoftBank or affiliated entities received preferential treatment in federal leasing or permitting.

- Review whether the company received access to decision-makers unavailable to other applicants.

- Examine whether the federal land arrangement was evaluated through ordinary procedures and at independently supportable terms.

### Federal Land Lease and Data-Center Arrangement

- Investigate the federal land lease arrangement announced in March 2026.

- Identify the federal agency responsible for the property and lease.

- Establish the location, size, duration, terms, and intended use of the leased property.

- Determine whether the lease involved a data-center project or associated infrastructure.

- Obtain the solicitation, application, appraisal, environmental review, approval, and lease documents.

- Determine whether competing applicants were considered.

- Examine whether the federal government received fair market value.

- Review whether the arrangement included special terms, waivers, subsidies, infrastructure support, or other concessions.

- Identify all companies and subsidiaries involved.

- Examine whether federal officials responsible for the lease had communications with SoftBank or presidential representatives.

- Determine whether the donation and lease were independent transactions or whether evidence connects them.

## Conflicts and Constitutional Questions

- Examine whether the donation constituted a private contribution to a presidential project or a benefit connected to the federal government.

- Determine whether any foreign-government ownership or control was involved in the source of the contribution.

- Examine whether the Foreign Emoluments Clause is implicated by any benefit traceable to a foreign state.

- Distinguish a private corporate contribution from a benefit provided by a foreign government.

- Identify the source and nature of any alleged benefit before asserting that a constitutional restriction applies.

- Examine whether presidential authority was used to benefit a private donor.

- Review applicable federal ethics, disclosure, procurement, leasing, and anti-corruption requirements.

## Congressional Oversight

### Elizabeth Warren

- Investigate the SoftBank donation and subsequent federal land lease.

- Examine the relationship between corporate contributions and federal government decisions.

- Obtain records from relevant agencies and corporate entities.

### Richard Blumenthal

- Participate in congressional scrutiny of the SoftBank arrangement.

- Examine possible government ethics and oversight issues.

### Melanie Stansbury

- Participate in congressional scrutiny of the donation and land lease.

- Examine the timing and government decision-making surrounding the arrangement.

## House Oversight

- Investigate corporate donations to presidential projects.

- Examine federal land leasing and potential presidential self-enrichment.

- Investigate the use of presidential authority to benefit private businesses.

## Senate Investigations

- Examine corporate fundraising arrangements involving federal contractors and major donors.

- Review whether government subsidies, leases, and regulatory concessions benefited political contributors.

## Investigative Methods

- Presidential library fund contribution records.

- Donation commitments, transfer records, and donor disclosures.

- SoftBank corporate records and relevant subsidiary records.

- Communications between SoftBank executives and government officials.

- Federal land ownership and leasing records.

- Property appraisals and market-value assessments.

- Lease applications, solicitations, evaluations, and approval memoranda.

- Environmental and infrastructure reviews.

- Records of competing applicants or alternative proposals.

- Meeting calendars and visitor logs.

- Communications among the White House, federal agencies, and donor representatives.

- Inspector General and GAO reviews, where applicable.

## Timeline

### 2026-01

- SoftBank makes a reported $50 million donation to Trump's presidential library fund.

- Warren, Blumenthal, and Andy Kim raise concerns about Pentagon contracts and loans benefiting Trump Jr.-connected companies.

### 2026-03

- SoftBank-related federal land lease arrangement announced.

- Warren and Blumenthal question the Department of Defense's response concerning Trump Jr.-linked companies.

### 2026-08-06

- Warren, Blumenthal, and Stansbury release information concerning SoftBank's $50 million presidential library donation and subsequent federal land lease announcement.

### 2026-09-28

- Reuters reports that contemplated congressional investigations may include corporate donors, family business arrangements, and federal contracting.

## Persons of Interest

### - Donald Trump

- presidential library fundraising and federal land-lease decision-making.

### - Masayoshi Son

- SoftBank founder and executive.

### - SoftBank

- reported donor and entity connected to the subsequent land lease.

### - Elizabeth Warren

- congressional scrutiny of the donation and federal arrangement.

### - Richard Blumenthal

- congressional scrutiny and government ethics oversight.

### - Melanie Stansbury

- congressional scrutiny of the SoftBank arrangement.

- Relevant federal land-management and leasing agencies.

- Government Accountability Office.

- Relevant inspectors general.

## Investigative Questions

1. When was the $50 million donation first discussed and formally committed?

2. Who solicited and accepted the contribution?

3. Which SoftBank entity supplied the funds?

4. When did discussions about the federal land lease begin?

5. Were the donation and lease discussed in the same communications?

6. Did the donor receive preferential access or treatment?

7. Was the lease competitively evaluated?

8. Was the lease price consistent with fair market value?

9. Were special concessions, waivers, or federal subsidies provided?

10. Did any foreign-government ownership or control affect the constitutional analysis?

11. Did federal officials follow applicable ethics and leasing requirements?

12. What evidence supports a connection between the donation and the government decision, if any?

## Sources

- Warren - SoftBank presidential library donation

  https://www.warren.senate.gov/newsroom/press-releases/softbank-confirms-50-million-donation-to-trump-library-just-two-months-before-trumps-announcement-of-a-lease-for-companys-data-center/

- Reuters - September 28, 2026, planned congressional investigations

  https://www.reuters.com/legal/government/democrats-probe-lucrative-trump-family-business-deals-if-they-win-midterms-2026-09-28/

- Washington Post - September 12, 2026, planned House investigations

  https://www.washingtonpost.com/politics/2026/09/12/house-democrats-plan-sweeping-trump-investigations-if-they-win-november/

- Associated Press - September 27, 2026, contemplated House oversight investigations

  https://www.washingtonpost.com/politics/2026/09/26/house-democrats-trump-impeachment-investigations-corruption-jeffries/91050294-b9a3-11f1-94cb-d3d8f22a8c8b_story.html

- Congressional Research Service

  https://crsreports.congress.gov/

- US Government Accountability Office

  https://www.gao.gov/

- Federal agency responsible for the relevant land lease

- Relevant federal agency Inspector General

----

----

