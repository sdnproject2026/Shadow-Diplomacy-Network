# MC2 Tel Aviv

The 1988 60 Minutes Expose

## Corporate Biography

