# Government Investigations

## Military Operations

### Purpose

- This article is designed to outline an investigative framework examining presidential authority, military accountability, legal mechanisms, and international law violations surrounding lethal military strikes against suspected drug-trafficking vessels.

### Synopsis

- This article is designed for an audience seeking a detailed legal and legislative oversight framework regarding US military operations targeting suspected maritime narcotics traffickers.

- Its primary purpose is to establish investigative priorities, evaluate executive and DOD authorization, assess compliance with international law, and detail oversight mechanisms for lethal strikes conducted under _Operation Southern Spear_.

### Introduction and Context

- This article opens with a look at extrajudicial killings and presidential authorization of lethal maritime strikes in the Caribbean and eastern Pacific.

### Main Arguments and Analysis

This article outlines specific operational, command, and geopolitical investigative tracks:

- Donald Trump - Presidential Authorization - investigating the legal basis for treating suspected traffickers as enemy combatants, the absence of judicial due process, intelligence reliability, survivor-targeting incidents, territorial sovereignty violations, and potential executive misrepresentations.

- _Operation Southern Spear_ / Joint Task Force - Western Hemisphere - focusing on the campaign initiated on September 2, 2025, detailing vessel destruction, casualty verification, classified DOJ legal justifications, and executive displacement of congressional war powers.

- Pete Hegseth - Secretary of Defense - examining DOD targeting protocols, compliance with rules of engagement, handling of internal military legal objections, Pentagon Inspector General inquiries, and potential command or individual criminal liability.

- International Investigations - detailing jurisdictional implications for affected nations - including Venezuela, Colombia, Trinidad and Tobago, and other Caribbean states - concerning sovereignty violations, flag-state consent, and non-judicial killings of foreign nationals.

### Conceptual Framework

The article organizes the oversight infrastructure, legal standards, and empirical data governing the inquiry - Congressional Oversight - Maritime Strikes - delineating committee mandates across House and Senate Armed Services, Judiciary, Oversight, and Intelligence committees.

## Timeline

Establishes key operational milestones from September 2, 2025, through strike renewals, casualty escalation reports, and oversight opportunities including late 2026.

## Legal Mechanisms

Categorizes mechanisms for evidence gathering, subpoena enforcement, DOD Inspector General audits, DOJ referrals, and UN/international human rights inquiries.

## International Legal Framework

Cites governing treaties and statutes, including UN Charter Articles 2(4) and 51, the Geneva Conventions, ICCPR right-to-life protections, and UNCLOS.

## Predicate Offenses

Enumerates potential domestic statutory and international law violations, ranging from unlawful killings and conspiracy to obstruction of justice and maritime sovereignty breaches.

## Evidentiary Support

This article cites independent reporting and official legal assessments to substantiate casualty and strike figures, referencing data from Human Rights Watch, USNI News, Associated Press, ABC News, Just Security, the Department of Defense Inspector General, Congressional Research Service, and United Nations Special Rapporteurs.

## Scope and Limitations

The article defines its evidentiary boundaries under the Investigative Standard, requiring each strike to be analyzed individually regarding target identity, geographic jurisdiction, available alternatives, and legal compliance rather than relying on generalized assumptions.

## Summary

In short, this article explores and presents the parameters of executive and military accountability for maritime strikes by organizing key operational details, international legal frameworks, oversight bodies, and specific investigative questions.

## Extrajudicial Killings

Presidential Authorization of Lethal Maritime Strikes

### Donald Trump - Presidential Authorization

- Investigate presidential authorization of lethal military strikes against suspected drug-trafficking vessels in the Caribbean and eastern Pacific.

- Examine the legal basis for treating suspected drug traffickers as enemy combatants.

- Determine whether the administration established a legally sufficient armed-conflict framework.

- Investigate the absence of conventional arrest, interdiction, prosecution, and judicial review before lethal force was used.

- Examine intelligence standards for identifying vessels, occupants, cargo, and alleged cartel affiliations.

- Investigate whether individuals were killed without evidence establishing an imminent threat to life.

- Examine incidents involving survivors, including whether follow-up strikes were ordered against individuals who no longer presented a threat.

- Investigate whether military operations occurred within sovereign territorial waters without authorization.

- Examine presidential briefings, DOJ legal opinions, military orders, intelligence assessments, and congressional notifications.

- Investigate whether the administration misrepresented the number of operations, deaths, identities of victims, or evidence of narcotics aboard targeted vessels.

### _Operation Southern Spear_

Joint Task Force - Western Hemisphere

- Investigate the campaign beginning September 2, 2025.

- Establish a complete list of vessels targeted, destroyed, or disabled.

- Establish the identities and nationalities of everyone killed, injured, rescued, or missing.

- Obtain strike footage, surveillance data, intelligence assessments, target-selection documents, and after-action reports.

- Determine which vessels were actually carrying narcotics and which were classified as suspected traffickers without publicly disclosed corroboration.

- Investigate the use of military rather than Coast Guard interdiction and ordinary criminal prosecution.

- Examine the classified DOJ memorandum reportedly used to justify the strikes.

- Investigate whether the executive branch's interpretation of presidential war powers improperly displaced congressional authority.

- Compare official vessel counts and casualty figures against independent investigations.

- Examine whether the administration accurately disclosed the number of strikes, fatalities, survivors, and damaged or destroyed vessels.

### Pete Hegseth - Secretary of Defense

- Investigate targeting and authorization procedures governing lethal maritime strikes.

- Examine military compliance with rules of engagement and international humanitarian law.

- Investigate whether military personnel received lawful orders.

- Review whether legal objections by military lawyers were ignored or overridden.

- Investigate the handling of survivor-targeting incidents.

- Examine reporting obligations to Congress and the accuracy of public statements.

- Review Pentagon Inspector General investigations and recommendations.

- Determine whether command responsibility or individual criminal liability is implicated by specific documented conduct.

## Congressional Oversight

Maritime Strikes

### House Armed Services Committee

- Investigate operational authorization and command responsibility.

- Examine targeting procedures, intelligence reliability, and military orders.

### House Judiciary Committee

- Examine the legal basis for lethal force.

- Investigate possible criminal violations and constitutional issues.

### House Oversight Committee

- Subpoena operational records, casualty data, executive-branch communications, and legal memoranda.

### Senate Armed Services Committee

- Examine military compliance, command accountability, and operational procedures.

### Senate Judiciary Committee

- Examine constitutional and statutory authority.

- Investigate due-process implications and potential unlawful killings.

### Intelligence Committees

- Examine intelligence reliability.

- Investigate target-identification standards.

- Review classified intelligence assessments and potential misrepresentations.

## International Investigations

### Venezuela and Caribbean States

- Investigate US military strikes affecting Venezuelan territorial interests.

- Establish the precise geographic location of every strike.

- Determine whether operations occurred in international waters, territorial seas, or another state's exclusive jurisdiction.

- Identify the flag state of each targeted vessel.

- Investigate whether flag states provided consent for boarding, interdiction, or other enforcement action.

- Examine whether coastal states were notified or consulted.

- Investigate whether foreign nationals were killed without judicial process.

### Colombia

- Examine any alleged involvement of Colombian nationals in maritime strikes.

- Investigate potential violations of Colombian sovereignty or the rights of Colombian citizens.

### Trinidad and Tobago and Caribbean States

- Examine maritime operations in or near territorial waters.

- Investigate whether governments were notified or consented to US operations.

- Review regional maritime-security implications.

## Timeline

### 2025-09-02

 - Trump administration begins military strikes against alleged drug-trafficking vessels.

### 2025-11-19

 - Epstein Files Transparency Act signed; separate congressional oversight opportunities continue.

### 2026-08

 - US military resumes strikes against suspected drug vessels; reported deaths exceed 220.

### 2026-09-02

 - Human Rights Watch reports at least 227 people killed in 69 maritime strikes.

### 2026-09-21

 - USNI reports 70 maritime strikes and 234 people killed.

### 2026-11-04

 - Further congressional oversight opportunities concerning lethal maritime operations.

## Legal Mechanisms

### Congressional Oversight

- Issue subpoenas for military orders and operational records.

- Conduct hearings involving military commanders and intelligence officials.

- Obtain casualty and target-identification records.

- Examine classified legal opinions.

- Pursue contempt proceedings for failure to comply with lawful subpoenas.

- Refer potential criminal conduct to DOJ.

### Department of Defense Inspector General

- Investigate military targeting procedures.

- Examine compliance with rules of engagement.

- Investigate casualty reporting.

- Examine procurement and operational expenditures.

- Review possible concealment of information.

- Refer potential criminal conduct to appropriate authorities.

### Department of Justice

Investigate where supported by evidence:

- Unlawful killings.

- Conspiracy.

- Obstruction of justice.

- False statements.

- Destruction of evidence.

- Violations of applicable federal civil-rights statutes.

- Aiding and abetting.

### International Investigations

- UN Human Rights Council.

- UN Special Rapporteurs on extrajudicial killings.

- Foreign national prosecutors.

- International human-rights commissions.

- Interpol cooperation where appropriate.

### International Legal Framework

- UN Charter Article 2(4): prohibition on the threat or use of force against the territorial integrity or political independence of another state.

- UN Charter Article 51: individual and collective self-defense, subject to applicable requirements.

- Geneva Conventions: protections applicable during armed conflict.

- International Covenant on Civil and Political Rights: protections including the right to life.

- UN Convention on the Law of the Sea: maritime jurisdiction and navigational rights.

- Convention Against Torture: prohibition on torture and related obligations.

## Predicate Offenses

- Unlawful killings, where applicable federal jurisdiction and statutory elements exist.

- Conspiracy.

- Obstruction of justice.

- Destruction or concealment of evidence.

- False statements.

- Witness intimidation.

- Violations of applicable international humanitarian law.

- Potential violations of maritime sovereignty.

- Potential violations of the right to life.

## Questions for Investigators

1. How many vessels were actually destroyed, disabled, or targeted?

2. How many people were killed, injured, rescued, or remain missing?

3. What percentage of targeted vessels were independently verified to contain narcotics?

4. What evidence supported the designation of individuals aboard targeted vessels as enemy combatants?

5. Who authorized each lethal strike?

6. Who authorized strikes against survivors or individuals no longer presenting an imminent threat?

7. Were ordinary interdiction and criminal prosecution alternatives available?

8. Were military legal objections ignored?

9. Did any operation violate another country's territorial sovereignty?

10. Were casualty figures or operational details intentionally concealed?

## Reference Materials

- Human Rights Watch - Year of Extrajudicial Killings at Sea, September 2, 2026.

- USNI - 70th Alleged Drug Boat Strike and UN Legal Concerns.

- Associated Press - 223 Deaths and 67 Strikes.

- ABC News - Legal Questions Surrounding Renewed Boat Strikes.

- Just Security - Legal Analysis of Maritime Strikes.

- Department of Defense Inspector General.

- Congressional Research Service.

## Investigative Standard

Investigate every strike individually. Establish target identity, intelligence reliability, geographic jurisdiction, authorization, available alternatives, casualties, treatment of survivors, and compliance with domestic and international law.

## Sources

### Human Rights Watch

- United States: Year of Extrajudicial Killings at Sea, September 2, 2026:

  https://www.hrw.org/news/2026/09/02/united-states-year-extrajudicial-killings-at-sea

### USNI News

- U.S. Strikes 70th Alleged Drug Boat, U.N. Brief Condemns Attacks, September 21, 2026:

  https://news.usni.org/2026/09/21/u-s-strikes-70th-alleged-drug-boat-u-n-brief-condemns-attacks

### Associated Press

- U.S. strikes a vessel in the eastern Pacific, killing 2 people in first attack in months. Reports 67 strikes, 223 deaths, and 65 vessels destroyed:

  https://apnews.com/article/9043dbd19265a3b4a801973376d53960

### ABC News

- Return of Trump's boat strike campaign reignites questions of legality -- and usefulness, August 31, 2026:

  https://abcnews.com/US/return-trumps-boat-strike-campaign-reignites-questions-legality/story?id=135951404

### Just Security

- Collection: U.S. Lethal Strikes on Suspected Drug Traffickers, Operation Southern Spear, Operation Absolute Resolve:

  https://www.justsecurity.org/120753/collection-u-s-lethal-strikes-on-suspected-drug-traffickers/

### United Nations / International Legal Analysis

- Ben Saul, UN Special Rapporteur: Killing “narco-terrorists” at sea  -  legal assessment of military attacks on criminal groups and drug trafficking, September 22, 2026:

  https://idpc.net/publications/2026/09/killing-narco-terrorists-at-sea-the-legality-of-military-attacks-on-criminal-groups-and-drug

- Stars and Stripes: UN experts demand accountability one year into US military drug-boat strikes, September 2, 2026:

  https://www.stripes.com/theaters/americas/2026-09-02/drug-boat-strikes-anniversary-un-22730035.html

- The Guardian: US strikes on alleged drug boats may constitute 'crimes against humanity', UN expert says, September 21, 2026:

  https://www.theguardian.com/world/2026/sep/21/us-boat-strikes-crime-against-humanity

### Additional Background and Legal Analysis

- FactCheck.org: Assessing the Facts and Legal Questions About the U.S. Strikes on Alleged Drug Boats, October 30, 2025, updated December 22, 2025:

  https://www.factcheck.org/2025/10/assessing-the-facts-and-legal-questions-about-the-u-s-strikes-on-alleged-drug-boats/

- Congressional Research Service reports:

  https://crsreports.congress.gov/

- Congressional Record: Senate discussion of legal objections and congressional authorization, December 10, 2025:

  https://www.congress.gov/119/crec/2025/12/10/171/208/CREC-2025-12-10-pt1-PgS8606-2.pdf

 

----

----

