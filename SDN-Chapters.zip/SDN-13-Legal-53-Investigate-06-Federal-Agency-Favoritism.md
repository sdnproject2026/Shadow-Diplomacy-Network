# Government Investigations

## Federal Agency Favoritism

Political Influence, Selective Enforcement, Retaliation, and Misuse of Federal Authority

## Purpose

This article is designed to outline an investigative framework for examining allegations of federal agency favoritism, political influence, selective enforcement, retaliation, and the misuse of executive authority involving political figures, private contractors, and federal institutions.

## Synopsis

This article is designed as an investigative reference report detailing executive branch oversight, regulatory integrity, and congressional inquiry mechanisms. Its primary purpose is to systematically catalog specific areas of potential administrative bias, targeted entities, investigative methods, and constitutional enforcement tools.

## Introduction and Context

Focuses on political influence, selective enforcement, retaliation, and the misuse of presidential direction over executive departments.

## Conceptual Framework

### Presidential Direction and Corporate Relationships

- Examines Donald Trump and executive authority alongside federal contracting and regulatory oversight involving Elon Musk and Federal Government Contracts (including SpaceX, Tesla, and xAI).

### Federal Agencies and Areas of Inquiry

- Identifies operational targets across the Department of Justice, Federal Bureau of Investigation, Department of Defense, Environmental Protection Agency, Internal Revenue Service, and Securities and Exchange Commission.

## Congressional Oversight

Outlines committee responsibilities for the House Oversight Committee, House Judiciary Committee, and Senate Investigations and Oversight.

## Legal Mechanisms

Catalogs evidence gathering techniques, alongside enforcement mechanisms including Congressional Subpoenas, Contempt of Congress, and oversight by Inspectors General and GAO.

## Timeline

Maps key reporting milestones from September 2026 to November 2026, profiling key figures including Donald Trump, Elon Musk, Robert Garcia, Jamie Raskin, and Hakeem Jeffries.

## Investigative Questions

Formulates key evaluative inquiries regarding political appointments, retaliatory enforcement, differential treatment of competitors, and document concealment.

## Evidentiary Support

Utilizes news reporting from the Washington Post, Associated Press, and Reuters, alongside institutional governance references from the Congressional Research Service, GAO, FEC, DOJ, and agency inspectors general.

## Conclusion and Synthesis

Synthesizes the investigative process by connecting political directives directly to agency records, procurement scoring, inspector general audits, and potential administrative or legal accountability options.

## Scope and Limitations

Acknowledges procedural constraints such as executive privilege disputes, witness constitutional protections, the high historical threshold for inherent contempt, and specifies that impeachment proceedings should be considered only if evidence and constitutional grounds warrant them.

## Summary

In short, this article explores and presents federal agency oversight by establishing a clear methodology for analyzing selective enforcement, corporate favoritism, and political interference, making complex legal and administrative procedures accessible to the reader.

## Federal Agency Favoritism

### Donald Trump

Presidential Direction of Federal Agencies

- Investigate allegations that federal agencies were used to target political opponents, critics, former officials, private businesses, or individuals opposing administration policies.

- Examine presidential and senior-administration communications concerning investigations, enforcement decisions, regulatory actions, federal grants, and procurement.

- Determine whether political appointees influenced decisions that ordinarily require independent, evidence-based agency judgment.

- Investigate whether federal agencies applied different enforcement standards to political allies and opponents.

- Examine whether investigations or regulatory actions were initiated, delayed, terminated, or redirected for political reasons.

- Determine whether federal contracts, grants, licenses, permits, or regulatory approvals were influenced by political loyalty or personal relationships.

- Examine whether federal personnel, appropriated funds, government databases, or investigative resources were used for unauthorized political purposes.

- Investigate whether federal agencies retaliated against companies, contractors, employees, or individuals for political speech or opposition to administration policies.

- Examine whether presidential authority was used to benefit private businesses, political donors, family members, or business associates.

### Elon Musk 

Federal Government Contracts

- Examine federal contracts and regulatory decisions involving SpaceX, Tesla, xAI, and other Musk-affiliated companies.

- Investigate potential conflicts arising from Musk's political spending and relationships with the Trump administration.

- Review whether procurement decisions were affected by political relationships or access to senior administration officials.

- Investigate whether federal agencies provided preferential treatment to Musk-affiliated businesses.

- Examine whether federal regulatory or enforcement decisions were influenced by political considerations.

- Investigate potential retaliation against companies or individuals opposing administration policies.

- Compare agency treatment of Musk-affiliated businesses with similarly situated competitors.

### Federal Agencies

- Department of Justice: examine politically influenced investigations, charging decisions, dismissals, and enforcement priorities.

- Federal Bureau of Investigation: examine investigative direction, personnel decisions, and potential interference with investigations.

- Department of Defense: examine procurement, contracting, grants, and treatment of companies with political connections.

- Environmental Protection Agency: examine regulatory decisions and enforcement actions affecting political allies or opponents.

- Internal Revenue Service: examine whether tax enforcement or audit decisions were politically directed.

- Securities and Exchange Commission: examine whether enforcement decisions involving politically connected businesses were affected by outside influence.

- Other federal agencies: identify contracts, grants, investigations, permits, and regulatory approvals potentially affected by political direction.

## Persons of Interest

- Donald Trump: presidential authority and potential direction of federal agencies.

- Elon Musk: federal contracts, political spending, and regulatory relationships.

- Robert Garcia: House Oversight Democratic investigative leadership.

- Jamie Raskin: House Judiciary Democratic leadership and executive accountability.

- Hakeem Jeffries: congressional oversight strategy.

- Inspectors general: independent review of agency conduct within their respective jurisdictions.

- Government Accountability Office: federal spending and program oversight.

## Congressional Oversight

### House Oversight Committee

- Investigate presidential direction of federal agencies.

- Subpoena communications between political appointees and agency officials.

- Examine federal contracts, grants, investigations, and regulatory decisions involving political allies and opponents.

- Investigate potential misuse of appropriated funds and federal personnel.

- Examine whether agencies were directed to reward political supporters or punish critics.

### House Judiciary Committee

- Examine executive-branch interference with federal investigations.

- Investigate alleged obstruction of congressional oversight.

- Examine potential abuses of executive authority.

- Review whether enforcement decisions violated applicable statutes or constitutional protections.

- Consider impeachment proceedings only if evidence and constitutional grounds warrant them.

### Senate Investigations and Oversight

- Examine political influence over federal procurement and enforcement.

- Investigate government subsidies and regulatory concessions benefiting major political donors.

- Review political fundraising arrangements involving federal contractors.

- Examine whether agency decisions were connected to private financial interests.

## Investigative Methods

- Obtain agency communications, emails, text messages, memoranda, calendars, and meeting records.

- Compare agency decisions before and after relevant political interventions.

- Obtain records of investigations opened, closed, delayed, or reassigned.

- Review procurement scoring, contract-award records, grant applications, and regulatory decision files.

- Identify political appointees involved in decisions and establish their authority.

- Interview career officials, inspectors general, contracting officers, investigators, and affected parties.

- Compare similarly situated businesses and individuals to identify inconsistent treatment.

- Trace appropriated funds and federal personnel time used in questioned activities.

- Preserve records before routine deletion or alteration.

- Refer evidence of potential criminal conduct to the Department of Justice or appropriate inspector general.

## Legal Mechanisms

### Congressional Subpoenas

- House and Senate committees may issue subpoenas for testimony and documents under their respective chamber rules.

- Committees may conduct hearings and investigate matters within their legislative jurisdiction.

- Witnesses may invoke applicable constitutional privileges and legal protections.

- Congress may pursue contempt proceedings for failure to comply with lawful subpoenas.

### Contempt of Congress

- Criminal contempt referrals may be made to the Department of Justice under 2 U.S.C. Sections 192 and 194.

- Civil enforcement actions may seek judicial orders compelling compliance.

- Inherent contempt is a historically recognized congressional authority, although modern use is exceptionally rare.

- Executive privilege disputes may produce prolonged litigation.

### Inspectors General and GAO

- Relevant inspectors general can examine agency misconduct, waste, fraud, abuse, and deficiencies in internal controls within their jurisdiction.

- The Government Accountability Office can examine federal expenditures, procurement, and program administration.

- Inspectors general may recommend corrective action and refer evidence of potential criminal conduct to appropriate authorities.

## Investigative Questions

1. Were federal investigations initiated or terminated because of political direction?

2. Were federal contracts, grants, or regulatory approvals influenced by political loyalty?

3. Were political appointees involved in decisions that improperly displaced independent agency judgment?

4. Were federal employees or appropriated funds used for political purposes?

5. Were companies or individuals subjected to retaliatory enforcement?

6. Did politically connected businesses receive preferential procurement or regulatory treatment?

7. Were comparable political allies and opponents treated differently?

8. Did agency officials conceal communications or obstruct congressional oversight?

9. Which decisions have a documented connection to presidential or political-appointee intervention?

10. What evidence supports administrative correction, civil litigation, criminal referral, or other accountability?

## Timeline

### 2026-09-12

- Washington Post reporting identifies contemplated House investigations into Trump administration conduct and related business interests.

### 2026-09-27

- Associated Press reporting describes contemplated House Democratic oversight investigations involving Trump, his family, and administration officials.

### 2026-09-28

- Reuters reports planned congressional investigations into Trump family business dealings if Democrats gain control of either chamber.

- Potential subjects include corporate relationships with the administration, family business interests, and federal contracting.

### 2026-11-04

- Federal agency favoritism, political influence, federal contracting, and executive-branch accountability remain identified investigative priorities in the supplied report.

## Sources

- Washington Post - September 12, 2026, planned House investigations

  https://www.washingtonpost.com/politics/2026/09/12/house-democrats-plan-sweeping-trump-investigations-if-they-win-november/

- Associated Press - September 27, 2026, contemplated House oversight investigations

  https://www.washingtonpost.com/politics/2026/09/26/house-democrats-trump-impeachment-investigations-corruption-jeffries/91050294-b9a3-11f1-94cb-d3d8f22a8c8b_story.html

- Reuters - September 28, 2026, planned congressional investigations

  https://www.reuters.com/legal/government/democrats-probe-lucrative-trump-family-business-deals-if-they-win-midterms-2026-09-28/

- Congressional Research Service

  https://crsreports.congress.gov/

- US Government Accountability Office

  https://www.gao.gov/

- Federal Election Commission

  https://www.fec.gov/

- Department of Justice

  https://www.justice.gov/

- Relevant federal agency inspectors general

----

----

