# Government Investigations

## War in Iran

### Purpose

This article is designed to outline a comprehensive oversight and legal framework investigating presidential authority, military losses, civilian casualties, potential information concealment, and constitutional war powers compliance regarding the military conflict with Iran.

### Synopsis

This article is designed for an audience seeking a detailed analytical framework for federal, legislative, and international inquiries into the war in Iran.

Its primary purpose is to systematically break down constitutional war-power issues, Defense Department reporting discrepancies, civilian impact assessments, institutional committee mandates, and statutory legal mechanisms.

## Introduction and Context

This article opens with War in Iran, establishing its central focus on Presidential War Powers, Casualties, Destruction, and Concealment initiated during military operations launched on February 28, 2026.

## Main Arguments and Analysis

This article outlines specific analytical tracks focusing on executive accountability, operational impacts, and regional fallout:

Donald Trump - Initiation and Continuation of Hostilities

- Examines whether offensive hostilities were improperly initiated under Article II without congressional authorization, compliance with the War Powers Resolution, and post-ceasefire decision-making.

Declaration of War and Congressional Authorization

- Focuses on the constitutional absence of a statutory authorization or formal war declaration, evaluating the applicability of the 2001 and 2002 AUMFs.

Pete Hegseth - Defense Department Casualty Reporting

- Investigates discrepancies between public casualty reporting and internal military medical records, delayed injury entries, facility damage, and operational equipment losses.

US Military Facilities and Infrastructure Damage

- Evaluates Iranian missile and drone strikes against US installations, satellite imagery disclosure, repair costs, and base vulnerabilities.

Civilian Casualties and Damage in Iran

- Focuses on civilian deaths - highlighting the February 28 Minab school strike - targeting intelligence accuracy, automated targeting systems, and adherence to international humanitarian law.

International Investigations

- Examines Iranian civilian and infrastructure impacts alongside foreign influence inquiries regarding business ventures and sovereign wealth investments involving Middle Eastern regional actors.

## Congressional Investigations

Outlines distinct responsibilities for House Armed Services, Oversight, Foreign Affairs, Appropriations, Senate Armed Services, Intelligence, Judiciary, GAO, and the DOD Inspector General.

## Timeline

Establishes a chronological sequence from the initial February 28, 2026, strikes (Operation Epic Fury), through the April ceasefire, July resumption, and casualty update milestones in September and October 2026.

## Legal Mechanisms

Identifies formal tools, including War Powers Resolution statutory limits, congressional subpoenas, DOD IG audits, GAO expenditure tracking, and international body inquiries.

## International Legal Framework

Cites foundational instruments, including UN Charter Articles 2(4) and 51, the Geneva Conventions, ICCPR, Convention Against Torture, and the Rome Statute.

## Predicate Offenses

Details legal categories subject to inquiry, such as unlawful use of force, war crimes, procurement fraud, evidence concealment, and false statements.

## Evidentiary Support

This article cites primary legal materials, news reporting, and official audits to frame its inquiries, referencing reports from the Congressional Research Service, House clerk roll-call votes, The Washington Post, Stars and Stripes, Associated Press, USNI News, Human Rights Watch, the Department of Defense Inspector General, and United Nations legal frameworks.

## Scope and Limitations

This article defines its analytical parameters under the Investigative Standard, noting that investigators must independently establish statutory legal authority, compare internal vs. public records, verify infrastructure damage, audit expenditures, and separate overall conflict legality from specific wartime attacks.

## Summary

In short, this article explores and presents the framework for investigating the war in Iran by organizing presidential actions, military casualty reporting, civilian impact assessments, and constitutional oversight tools into an accessible legal and structural roadmap.

## Offenses

### Donald Trump - Initiation and Continuation of Hostilities

- Investigate the February 28, 2026, initiation of US military operations against Iran.

- Determine whether the President initiated hostilities without congressional authorization.

- Examine whether the administration relied on an expansive interpretation of Article II presidential authority.

- Investigate whether the administration falsely characterized offensive operations as exclusively defensive.

- Examine whether the administration adequately notified Congress under the War Powers Resolution.

- Investigate whether the 60-day statutory period was observed and whether hostilities continued without the necessary congressional authorization.

- Examine statements by Trump and senior officials describing the conflict as a war.

- Investigate the decision-making behind the continuation of military operations after the April ceasefire and collapse of subsequent diplomatic arrangements.

- Determine whether presidential statements about the duration, objectives, costs, and consequences of the war were consistent with classified operational assessments.

### Declaration of War and Congressional Authorization

- Investigate the absence of a formal congressional declaration of war against Iran.

- Examine the absence of a specific statutory authorization for the use of military force against Iran.

- Review presidential notifications to Congress under the War Powers Resolution.

- Examine whether the 2001 and 2002 authorizations for use of military force could legally authorize operations against Iran.

- Investigate congressional votes concerning removal of US forces from hostilities.

- Examine whether Congress was provided sufficient information to exercise its constitutional responsibilities.

- Investigate whether the administration continued hostilities after congressional opposition or statutory deadlines.

### Pete Hegseth - Defense Department Casualty Reporting

- Investigate discrepancies between public casualty databases and internal military casualty accounting.

- Examine delayed reporting of deaths and injuries.

- Investigate whether military casualties were categorized in ways that obscured their connection to the Iran war.

- Review deaths attributed to combat, noncombat operations, indirect attacks, and subsequent military activities.

- Investigate whether wounded personnel were omitted, reclassified, or reported with significant delays.

- Examine the disclosure of military facility damage, equipment losses, and operational failures.

- Obtain the complete casualty database and compare it with internal military medical and personnel records.

### US Military Facilities and Infrastructure Damage

- Investigate the extent of Iranian missile and drone attacks against US installations.

- Examine damage to airfields, radar systems, missile-defense installations, hangars, fuel facilities, aircraft, warehouses, and troop accommodations.

- Investigate whether public statements understated the extent of damage.

- Examine satellite imagery and commercial imagery withheld from public release.

- Determine the cost of repair and replacement.

- Investigate the relocation of aircraft, personnel, and equipment from vulnerable bases.

- Examine whether military readiness assessments were misrepresented to Congress.

### Civilian Casualties and Damage in Iran

- Investigate civilian deaths resulting from US and Israeli strikes.

- Examine the February 28 Minab school strike.

- Investigate the accuracy of target-identification intelligence.

- Examine whether outdated intelligence or automated targeting systems contributed to civilian deaths.

- Obtain targeting records, rules of engagement, strike assessments, and post-strike investigations.

- Investigate whether final findings were withheld, delayed, or selectively disclosed.

- Examine destruction of hospitals, schools, residential buildings, energy facilities, transportation infrastructure, and other civilian property.

- Establish independently verified figures for deaths, injuries, displacement, and physical destruction.

- Investigate compliance with distinction, proportionality, precaution, and civilian-protection obligations.

## Congressional Investigations

### House Armed Services Committee

- War authorization.

- Operational failures.

- Military casualties.

- Infrastructure damage.

- Military readiness.

- Command responsibility.

### House Oversight Committee

- Presidential decision-making.

- Casualty reporting.

- Withheld information.

- Potential concealment of military losses.

- Executive-branch communications.

### House Foreign Affairs Committee

- International legality.

- Diplomatic consequences.

- Sovereignty.

- Foreign-government involvement.

### House Appropriations Committee

- Wartime spending.

- Military expenditures.

- Contractor benefits.

- Repair and replacement costs.

### Senate Armed Services Committee

- Command responsibility.

- Operational losses.

- Military readiness.

- Casualty reporting.

### Senate Intelligence Committee

- Intelligence reliability.

- Target selection.

- Intelligence failures.

- Classified assessments.

### Senate Judiciary Committee

- War Powers Resolution.

- Constitutional authority.

- Potential executive misconduct.

### Government Accountability Office

- Independent accounting of expenditures and damage.

- Military procurement.

- Contracting and financial oversight.

### Department of Defense Inspector General

- Casualty records.

- Equipment losses.

- Procurement.

- Reporting failures.

- Operational deficiencies.

## International Investigations

### Iran

- Investigate Iranian civilian casualties and infrastructure damage.

- Examine Iranian attacks on US military facilities and regional civilian infrastructure.

- Investigate potential war crimes by all parties.

### Saudi Arabia, UAE, and Qatar

- Examine military cooperation and regional security arrangements.

- Investigate financial relationships involving Trump family business ventures.

- Examine sovereign wealth fund investments and potential foreign influence.

- Review whether foreign investments intersected with presidential diplomatic decisions.

## Timeline

### 2026-02-28

- US and Israeli military operations against Iran begin.

### 2026-02-28

- Operation Epic Fury commences.

### 2026-02-28

- Minab school strike kills more than 150 people according to preliminary reporting in the supplied document.

### 2026-03

- Congressional scrutiny expands concerning civilian casualties, targeting decisions, and presidential war powers.

### 2026-04

- US and Iran agree to a ceasefire.

### 2026-06

- Ceasefire arrangements deteriorate.

### 2026-07

- Military hostilities resume.

### 2026-07

- Congressional members request additional information concerning civilian casualties and military losses.

### 2026-09-15

- Congressional Research Service reports 18 US military deaths and 824 wounded as of that date.

### 2026-09-18

- Washington Post reports internal Pentagon figures indicate more US military deaths than publicly disclosed.

### 2026-10-29

- Pentagon casualty database reports 23 US military deaths and 865 wounded in Iran-related operations.

### 2026-11-04

- Further congressional oversight opportunities concerning military authorization, casualties, damage, and wartime expenditures.

## Legal Mechanisms

### War Powers Resolution

- Examine presidential notification requirements.

- Review the statutory 60-day period.

- Examine the 30-day withdrawal provision where applicable.

- Investigate whether congressional authorization was obtained.

- Review congressional votes concerning continued hostilities.

### Congressional Investigative Powers

- Subpoena classified and unclassified records.

- Conduct public and closed hearings.

- Obtain military casualty and medical records.

- Obtain targeting assessments and operational orders.

- Review presidential communications.

- Investigate withheld information.

- Refer potential criminal violations to DOJ.

### Department of Defense Inspector General

- Investigate military targeting procedures.

- Examine casualty-reporting discrepancies.

- Investigate compliance with rules of engagement.

- Examine procurement and expenditures.

- Review operational failures.

- Investigate possible concealment of information.

### Government Accountability Office

- Independently audit military expenditures.

- Examine reconstruction and replacement costs.

- Review procurement and contractor payments.

- Evaluate the accuracy of government financial reporting.

## International Legal Framework

- UN Charter Article 2(4).

- UN Charter Article 51.

- Geneva Conventions.

- International Covenant on Civil and Political Rights.

- Convention Against Torture.

- Rome Statute, where jurisdiction exists.

The investigation should distinguish the legality of initiating hostilities from the legality of individual attacks conducted during an armed conflict.



## Predicate Offenses

- Potential unlawful use of force.

- Potential violations of international humanitarian law.

- Potential war crimes, where applicable elements and jurisdiction are established.

- Obstruction of justice.

- False statements.

- Destruction or concealment of evidence.

- Fraud involving military procurement.

- Violations of applicable federal reporting requirements.

## Questions for Investigators

1. Did the President initiate military hostilities against Iran without the constitutionally required congressional authorization?

2. Did the administration comply with the War Powers Resolution?

3. Did the administration provide Congress with accurate and timely casualty reports?

4. What is the independently verified death toll among US military personnel, Iranian military personnel, and Iranian civilians?

5. How many US military personnel were wounded?

6. What military facilities, diplomatic properties, civilian buildings, and critical infrastructure were destroyed or damaged?

7. Did the administration conceal military losses, civilian casualties, or the extent of infrastructure destruction?

8. What was the actual financial cost of the conflict?

9. Were civilian targets improperly identified or attacked?

10. Were the Minab school strike findings independently investigated?

11. Were classified operational assessments inconsistent with public presidential statements?

12. Did any individual issue unlawful orders or conceal evidence of unlawful conduct?

## Reference Materials

- Congressional Research Service - US Conflict with Iran.

- White House - September 3, 2026 War Powers Notification.

- Washington Post - Pentagon Casualty Reporting Discrepancies.

- Stars and Stripes - October 29 Pentagon Casualty Figures.

- Associated Press - Iranian Strikes on US Military Facilities.

- USNI - Pentagon Inspector General Report on Operation Epic Fury.

- Congressional Record - Iran War Authorization and Congressional Powers.

- United Nations - Full Text of the UN Charter.

## Investigative Standard

Establish the legal authority for hostilities, obtain complete military and medical casualty records, independently assess infrastructure destruction, examine intelligence and targeting decisions, audit wartime expenditures, and determine whether public reporting accurately represented actual conditions.

## Sources

### Congressional Research Service

- Congressional Research Service, *U.S. Conflict with Iran*, updated September 18, 2026. Covers the conflict, ceasefire, renewed hostilities, congressional war-powers options, and estimated military costs.

  https://www.everycrsreport.com/reports/R48887.html

- Congressional Research Service, *U.S. Conflict with Iran*, March 26, 2026 report:

  https://www.everycrsreport.com/files/2026-03-26_R48887_1afa45aeebb1130b3f0d451b54cd24fa49b31761.pdf

### War Powers and Congressional Authorization

- US House of Representatives, Office of the Clerk, September 15, 2026, Roll Call 307, H. Con. Res. 93. House vote directing the President to remove US forces from hostilities with Iran; passed 220–204:

  https://clerk.house.gov/Votes/2026307

- US House of Representatives, Office of the Clerk, July 23, 2026, Roll Call 282, H. Con. Res. 89:

  https://clerk.house.gov/Votes/2026282

- US House of Representatives, Office of the Clerk, June 3, 2026, Roll Call 199, H. Con. Res. 86:

  https://clerk.house.gov/Votes/2026199

- US House of Representatives, Office of the Clerk, May 14, 2026, Roll Call 170, H. Con. Res. 75:

  https://clerk.house.gov/Votes/2026170

- US House of Representatives, Office of the Clerk, April 16, 2026, Roll Call 114, H. Con. Res. 40:

  https://clerk.house.gov/Votes/2026114

- Congressional Record, April 16, 2026, House consideration of H. Con. Res. 40:

  https://www.govinfo.gov/content/pkg/CREC-2026-04-16/pdf/CREC-2026-04-16-pt1-PgH2929.pdf

- Reuters, US House votes to curb Trump's Iran war powers but Senate backs president, July 23, 2026:

  https://www.reuters.com/legal/government/us-house-votes-curb-trumps-iran-war-powers-senate-backs-president-2026-07-23/

### Pentagon Casualty Reporting

- The Washington Post, *More U.S. troops have died amid Iran war than Pentagon has disclosed publicly*, September 18, 2026:

  https://www.washingtonpost.com/national-security/2026/09/18/more-us-troops-have-died-amid-iran-war-than-pentagon-has-disclosed-publicly/

- Stars and Stripes, *Pentagon raises official death toll from Iran war to 23*, October 29, 2026:

  https://www.stripes.com/theaters/middle_east/2026-10-29/pentagon-iran-war-troops-deaths-23299434.html

- The Washington Post, *Two U.S. service members die amid Iran war, Pentagon tally shows*, October 29, 2026:

  https://www.washingtonpost.com/politics/2026/10/29/two-us-service-members-die-amid-iran-war-pentagon-tally-shows/

### US Military Facilities and Infrastructure Damage

- Associated Press, *Iran targeted US air defenses then hit aircraft and buildings on Mideast bases, AP analysis finds*, November 2026:

  https://apnews.com/article/26e0f05e01d6f56ff46f7c1a14384f7c

### Department of Defense Inspector General

- Department of Defense Office of Inspector General, *Operation Epic Fury*, Lead Inspector General report to Congress, September 14, 2026:

  https://www.dodig.mil/reports.html/Article/4600623/operation-epic-fury-oef/

- Department of Defense Office of Inspector General, Lead Inspector General Reports:

  https://www.dodig.mil/Reports/Lead-Inspector-General-Reports/

- USNI News, *Pentagon Inspector General Report on Operation Epic Fury*, September 16, 2026:

  https://news.usni.org/2026/09/16/pentagon-inspector-general-report-on-operation-epic-fury

- Department of State Office of Inspector General, Operation Epic Fury quarterly reports:

  https://www.stateoig.gov/projects/79912

### Minab School Strike and Civilian Casualties

- Human Rights Watch, *US/Israel: Investigate Iran School Attack as a War Crime*, March 7, 2026:

  https://www.hrw.org/news/2026/03/07/us/israel-investigate-iran-school-attack-as-a-war-crime

### Congressional and International Legal Materials

- United Nations, Charter of the United Nations, including Articles 2(4) and 51:

  https://www.un.org/en/about-us/un-charter/full-text

- United Nations, International Covenant on Civil and Political Rights:

  https://www.ohchr.org/en/instruments-mechanisms/instruments/international-covenant-civil-and-political-rights

- United Nations, Convention Against Torture:

  https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-against-torture-and-other-cruel-inhuman-or-degrading

- International Committee of the Red Cross, Geneva Conventions:

  https://www.icrc.org/en/war-and-law/treaties-customary-law/geneva-conventions

- International Criminal Court, Rome Statute:

  https://www.icc-cpi.int/sites/default/files/2024-05/Rome-Statute-eng.pdf

- US Government Accountability Office:

  https://www.gao.gov/

- US Department of Defense Casualty Status:

  https://www.defense.gov/casualty.pdf

  

----

----

