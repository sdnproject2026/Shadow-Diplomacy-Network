# Government Investigations

## Dark Money

Nonprofit Political Spending, Independent Expenditures, Campaign Coordination, Disclosure, and Donor Influence

## Purpose

This article is designed to outline a comprehensive investigative framework for examining political financing, billionaire donations, nonprofit dark money, Super PAC independent expenditures, and potential coordination or policy influence involving Donald Trump and aligned political organizations.

## Synopsis

This article is a structured markdown-formatted analytical report designed for mapping out congressional oversight, campaign finance investigations, and regulatory inquiries. Its primary purpose is to categorize key investigative targets, methods, legal frameworks, and questions regarding political spending and donor influence.

## Introduction and Context

Sets up the broad scope of government investigations into political financing, dark money, and donor influence.

## Conceptual Framework

Defines major thematic categories such as political financing by Donald Trump, billionaire and corporate donors (Elon Musk, Vivek Ramaswamy), nonprofit dark money, and Super PAC independent expenditures.

## Main Arguments and Analysis

Explores how political spending intersects with campaign coordination, federal policy, donor influence, and congressional oversight committees.

Details specific focus areas for the House Oversight Committee, House Judiciary Committee, Senate Investigations and Oversight, and the Federal Election Commission.

Outlines the legal framework governing dark money, Super PACs, coordination restrictions, and disclosure rules.

## Evidentiary Support

Details investigative methods, records, timelines, and primary sources such as FEC filings, nonprofit tax returns, corporate records, and congressional subpoenas.

Incorporates a chronology of recent events from September 2026 to November 2026 outlining contemplated congressional investigations.

Lists key persons and institutions of interest alongside official sources and reporting links from the Federal Election Commission, Campaign Legal Center, Americans for Tax Fairness, and major news outlets.

## Alternative Perspectives

Acknowledges that the existence of a nonprofit, large contribution, or undisclosed donor does not by itself establish a campaign finance violation, and distinguishes lawful activity from unlawful concealment.

## Conclusion and Synthesis

Summarizes the inquiry through a series of key investigative questions regarding funding sources, disclosure compliance, coordination, and potential violations requiring review or subpoenas.

## Scope and Limitations

Notes that the supplied sections do not provide a detailed, topic-specific chronology of dark-money transactions or particular FEC enforcement proceedings, limiting the timeline to broader investigative milestones.

## Summary

In short, this article explores and presents government investigations into dark money and political financing by categorizing targets, legal boundaries, oversight committees, and investigative methods into structured, accessible sections.

## Dark Money

Nonprofit Political Spending, Independent Expenditures, Campaign Coordination, Disclosure, and Donor Influence

### Donald Trump

Political Financing and Donor Influence

- Investigate political contributions and independent expenditures by billionaire donors and corporate interests supporting Trump and aligned political organizations.

- Examine whether nonprofit organizations were used to conceal the original sources of political spending.

- Identify the individuals, corporations, trusts, and other entities financing political organizations and independent expenditure committees.

- Investigate whether political spending was connected to requests for federal contracts, subsidies, regulatory concessions, appointments, or other government action.

- Examine whether donors received preferential access to presidential or administration officials.

- Review political fundraising arrangements involving federal contractors and regulated industries.

- Determine whether political spending was accurately disclosed under applicable federal election laws.

- Distinguish lawful political spending from prohibited campaign coordination, false reporting, or other potential violations.

## Billionaire Donors 

### Elon Musk

- Examine political spending and contributions involving Musk.

- Investigate relationships between political organizations and Musk-affiliated businesses.

- Review whether political spending coincided with federal contracts or regulatory decisions involving SpaceX, Tesla, xAI, and other affiliated companies.

- Examine whether political contributions or independent expenditures were associated with requests for preferential treatment.

### Vivek Ramaswamy

- Examine political organizations and financing arrangements associated with Ramaswamy.

- Identify relevant donors, nonprofit organizations, and independent expenditure committees.

- Review potential relationships between political spending and federal policy interests.

### Other Billionaire Donors

- Identify major donors and the organizations receiving their funds.

- Examine whether donors used intermediaries or nonprofit entities to obscure the source of political spending.

- Review whether donations were connected to federal policy, procurement, subsidies, or regulatory decisions.

- Examine whether corporate and individual contributions were properly reported.

### Nonprofit Organizations and Dark Money

- Identify nonprofit organizations participating in political spending.

- Determine the tax classification and applicable legal restrictions for each organization.

- Examine whether political activity was consistent with the organization's legal status.

- Trace grants, transfers, and contributions from nonprofit organizations to other political entities.

- Identify whether funds were routed through multiple organizations before reaching independent expenditure committees.

- Examine whether donor identities were disclosed where required.

- Determine whether organizations accurately reported political expenditures and related activities.

- Investigate whether nonprofit entities were used to conceal political financing or evade applicable disclosure requirements.

### Super PACs Expenditures

- Identify Super PACs receiving contributions from billionaires, corporations, nonprofits, and other entities.

- Examine the source and timing of large contributions.

- Review independent expenditure reports and supporting disclosures.

- Investigate whether expenditures were genuinely independent of candidate campaigns.

- Examine communications between Super PACs, campaigns, political parties, donors, consultants, and affiliated organizations.

- Determine whether prohibited coordination occurred.

- Review whether spending was properly reported and classified.

- Identify whether political advertisements or expenditures were funded through intermediary organizations.

### Campaign Coordination 

- Examine whether campaigns and independent expenditure committees coordinated communications, strategy, spending, or activities.

- Review shared consultants, personnel, vendors, data, and strategic communications.

- Determine whether relevant contacts violated applicable coordination restrictions.

- Examine whether nonprofit organizations accurately disclosed political spending.

- Review FEC reports and amended filings.

- Investigate whether donors, intermediaries, and recipients were accurately identified where disclosure was legally required.

- Distinguish legal nondisclosure from unlawful concealment or false reporting.

### Federal Policy and Donor Influence

- Examine whether political donors received favorable treatment involving federal contracts.

- Review donations and independent expenditures by companies seeking federal procurement awards.

- Investigate political financing by regulated industries seeking regulatory concessions.

- Examine donations by entities seeking federal leases, permits, loans, subsidies, or other government benefits.

- Review potential relationships between political financing and presidential family businesses.

- Examine whether foreign financial relationships intersected with political fundraising or federal policy decisions.

- Investigate whether political organizations served as intermediaries for financial benefits to candidates or political associates.

## Persons of Interest

- Donald Trump: presidential fundraising, political organizations, and donor relationships.

- Elon Musk: billionaire donor and business executive with federal contract and regulatory relationships.

- Vivek Ramaswamy: businessman and political figure identified in the report in connection with billionaire political financing.

- Robert Garcia: House Oversight Democratic leadership.

- Jamie Raskin: House Judiciary Democratic leadership.

- Hakeem Jeffries: congressional oversight strategy.

- Federal Election Commission.

- Campaign Legal Center.

- Americans for Tax Fairness.

- Relevant nonprofit organizations, Super PACs, political committees, and major donors.

## Congressional Oversight

### House Oversight

- Investigate political fundraising arrangements involving federal contractors.

- Examine corporate donations to presidential projects.

- Review political relationships involving Trump family businesses and major donors.

- Investigate whether presidential authority was used to benefit private businesses or political supporters.

### House Judiciary

- Examine alleged obstruction of congressional oversight.

- Investigate potential abuses of executive authority.

- Review applicable campaign finance and constitutional accountability issues.

### Senate Investigations

- Examine political fundraising arrangements involving federal contractors.

- Review government subsidies and regulatory concessions benefiting major political donors.

- Investigate foreign sovereign wealth investments involving Trump family associates.

- Examine whether political donations intersected with federal procurement and regulatory decisions.

### Federal Election Commission

- Review campaign finance reports and independent expenditure disclosures.

- Examine alleged violations of coordination restrictions.

- Review whether political committees and other covered entities filed accurate reports.

- Apply the disclosure and enforcement requirements relevant to each organization and activity.

## Legal Framework

- Certain nonprofit organizations can participate in political spending under federal tax law.

- Super PACs may accept unlimited contributions for independent expenditures.

- Coordination between campaigns and independent expenditure committees is restricted.

- Political spending disclosure requirements depend on the organization, activity, and applicable FEC rules.

- Congressional investigators can examine financial records and communications where legally authorized.

Investigators must distinguish:

- Lawful nonprofit political activity.

- Lawful independent expenditures.

- Contributions subject to federal disclosure requirements.

- Activities subject to campaign coordination restrictions.

- Potentially prohibited contributions or coordination.

- False statements, inaccurate reports, or unlawful concealment where supported by evidence.

The existence of a nonprofit, a large contribution, or an undisclosed donor does not by itself establish a campaign finance violation.

## Investigative Methods

- Federal Election Commission filings.

- Political committee contribution and expenditure reports.

- Independent expenditure disclosures.

- Nonprofit tax filings and publicly available financial disclosures.

- Corporate and organizational records.

- Grant and contribution records among nonprofit entities.

- Contracts with political consultants, advertising firms, and vendors.

- Shared personnel and consultant records.

- Campaign and committee communications.

- Donor correspondence and fundraising solicitations.

- Public statements concerning political spending.

- Federal procurement and regulatory records where donor relationships may be relevant.

- Congressional subpoenas for financial records and communications where legally authorized.

## Timeline

The supplied sections do not provide a detailed, topic-specific chronology of dark-money transactions, individual Super PAC transfers, or particular FEC enforcement proceedings. 

The following dates are broader investigative milestones rather than proof of specific dark-money conduct.

### 2026-09-12

- Washington Post reports on contemplated House investigations involving Trump administration conduct and related business interests.

### 2026-09-27

- Associated Press reports on contemplated House Democratic investigations into Trump, his family, and administration officials.

### 2026-09-28

- Reuters reports that congressional Democrats are preparing investigations into Trump family business dealings if they gain control of either chamber.

- Potential subjects include corporate donors, family business interests, and federal contracting.

### 2026-11-04

- Political fundraising, billionaire political financing, corporate donors, and federal contracting remain identified congressional investigative priorities in the supplied report.

## Investigative Questions

1. Which billionaires and corporations financed political organizations supporting Trump and aligned political interests?

2. Which nonprofit organizations received and transferred political funds?

3. Were donor identities disclosed where legally required?

4. Were funds routed through multiple organizations before reaching Super PACs?

5. Did any campaign coordinate expenditures with an ostensibly independent committee?

6. Were shared consultants, personnel, vendors, or strategic communications involved?

7. Did political spending coincide with requests for federal contracts, loans, subsidies, leases, or regulatory concessions?

8. Did donors receive access or preferential treatment from federal officials?

9. Were FEC reports accurate and complete?

10. Did any organization make false statements or conceal information required by law?

11. Which financial transactions warrant FEC review, congressional subpoenas, IRS scrutiny, or other lawful investigation?

12. Which activities are protected political spending and which, if any, violate applicable campaign finance restrictions?

## Sources

- Federal Election Commission

https://www.fec.gov/

- Campaign Legal Center

https://campaignlegal.org/

- Americans for Tax Fairness

https://americansfortaxfairness.org/

- Congressional Research Service

https://crsreports.congress.gov/

- Reuters - September 28, 2026, planned congressional investigations

https://www.reuters.com/legal/government/democrats-probe-lucrative-trump-family-business-deals-if-they-win-midterms-2026-09-28/

- Washington Post - September 12, 2026, planned House investigations

https://www.washingtonpost.com/politics/2026/09/12/house-democrats-plan-sweeping-trump-investigations-if-they-win-november/

- Associated Press - September 27, 2026, contemplated House oversight investigations

https://www.washingtonpost.com/politics/2026/09/26/house-democrats-trump-impeachment-investigations-corruption-jeffries/91050294-b9a3-11f1-94cb-d3d8f22a8c8b_story.html

----

----

