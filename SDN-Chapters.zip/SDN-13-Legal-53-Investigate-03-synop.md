# Government Investigations

## War in Iran

### Purpose

This article is designed to outline a comprehensive oversight and legal framework investigating presidential authority, military losses, civilian casualties, potential information concealment, and constitutional war powers compliance regarding the military conflict with Iran.

### Synopsis

This article is designed for an audience seeking a detailed analytical framework for federal, legislative, and international inquiries into the war in Iran.

Its primary purpose is to systematically break down constitutional war-power issues, Defense Department reporting discrepancies, civilian impact assessments, institutional committee mandates, and statutory legal mechanisms.

## Introduction and Context

This article opens with War in Iran, establishing its central focus on Presidential War Powers, Casualties, Destruction, and Concealment initiated during military operations launched on February 28, 2026.

## Main Arguments and Analysis

This article outlines specific analytical tracks focusing on executive accountability, operational impacts, and regional fallout:

Donald Trump - Initiation and Continuation of Hostilities

- Examines whether offensive hostilities were improperly initiated under Article II without congressional authorization, compliance with the War Powers Resolution, and post-ceasefire decision-making.

Declaration of War and Congressional Authorization

- Focuses on the constitutional absence of a statutory authorization or formal war declaration, evaluating the applicability of the 2001 and 2002 AUMFs.

Pete Hegseth - Defense Department Casualty Reporting

- Investigates discrepancies between public casualty reporting and internal military medical records, delayed injury entries, facility damage, and operational equipment losses.

US Military Facilities and Infrastructure Damage

- Evaluates Iranian missile and drone strikes against US installations, satellite imagery disclosure, repair costs, and base vulnerabilities.

Civilian Casualties and Damage in Iran

- Focuses on civilian deaths - highlighting the February 28 Minab school strike - targeting intelligence accuracy, automated targeting systems, and adherence to international humanitarian law.

International Investigations

- Examines Iranian civilian and infrastructure impacts alongside foreign influence inquiries regarding business ventures and sovereign wealth investments involving Middle Eastern regional actors.

## Congressional Investigations

Outlines distinct responsibilities for House Armed Services, Oversight, Foreign Affairs, Appropriations, Senate Armed Services, Intelligence, Judiciary, GAO, and the DOD Inspector General.

## Timeline

Establishes a chronological sequence from the initial February 28, 2026, strikes (Operation Epic Fury), through the April ceasefire, July resumption, and casualty update milestones in September and October 2026.

## Legal Mechanisms

Identifies formal tools, including War Powers Resolution statutory limits, congressional subpoenas, DOD IG audits, GAO expenditure tracking, and international body inquiries.

## International Legal Framework

Cites foundational instruments, including UN Charter Articles 2(4) and 51, the Geneva Conventions, ICCPR, Convention Against Torture, and the Rome Statute.

## Predicate Offenses

Details legal categories subject to inquiry, such as unlawful use of force, war crimes, procurement fraud, evidence concealment, and false statements.

## Evidentiary Support

This article cites primary legal materials, news reporting, and official audits to frame its inquiries, referencing reports from the Congressional Research Service, House clerk roll-call votes, The Washington Post, Stars and Stripes, Associated Press, USNI News, Human Rights Watch, the Department of Defense Inspector General, and United Nations legal frameworks.

## Scope and Limitations

This article defines its analytical parameters under the Investigative Standard, noting that investigators must independently establish statutory legal authority, compare internal vs. public records, verify infrastructure damage, audit expenditures, and separate overall conflict legality from specific wartime attacks.

## Summary

In short, this article explores and presents the framework for investigating the war in Iran by organizing presidential actions, military casualty reporting, civilian impact assessments, and constitutional oversight tools into an accessible legal and structural roadmap.