# Government Investigations

## Military Operations

### Purpose

- This article is designed to outline an investigative framework examining presidential authority, military accountability, legal mechanisms, and international law violations surrounding lethal military strikes against suspected drug-trafficking vessels.

### Synopsis

- This article is a structured markdown-formatted article designed for an audience seeking a detailed legal and legislative oversight framework regarding US military operations targeting suspected maritime narcotics traffickers. Its primary purpose is to establish investigative priorities, evaluate executive and DOD authorization, assess compliance with international law, and detail oversight mechanisms for lethal strikes conducted under Operation Southern Spear.

### Introduction and Context

- This article opens with extrajudicial killings and presidential authorization of lethal maritime strikes in the Caribbean and eastern Pacific.

### Main Arguments and Analysis

This article outlines specific operational, command, and geopolitical investigative tracks:

- Donald Trump - Presidential Authorization - investigating the legal basis for treating suspected traffickers as enemy combatants, the absence of judicial due process, intelligence reliability, survivor-targeting incidents, territorial sovereignty violations, and potential executive misrepresentations.

- Operation Southern Spear / Joint Task Force - Western Hemisphere - focusing on the campaign initiated on September 2, 2025, detailing vessel destruction, casualty verification, classified DOJ legal justifications, and executive displacement of congressional war powers.

- Pete Hegseth - Secretary of Defense - examining DOD targeting protocols, compliance with rules of engagement, handling of internal military legal objections, Pentagon Inspector General inquiries, and potential command or individual criminal liability.

- International Investigations - detailing jurisdictional implications for affected nations - including Venezuela, Colombia, Trinidad and Tobago, and other Caribbean states - concerning sovereignty violations, flag-state consent, and non-judicial killings of foreign nationals.

### Conceptual Framework

The article organizes the oversight infrastructure, legal standards, and empirical data governing the inquiry:

- Congressional Oversight - Maritime Strikes - delineating committee mandates across House and Senate Armed Services, Judiciary, Oversight, and Intelligence committees.

## Timeline

Establishes key operational milestones from September 2, 2025, through strike renewals, casualty escalation reports, and oversight opportunities into late 2026.

## Legal Mechanisms

Categorizes mechanisms for evidence gathering, subpoena enforcement, DOD Inspector General audits, DOJ referrals, and UN/international human rights inquiries.

## International Legal Framework

Cites governing treaties and statutes, including UN Charter Articles 2(4) and 51, the Geneva Conventions, ICCPR right-to-life protections, and UNCLOS.

## Predicate Offenses

Enumerates potential domestic statutory and international law violations, ranging from unlawful killings and conspiracy to obstruction of justice and maritime sovereignty breaches.

## Evidentiary Support

This article cites independent reporting and official legal assessments to substantiate casualty and strike figures, referencing data from Human Rights Watch, USNI News, Associated Press, ABC News, Just Security, the Department of Defense Inspector General, Congressional Research Service, and United Nations Special Rapporteurs.

## Scope and Limitations

The article defines its evidentiary boundaries under the Investigative Standard, requiring each strike to be analyzed individually regarding target identity, geographic jurisdiction, available alternatives, and legal compliance rather than relying on generalized assumptions.

## Summary

In short, this article explores and presents the parameters of executive and military accountability for maritime strikes by organizing key operational details, international legal frameworks, oversight bodies, and specific investigative questions.

