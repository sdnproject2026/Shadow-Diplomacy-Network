# Government Investigations

## International Crimes

# Purpose

This article is designed to outline an investigative framework for analyzing potential international crimes, foreign sovereignty violations, foreign emoluments, and cross-border financial relationships involving foreign states, international regulatory bodies, and presidential accountability.

# Synopsis

This article is designed as an investigative reference report focusing on international law, sovereign jurisdiction, foreign relations, and global financial oversight. Its primary purpose is to systematically present jurisdictional parameters, foreign regional conflicts, international legal frameworks, and global investigative bodies.

## Introduction and Context

This article focuses on international crimes, sovereign jurisdiction, foreign government accountability, and presidential responsibility for overseas military operations and international law compliance.

## Conceptual Framework

### Sovereignty and Jurisdiction

- Establishes jurisdictional categories (Territorial, Nationality, Flag-State, Universal) alongside regional focus areas including Iran, Venezuela and Caribbean States, and specific sovereign entities (Colombia, Trinidad and Tobago, Saudi Arabia, UAE, Qatar, and the United Kingdom).

### International Legal 

- Identifies key treaties and conventions, including Article 2(4) and Article 51 of the UN Charter, the Geneva Conventions, ICCPR, UNCLOS, Convention Against Torture, and the Rome Statute.

### Related Foreign Financial Issues

- Focuses on Jared Kushner and Affinity Partners sovereign investments and constitutional analysis of the Foreign Emoluments Clause.

## International Investigative Bodies

- Details roles for the United Nations Human Rights Council, UN Special Rapporteurs, International Court of Justice (ICJ), International Criminal Court (ICC), Interpol, and national prosecutors.

## Predicate Offenses

- Outlines cross-border evidence preservation, mutual legal assistance, state-to-state proceedings, and potential offenses including unlawful killings, war crimes, money laundering, and sovereignty violations.

## Questions for Investigators

- Formulates questions on host-state consent, judicial process, civilian infrastructure damage, foreign sovereign wealth connections, and ICC jurisdiction.

## Evidentiary Support

References primary international treaties (UN Charter, Geneva Conventions, UNCLOS, Rome Statute), official UN bodies, US Constitutional provisions, and investigative news reporting (Reuters).

## Investigative Standard

Synthesizes the analysis by requiring investigators to identify precise location, nationality, responsible parties, legal framework, and jurisdiction for every incident while pursuing accountability through competent domestic and international institutions.

## Scope and Limitations

### Highlights critical legal caveats

- The US is not a party to the Rome Statute, the existence of armed conflict or civilian casualties does not automatically establish a war crime, and Supreme Court precedent on the Foreign Emoluments Clause lacks a definitive merits ruling.

## Summary

In short, this article explores and presents international law and sovereignty investigations by structuring legal frameworks, regional conflict zones, cross-border financial connections, and international judicial channels into a coherent analytical roadmap, making complex global jurisdiction issues accessible to the reader.

## International Crimes

### Sovereign Jurisdiction 

Foreign Government Accountability

### Donald Trump 

International Responsibility

- Investigate presidential decisions involving the use of US military force within sovereign territories.

- Examine whether military operations violated the territorial integrity or political independence of other states.

- Investigate operations conducted without host-state consent or a valid international legal justification.

- Examine whether the administration relied on disputed self-defense claims.

- Investigate the use of force against foreign nationals outside US territory.

- Examine whether US operations violated international human-rights obligations.

- Investigate possible violations of international humanitarian law during armed conflict.

- Examine whether foreign governments were pressured to cooperate with operations that violated their own domestic or international obligations.

- Investigate whether US officials concealed evidence of civilian casualties or destruction of protected civilian infrastructure.

### Iran

Sovereignty and International Law

- Investigate the legality of US and Israeli military operations inside Iranian territory.

- Examine whether the attacks satisfied the requirements of individual or collective self-defense.

- Determine whether Iran had committed an armed attack sufficient to justify the use of force under Article 51 of the UN Charter.

- Examine whether military objectives were legitimate and whether attacks complied with proportionality and distinction.

- Investigate damage to civilian infrastructure and protected facilities.

- Examine potential violations involving attacks on schools, hospitals, residential areas, and civilian energy infrastructure.

- Investigate the treatment of prisoners, detainees, and civilian populations.

- Examine whether Iran's retaliatory attacks against US facilities, Israel, and other regional states independently violated international law.

### Venezuela and Caribbean States 

Maritime Sovereignty

- Investigate US military strikes in the Caribbean and eastern Pacific.

- Establish the precise geographic location of every strike.

- Determine whether operations occurred in international waters, territorial seas, or another state's exclusive jurisdiction.

- Identify the flag state of each targeted vessel.

- Investigate whether the flag state provided consent for boarding, interdiction, or other enforcement action.

- Examine whether coastal states were notified or consulted.

- Investigate whether the US asserted jurisdiction based on suspected drug trafficking, nationality, treaty provisions, or armed-conflict claims.

- Examine whether the United States violated another state's sovereignty by conducting military strikes within its territorial waters.

- Investigate whether foreign nationals were killed without judicial process.

### Sovereign States and Jurisdiction

The investigation should distinguish between four separate jurisdictional questions:

1. Territorial jurisdiction: Which state has sovereignty over the location where the alleged offense occurred?

2. Nationality jurisdiction: Which country has jurisdiction over the person accused or the victim?

3. Flag-state jurisdiction: Which country has jurisdiction over a vessel registered under its flag?

4. Universal or international jurisdiction: Whether particular international crimes permit prosecution beyond the state where they occurred.

## International Legal Framework

- UN Charter Article 2(4): prohibition on the threat or use of force against the territorial integrity or political independence of another state.

- UN Charter Article 51: individual and collective self-defense following an armed attack, subject to applicable requirements.

- Geneva Conventions: protections applicable during armed conflict.

- International Covenant on Civil and Political Rights: protections including the right to life.

- UN Convention on the Law of the Sea: maritime jurisdiction and navigational rights.

- Convention Against Torture: prohibition on torture and related obligations.

- Rome Statute: framework for crimes within the International Criminal Court's jurisdiction.

The United States is not a party to the Rome Statute. 

The ICC therefore does not automatically have jurisdiction over every alleged crime involving US nationals. Jurisdiction may nevertheless arise under specific territorial, nationality, Security Council referral, or other applicable provisions.

## International Investigations

### Iran

- Investigate Iranian civilian casualties and infrastructure damage.

- Examine Iranian attacks on US military facilities and regional civilian infrastructure.

- Investigate potential war crimes by all parties.

### Venezuela

- Examine the legality of US military operations affecting Venezuelan territorial interests.

- Investigate potential violations of sovereignty and the rights of Venezuelan nationals.

### Colombia

- Examine any alleged involvement of Colombian nationals in maritime strikes.

- Investigate potential violations of Colombian sovereignty or the rights of Colombian citizens.

### Trinidad and Tobago and Caribbean States

- Examine maritime operations in or near territorial waters.

- Investigate whether governments were notified or consented to US operations.

- Review the impact on maritime security and regional sovereignty.

### Saudi Arabia, UAE, and Qatar

- Investigate financial relationships involving Trump family business ventures.

- Examine sovereign wealth fund investments and potential foreign influence.

- Review whether foreign investments intersected with presidential diplomatic decisions.

- Investigate whether any financial transactions involved prohibited benefits to public officials.

### United Kingdom

- Examine the Epstein-related investigation involving Andrew Mountbatten-Windsor.

- Review cooperation between UK police, US investigators, and Epstein survivors.

- Investigate potential cross-border trafficking and financial transactions.

## Related Foreign Financial Issues

### Jared Kushner and Affinity Partners

- Investigate foreign sovereign wealth investments in Affinity Partners.

- Examine Saudi, UAE, and Qatari investments.

- Investigate potential conflicts between foreign financing and previous White House diplomatic responsibilities.

- Examine whether foreign investors received favorable access to US government officials.

- Investigate whether diplomatic decisions overlapped with financial interests.

- Examine the reported $2 billion Saudi investment.

- Review potential foreign influence and financial disclosure issues.

### Foreign Emoluments Clause

- Examine whether foreign-government financial benefits involving presidential business interests implicate Article I, Section 9, Clause 8.

- Investigate whether foreign-government benefits were accepted without congressional consent.

- Examine the source and nature of each financial benefit.

- Distinguish ordinary private commercial transactions from benefits attributable to foreign governments.

The supplied original report notes that the Supreme Court did not issue a definitive merits ruling on Trump's first-term emoluments litigation.

## International Judicial Bodies

### United Nations Human Rights Council

- Investigate alleged human-rights violations.

- Examine civilian casualties and destruction of protected infrastructure.

- Seek independent documentation and witness testimony.

### UN Special Rapporteurs

- Examine alleged extrajudicial killings.

- Investigate violations of international law.

- Request explanations from relevant governments.

### International Court of Justice

- Adjudicate disputes between states where jurisdiction exists.

- Examine state responsibility under applicable international law.

### International Criminal Court

- Investigate crimes within its jurisdiction.

- Examine applicable territorial and other jurisdictional requirements.

- Preserve evidence of alleged international crimes.

### Interpol

- Facilitate international police cooperation.

- Assist with cross-border criminal investigations where appropriate.

## Foreign National Prosecutors

- Investigate offenses within their respective territorial or nationality jurisdictions.

- Preserve evidence.

- Examine potential criminal conduct involving their nationals or territory.

### National Human-Rights Commissions

- Investigate civilian casualties.

- Examine unlawful state conduct.

- Preserve evidence and obtain witness testimony.

## Legal Mechanisms

- International evidence preservation.

- Mutual legal assistance requests.

- Cross-border financial investigations.

- National criminal prosecutions.

- International human-rights investigations.

- State-to-state legal proceedings.

- Treaty-based cooperation.

- International judicial proceedings where jurisdiction exists.

- Independent civilian casualty and property-damage assessments.

## Predicate Offenses

- Potential unlawful killings.

- Potential war crimes.

- Potential crimes against humanity where the applicable elements are established.

- Torture.

- Conspiracy.

- Obstruction of justice.

- Destruction or concealment of evidence.

- Money laundering.

- Cross-border financial fraud.

- Violations of applicable sovereignty and maritime laws.

The existence of armed conflict or civilian casualties does not automatically establish a war crime. Investigators must establish the applicable offense, conduct, intent, circumstances, and jurisdiction.

## Questions for Investigators

1. Did US military operations violate the sovereignty of any foreign state?

2. Were operations conducted without host-state consent or a valid international legal justification?

3. Which countries have territorial, nationality, or flag-state jurisdiction over maritime strikes?

4. Did foreign nationals die without judicial process?

5. Did US military operations cause civilian deaths or destruction of protected civilian infrastructure?

6. Were any foreign governments pressured to facilitate potentially unlawful military operations?

7. Did foreign sovereign wealth funds or overseas corporations provide financial benefits connected to presidential access?

8. Did financial relationships involving foreign governments overlap with presidential diplomatic decisions?

9. Could foreign national prosecutors investigate conduct occurring within their jurisdiction?

10. Which allegations fall within the jurisdiction of the International Criminal Court or other international judicial bodies?

11. Were international legal obligations independently violated by retaliatory operations?

12. What evidence should be preserved for future domestic or international proceedings?

## Reference Materials

- United Nations - Full Text of the UN Charter.

- UN Security Council - Sovereignty and Prohibition on Use of Force.

- UN Human Rights Council.

- UN Special Rapporteurs.

- International Court of Justice.

- International Criminal Court.

- UN Convention on the Law of the Sea.

- International Covenant on Civil and Political Rights.

- Geneva Conventions.

- Convention Against Torture.

- Congressional Research Service.

## Investigative Standard

Identify the location, nationality, responsible parties, applicable legal framework, and jurisdiction for every incident. Preserve primary evidence, independently establish casualties and property damage, distinguish state responsibility from individual criminal liability, and pursue investigations through legally competent domestic and international institutions.

## Sources

### United Nations Charter and Sovereignty

- United Nations - Full Text of the UN Charter, including Articles 2(4), 51, and 92–96:

  https://www.un.org/en/about-us/un-charter/full-text

- UN Security Council - Repertoire of the Practice of the Security Council:

  https://main.un.org/securitycouncil/en/content/repertoire

- International Court of Justice - Statute of the International Court of Justice, including jurisdiction under Article 36:

  https://www.un.org/en/about-us/un-charter/statute-of-the-international-court-of-justice

### International Criminal Court

- International Criminal Court - Rome Statute:

  https://www.icc-cpi.int/sites/default/files/2024-05/Rome-Statute-eng.pdf

- International Criminal Court - Jurisdiction:

  https://www.icc-cpi.int/about/how-the-court-works

- International Committee of the Red Cross - Rome Statute, Article 12: Preconditions to the Exercise of Jurisdiction:

  https://ihl-databases.icrc.org/en/ihl-treaties/icc-statute-1998/article-12

- United Nations Treaty Collection - Rome Statute of the International Criminal Court, status of parties:

  https://treaties.un.org/Pages/ViewDetails.aspx?src=TREATY&mtdsg_no=XVIII-10&chapter=18

### International Humanitarian and Human-Rights Law

- International Committee of the Red Cross - Geneva Conventions:

  https://www.icrc.org/en/war-and-law/treaties-customary-law/geneva-conventions

- United Nations - International Covenant on Civil and Political Rights:

  https://www.ohchr.org/en/instruments-mechanisms/instruments/international-covenant-civil-and-political-rights

- United Nations - Convention Against Torture:

  https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-against-torture-and-other-cruel-inhuman-or-degrading

- International Committee of the Red Cross - Customary International Humanitarian Law Database:

  https://ihl-databases.icrc.org/en/customary-ihl

### Maritime Jurisdiction and Law of the Sea

- United Nations - United Nations Convention on the Law of the Sea:

  https://www.un.org/depts/los/convention_agreements/texts/unclos/unclos_e.pdf

- United Nations Division for Ocean Affairs and the Law of the Sea:

  https://www.un.org/depts/los/

- International Maritime Organization - Maritime Security:

  https://www.imo.org/en/OurWork/Security/Pages/MaritimeSecurity.aspx

### United Nations Human-Rights Investigations

- United Nations Human Rights Council:

  https://www.ohchr.org/en/hr-bodies/hrc

- United Nations Special Procedures - Special Rapporteurs and Independent Experts:

  https://www.ohchr.org/en/special-procedures-human-rights-council

- Office of the UN High Commissioner for Human Rights:

  https://www.ohchr.org/

### International Police and Legal Cooperation

- INTERPOL - International Police Cooperation:

  https://www.interpol.int/

- United Nations Office on Drugs and Crime - Mutual Legal Assistance:

  https://www.unodc.org/

- United States Department of Justice - Office of International Affairs:

  https://www.justice.gov/criminal/criminal-oia

### Foreign Emoluments and Financial Conflicts

- US Constitution - Article I, Section 9:

  https://constitution.congress.gov/browse/article-1/section-9/

- Congressional Research Service - Constitution Annotated, Foreign Emoluments Clause:

  https://constitution.congress.gov/browse/essay/artI-S9-C8-1/ALDE_00013140/

- US Government Accountability Office:

  https://www.gao.gov/

### Jared Kushner and Affinity Partners

- Affinity Partners:

  https://www.affinitypartners.com/

- Reuters - Reporting on Trump Family Business Deals and Foreign Investment:

  https://www.reuters.com/world/us/democrats-probe-lucrative-trump-family-business-deals-if-they-win-midterms-2026-09-28/

### Congressional Research and International Law

- Congressional Research Service:

  https://crsreports.congress.gov/

- United States Department of State - Office of the Legal Adviser:

  https://www.state.gov/bureaus-offices/secretary-of-state/office-of-the-legal-adviser/

- United States Department of Defense - Law of War:

  https://www.defense.gov/Spotlights/Law-of-War/

----

----

