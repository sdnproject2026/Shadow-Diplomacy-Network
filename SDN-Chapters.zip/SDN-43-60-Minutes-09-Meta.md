### SDN-43-60-Minutes-09-MC2-Tel-Aviv

## Metadata

- PB
- PI
- CC
- PR

> HASH

----

- 2026-11-00
