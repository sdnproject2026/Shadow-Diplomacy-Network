# Government Investigations

## Cryptocurrency

### Purpose

This article is designed to outline a comprehensive investigative framework for examining cryptocurrency ventures, financial self-enrichment, and potential legal violations associated with presidential family members and related entities, alongside relevant congressional, regulatory, and legal mechanisms.

### Synopsis

This article is designed as an investigative reference report detailing potential legal, regulatory, and congressional oversight inquiries into political figures and cryptocurrency projects. Its primary purpose is to systematically catalog investigative domains, targeted entities, financial metrics, and legal mechanisms.

## Introduction and Context

### Government Investigations

- Focuses on presidential self-enrichment, investor losses, and financial fraud regarding cryptocurrency ventures.

## Conceptual Framework

### Cryptocurrency Ventures

- Covers World Liberty Financial, $TRUMP - Presidential Meme Coin, MELANIA Meme Coin, and the roles of Donald Trump, Melania Trump, Donald Trump Jr., and Eric Trump.

### Reported Financial Impact

- Details investor losses, market capitalization versus realized proceeds, and the Reuters June 9, 2026 estimate of $2.3 billion in gains and losses.

### Foreign Investment and Political Influence

- Examines sovereign wealth funds, foreign purchases, and the Foreign Emoluments Clause.

### Related Financial Investigations

- Reviews Jared Kushner and Affinity Partners and Donald Trump Jr. and 1789 Capital.

## Main Arguments and Analysis

### Congressional Investigations

- Outlines roles for the House Oversight Committee, House Judiciary Committee, Senate Banking Committee, and Senate Investigations and Oversight.

### Financial Regulators

- Highlights oversight by the Securities and Exchange Commission (SEC), Commodity Futures Trading Commission (CFTC), Financial Crimes Enforcement Network (FinCEN), and Internal Revenue Service (IRS).

### Timeline and Legal Mechanisms

- Catalogs key dates from January 2025 through November 2026, alongside potential predicate offenses like securities fraud, wire fraud, and money laundering.

### Questions for Investigators

- Poses core analytical questions regarding token allocations, proceeds, and foreign access.

## Evidentiary Support

Utilizes market data references from CoinMarketCap and CoinGecko, institutional reports from the House Judiciary Committee Democrats, and investigative reporting from Reuters.

## Investigative Standard

Concludes with a mandate to trace every token allocation, financial transfer, and potential conflict between public authority and private financial interests.

## Scope and Limitations

Notes explicit caveats that investment losses or insider allocations do not independently establish fraud, requiring investigators to establish statutory elements, intent, and material omissions.

## Summary

In short, this article explores and presents government investigations into cryptocurrency ventures and financial dealings by categorizing targets, oversight committees, regulatory bodies, and legal standards into a clear structural framework, making its complex scope accessible to the reader.

## Presidential Self-Enrichment

Investor Losses, and Potential Financial Fraud

### Donald Trump

World Liberty Financial and Presidential Cryptocurrency Ventures

- Investigate the creation and ownership structure of World Liberty Financial.

- Examine the role of Trump family members in token issuance, marketing, sales, governance, and revenue distribution.

- Investigate whether the President or his family profited from cryptocurrency ventures while exercising regulatory authority over the cryptocurrency industry.

- Examine foreign purchases of Trump-affiliated cryptocurrency tokens.

- Investigate whether foreign governments, sovereign wealth funds, politically connected individuals, or overseas corporations purchased tokens to obtain presidential access or influence.

- Examine whether token ownership provided voting, governance, or other privileges.

- Investigate whether buyers were adequately informed about token restrictions, liquidity, insider allocations, and actual economic rights.

- Review whether promotional statements created misleading expectations of value, utility, or presidential backing.

- Investigate insider sales, undisclosed token disposals, related-party transactions, and conflicts of interest.

- Examine whether cryptocurrency ventures were used to transfer wealth to family members, business associates, political donors, or foreign interests.

- Investigate possible securities fraud, commodities-law violations, deceptive marketing, wire fraud, money laundering, and tax violations where evidence supports the elements of those offenses.

### World Liberty Financial

- Investigate distribution of WLFI tokens.

- Examine insider allocations and restrictions on public trading.

- Investigate token sales and liquidity arrangements.

- Examine the relationship between token holders and the company.

- Investigate whether purchasers understood that buying tokens did not necessarily provide equity ownership or conventional shareholder rights.

- Investigate the relationship between token sales and family revenue.

- Review foreign investment and connections to government officials.

- Examine whether cryptocurrency regulatory decisions benefited affiliated ventures.

### $TRUMP - Presidential Meme Coin

- Investigate the January 2025 launch of the $TRUMP token.

- Examine allocation of tokens to insiders and associated entities.

- Investigate revenue generated by token sales and trading activity.

- Examine whether presidential promotional activity created misleading impressions about investment security.

- Investigate the extent to which purchasers were exposed to concentrated insider ownership and sudden price declines.

- Examine whether insiders realized profits while ordinary purchasers absorbed market losses.

- Investigate potential conflicts between presidential responsibilities and commercial token ownership.

### MELANIA Meme Coin

- Investigate the creation and distribution of the MELANIA cryptocurrency.

- Examine ownership, insider allocations, token unlock schedules, and sales.

- Investigate Melania Trump's role and affiliated companies in marketing and monetizing the token.

- Examine whether buyers received adequate disclosures concerning supply concentration and liquidity.

- Investigate whether promotional activity created an impression of official presidential-family sponsorship.

- Examine whether token buyers suffered losses while insiders realized substantial proceeds.

- Investigate whether proceeds were transferred through corporate entities or wallets requiring beneficial-ownership disclosure.

- Examine potential conflicts involving the First Lady's public position and commercial cryptocurrency activities.

### Donald Trump Jr. and Eric Trump

- Investigate their roles in cryptocurrency ventures.

- Examine token ownership, beneficial interests, distributions, and related-party transactions.

- Investigate their involvement in marketing and fundraising.

- Examine whether family members benefited from government policies or regulatory decisions affecting their cryptocurrency businesses.

- Investigate potential undisclosed foreign financial relationships.

- Examine whether political connections were used to attract investors.

### Reported Financial Impact

- Investigate reported investor losses exceeding 98% for certain Trump-family cryptocurrency ventures.

- Establish the difference between peak market capitalization, realized investor losses, and unrealized declines.

- Determine how much money insiders actually received.

- Compare insider sales and distributions with losses experienced by public purchasers.

- Examine whether misleading representations or undisclosed insider arrangements contributed to investor losses.

- Investigate the Reuters-reported June 9, 2026, estimate of approximately $2.3 billion in combined Trump-family cryptocurrency gains and approximately $2.3 billion in outside investor losses.

- Independently reconstruct transaction-level proceeds and losses rather than treating market-capitalization changes as realized losses.

## Foreign Political Influence

Examine purchases by foreign governments, sovereign wealth funds, overseas corporations, and politically connected investors.

- Investigate whether cryptocurrency purchases were connected to presidential access.

- Examine whether foreign financing overlapped with diplomatic or regulatory decisions.

- Review potential foreign influence and financial disclosure issues.

- Examine potential implications of the Foreign Emoluments Clause.

- Investigate whether financial arrangements were structured to obscure beneficial ownership.

## Related Financial Investigations

### Jared Kushner and Affinity Partners

- Investigate foreign sovereign wealth investments in Affinity Partners.

- Examine investments from Saudi Arabia, the United Arab Emirates, and Qatar.

- Investigate potential conflicts between financial relationships and previous White House diplomatic responsibilities.

- Examine whether foreign investors received favorable access to US officials.

- Investigate whether diplomatic decisions overlapped with financial interests.

- Examine the reported $2 billion Saudi investment.

- Review financial disclosure and potential foreign influence.

### Donald Trump Jr. and 1789 Capital

- Investigate investments in companies receiving federal contracts.

- Examine whether political access was marketed to prospective investors.

- Review relationships between portfolio companies and federal procurement officials.

- Investigate conflicts involving defense technology, artificial intelligence, drones, and government financing.

These investigations should remain distinct from cryptocurrency inquiries unless evidence establishes a financial or corporate connection.

## Congressional Investigations

### House Oversight Committee

- Investigate World Liberty Financial.

- Examine Trump family cryptocurrency ownership and financial arrangements.

- Investigate foreign financial relationships.

- Examine corporate donations and presidential self-enrichment.

- Investigate whether presidential authority was used to benefit private businesses.

- Subpoena token-distribution records, financial statements, and relevant communications.

Robert Garcia is identified in the supplied report as a potential Democratic investigative leader if Democrats assume committee control.

### House Judiciary Committee

- Examine potential conflicts of interest.

- Investigate executive-branch regulatory favoritism.

- Examine potential obstruction of congressional oversight.

- Investigate foreign influence and possible legal violations.

Jamie Raskin is identified in the supplied report as a leading figure in preparations for executive-accountability investigations.

### Senate Banking Committee

- Investigate cryptocurrency businesses connected to the Trump family.

- Examine foreign financing of cryptocurrency ventures.

- Review federal cryptocurrency regulatory decisions.

- Investigate financial disclosure and anti-corruption safeguards.

### Senate Investigations and Oversight

- Examine foreign sovereign wealth investments.

- Investigate political fundraising arrangements involving federal contractors.

- Review government subsidies and regulatory concessions.

- Examine financial relationships involving presidential family associates.

## Financial Regulators

### Securities and Exchange Commission

- Investigate securities offerings.

- Examine deceptive disclosures.

- Review insider transactions.

- Investigate potential securities fraud.

- Examine whether applicable registration and disclosure requirements were satisfied.

### Commodity Futures Trading Commission

- Investigate commodity-market manipulation.

- Examine applicable cryptocurrency-market violations.

- Review trading and market conduct.

### Financial Crimes Enforcement Network

- Examine suspicious financial transactions.

- Investigate beneficial ownership.

- Review money-laundering risks.

- Examine applicable Bank Secrecy Act obligations.

### Internal Revenue Service

- Investigate tax reporting.

- Examine undisclosed income.

- Review potentially fraudulent financial disclosures.

- Investigate taxable cryptocurrency proceeds and distributions.

## Timeline

### 2025-01

- $TRUMP presidential meme coin launches.

### 2025

- MELANIA meme coin launches.

### 2026-01

- Congressional scrutiny expands to cryptocurrency ventures and presidential family financial interests.

### 2026-06-09

- Reuters publishes investigation estimating $2.3 billion in combined Trump-family cryptocurrency gains and approximately $2.3 billion in outside investor losses.

### 2026-09-28

- Reuters reports anticipated congressional investigations into cryptocurrency, 1789 Capital, Affinity Partners, corporate donors, and defense contracts.

### 2026-11-04

- Further congressional investigative opportunities concerning presidential family cryptocurrency ventures.

## Legal Mechanisms

- Congressional subpoenas.

- SEC investigations.

- CFTC investigations.

- FinCEN financial intelligence and compliance examinations.

- IRS tax investigations.

- DOJ financial fraud investigations.

- Beneficial-ownership investigations.

- Anti-money-laundering examinations.

- Inspector-general investigations.

- Foreign financial transaction reviews.

- Civil litigation and investor claims.

## Predicate Offenses

- Securities fraud.

- Commodities-law violations.

- Wire fraud.

- Money laundering.

- Tax fraud and tax evasion.

- False financial disclosures.

- Conspiracy.

- Fraudulent fundraising.

- Deceptive marketing.

- Undisclosed foreign financial arrangements.

- Potential campaign finance violations.

An investment loss, token-price decline, or insider allocation does not independently establish fraud. Investigators must establish applicable representations, material omissions, intent, transactions, and statutory elements.

## Questions for Investigators

1. How much money did Trump, Melania, Donald Trump Jr., Eric Trump, and affiliated entities receive from cryptocurrency ventures?

2. What percentage of tokens were allocated to insiders?

3. What were the actual proceeds from token sales and insider distributions?

4. Did purchasers receive adequate disclosures about token ownership, liquidity restrictions, and financial risks?

5. Did foreign investors purchase cryptocurrency or provide financing to obtain presidential access or influence?

6. Were regulatory decisions affected by the President's private cryptocurrency interests?

7. Were purchasers misled about the economic rights associated with tokens?

8. Did insiders sell tokens before substantial market declines?

9. Were financial transfers structured to conceal beneficial ownership?

10. Did any cryptocurrency venture violate applicable securities, commodities, tax, or anti-money-laundering laws?

11. What portion of reported investor losses represents realized losses rather than unrealized market declines?

12. Did presidential-family members use political connections to attract investors?

## Reference Materials

- Reuters - Parsing the Trumps' Crypto Profits and Investors' Losses, June 9, 2026.

- CoinMarketCap - MELANIA Token Historical Performance.

- CoinGecko - MELANIA Token Market Data.

- House Judiciary Democrats - Trump Family Cryptocurrency Report.

- Federal Election Commission.

- Securities and Exchange Commission.

- Commodity Futures Trading Commission.

- Financial Crimes Enforcement Network.

- Internal Revenue Service.

## Investigative Standard

Trace every token allocation, purchase, sale, distribution, beneficial owner, and financial transfer. Establish actual realized proceeds, investor losses, representations made to purchasers, foreign financial connections, and the relationship between presidential authority and private financial interests.

## Sources

### Reuters 

Trump Family Cryptocurrency Profits and Investor Losses

- Reuters, June 9, 2026, Parsing the Trumps' Crypto Profits, Investors' Losses. Reuters estimated approximately $2.3 billion in Trump-family gains and approximately $2.3 billion in outside investor losses across several crypto-related ventures. The reported investor-loss figure includes paper losses on unsold investments, not solely realized losses.

https://www.reuters.com/investigations/parsing-trumps-crypto-profits-investors-losses-2026-06-09/

- Reuters special report, Under the Trump crypto playbook, the family always wins. Investors don't:

https://archive.ph/bCJGA

### House Judiciary Committee Democrats

Trump Family Cryptocurrency Report

- House Judiciary Democrats, November 25, 2025, New Report Exposes the Trump Family’s Multi-Billion-Dollar Crypto Empire, Fueled by Self-Dealing and Corrupt Foreign Interests:

https://democrats-judiciary.house.gov/media-center/press-releases/new-report-exposes-the-trump-family-s-multi-billion-dollar-crypto-empire-fueled-by-self-dealing-and-corrupt-foreign-interests

- Full House Judiciary Democratic staff report, Trump, Crypto, and a New Age of Corruption:

https://democrats-judiciary.house.gov/sites/evo-subsites/democrats-judiciary.house.gov/files/evo-media-document/2025-11-24.hjc-dem-staff-report-trump-crypto-corruption-small_0.pdf

### House Financial Services Committee Democrats

- Anti-Crypto Corruption Week, including material on World Liberty Financial, foreign investment, token-sale revenue, and the Trump family's financial interests:

https://democrats-financialservices.house.gov/issues/anti-crypto-corruption-week.htm

### MELANIA Token

Market Data and Historical Performance

- CoinMarketCap, Official Melania Meme (MELANIA), price, market capitalization, supply, and historical performance:

https://coinmarketcap.com/currencies/melania-meme/

- CoinGecko, Melania Meme (MELANIA), market data and token allocation:

https://www.coingecko.com/en/coins/melania-meme

- CoinGecko, MELANIA historical price data:

https://www.coingecko.com/en/coins/melania-meme/historical_data

### $TRUMP Token

Market Data

- CoinMarketCap, Official Trump (TRUMP), price, market capitalization, supply, and market data:

https://coinmarketcap.com/currencies/official-trump/

- CoinGecko, Official Trump (TRUMP), market data:

https://www.coingecko.com/en/coins/official-trump/

### World Liberty Financial

- World Liberty Financial, official website:

https://worldlibertyfinancial.com/

- World Liberty Financial, official documentation:

https://docs.worldlibertyfinancial.com/

### and Related Business Interests

- Reuters, September 28, 2026, Democrats to probe lucrative Trump family business deals if they win midterms:

https://www.reuters.com/world/us/democrats-probe-lucrative-trump-family-business-deals-if-they-win-midterms-2026-09-28/

### Federal Financial Regulators

- Securities and Exchange Commission:

https://www.sec.gov/

- SEC, Enforcement Division:

https://www.sec.gov/enforcement-litigation

- Commodity Futures Trading Commission:

https://www.cftc.gov/

- CFTC, Enforcement Division:

https://www.cftc.gov/LawRegulation/Enforcement

- Financial Crimes Enforcement Network:

https://www.fincen.gov/

- FinCEN, Bank Secrecy Act resources:

https://www.fincen.gov/resources/statutes-regulations/bank-secrecy-act

- Internal Revenue Service:

https://www.irs.gov/

- IRS, Digital Assets:

https://www.irs.gov/businesses/small-businesses-self-employed/digital-assets

### Campaign Finance and Financial Disclosure

- Federal Election Commission:

https://www.fec.gov/

- US Office of Government Ethics:

https://www.oge.gov/

- US Department of Justice, Criminal Division:

https://www.justice.gov/criminal

### Related Financial Investigations

- Affinity Partners, official website:

https://www.affinitypartners.com/

- 1789 Capital, official website:

https://www.1789capital.com/

----

----

