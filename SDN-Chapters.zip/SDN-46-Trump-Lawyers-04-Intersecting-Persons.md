# Intersecting Persons

Organizations and persons of interest.

## Organizations

Alphabetized and deduplicated from the new article.

Abbreviations and alternate references are consolidated.

Named courts, government bodies, and political parties are included.

Unnamed organizations, investigative operations, statutes, and individual Reddit forums are excluded.

- A&O Shearman

- Apollo Global Management

- Bank of America

- Bank of New York Mellon

- Cadwalader, Wickersham & Taft

- Democratic Party

- Deutsche Bank

- Equal Employment Opportunity Commission (EEOC)

- Financial Crimes Enforcement Network (FinCEN)

- Harvard Law School

- Internal Revenue Service (IRS)

- JPMorgan Chase

- Kirkland & Ellis

- Latham & Watkins

- Louis D.

- Brandeis Center for Human Rights Under Law

- Milbank

- Nardello and Co.

- New York Appellate Division

- New York Times

- Organized Crime Drug Enforcement Task Forces (OCDETF)

- Paul, Weiss, Rifkind, Wharton & Garrison LLP

- Perkins Coie

- Reddit

- Simpson Thacher & Bartlett

- Skadden, Arps

- Sullivan & Cromwell

- Truth Social

- US Court of Appeals for the Second Circuit

- US Department of Commerce

- US Department of Justice (DOJ)

- US Department of the Treasury

- US Drug Enforcement Administration (DEA)

- US House of Representatives

- US House Committee on Oversight (House Oversight Committee)

- US House Committee on the Judiciary

- US Senate

- US Senate Committee on Finance

- US Senate Committee on the Judiciary

- US Senate Permanent Subcommittee on Investigations (PSI)

- White House / Trump administration

- Willkie Farr & Gallagher

- WilmerHale

Additional organization identifiable only in source links

- Above the Law

## Persons

Alphabetized by surname, using “Last name, First name Middle initial” where the article supplies those details.

No missing middle initials are inferred.

Affiliations reflect only the supplied article, including former positions and client relationships, and are not independently verified.

Listing an affiliation does not imply involvement in alleged wrongdoing.

- Black, Leon

  - Apollo Global Management - co-founder and former CEO/chairman.

  - Paul, Weiss, Rifkind, Wharton & Garrison LLP - client represented in Senate Finance Committee submissions.

- Blanche, Todd

  - US Department of Justice - Deputy Attorney General.

  - Donald Trump’s legal-defense team 

  - former personal criminal-defense attorney.

- Blumenthal, Richard

  - US Senate - senator from Connecticut.

  - US Senate Committee on the Judiciary

  - US Senate Permanent Subcommittee on Investigations

  - Democratic Party 

- Cole, Terrance C.

  - US Drug Enforcement Administration - administrator.

- Dershowitz, Alan

  - Harvard Law School - professor emeritus.

  - Jeffrey Epstein’s legal-defense team 

  - former criminal-defense attorney.

- Epshteyn, Boris

  - Donald Trump’s legal and political advisory team 

  - personal attorney and senior political adviser.

- Epstein, Jeffrey

  - NA

- GG, [name withheld]

  - pseudonym as a woman receiving payments from Leon Black.

- Karp, Brad

  - Paul, Weiss, Rifkind, Wharton & Garrison LLP 

  - litigation partner and former chairman.

- Maxwell, Ghislaine

  - an associate of Jeffrey Epstein.

- Raskin, Jamie

  - US House of Representatives

  - US House Committee on the Judiciary - ranking member

  - Democratic Party

- Schiff, Adam

  - US Senate - senator from California.

  - US Senate Committee on the Judiciary

  - Democratic Party

- Schwartz, Matthew

  - US Court of Appeals for the Second Circuit - judge

  - Sullivan & Cromwell - former litigation partner.

  - Donald Trump’s legal team 

  - former counsel in the New York criminal appeal.

- Trump, Donald

  - President of the United States.

- Webber, Mitchell

  - Paul, Weiss, Rifkind, Wharton & Garrison LLP - partner.

  - Louis D. Brandeis Center for Human Rights Under Law 

  - board member.

  - former Associate White House Counsel, 2019–2021.

----
 
----
