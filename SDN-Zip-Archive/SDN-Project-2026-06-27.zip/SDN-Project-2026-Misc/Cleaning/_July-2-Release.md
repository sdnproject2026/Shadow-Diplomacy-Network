# Epstein Doc Release July 2nd

# The case

A lawsuit, by independent journalist/legal commentator Katie Phang, seeks court enforcement of the Epstein Files Transparency Act, arguing the Justice Department, under Acting Attorney General Todd Blanche, did not properly comply with the law’s disclosure and unredaction requirements for certain Epstein-related records.

A judge later ordered DOJ to either release additional less-redacted/unredacted materials or explain why it can’t by a set deadline. 

## Key parties

### Plaintiff

- Katie Phang 

### Defendant

- Acting Attorney General Todd Blanche / DOJ 

### Judge

- US District Judge Emmet Sullivan 

## Timeline

### Passage of law 

- The Epstein Files Transparency Act was passed in 2025 (described as “passed…in 2025”). 

### Statutory deadline missed

- DOJ was legally required to release the materials by Dec. 19, 2025, but missed that deadline. 

### December releases

- An initial release of hundreds of thousands of pages came out in December and was described as heavily redacted. 

### January releases

- Millions of additional documents were released in January. 

### March releases

- A follow-up batch was published in March, including roughly 50,000 previously removed files that were restored after review. 

### April 2026

- Lawsuit filed

- Phang filed suit 

### Early June

- “response” deadline

- The judge directed DOJ to respond by 1 p.m. Thursday and DOJ missed that deadline. 

### June 25, 2026

- Court order

- Sullivan ordered DOJ to comply by the next Thursday. 

### Thursday, July 2, 2026

- Compliance deadline ordered

- DOJ must produce to the public the specified files (or explain why it can’t). 

## Requirements

The order covered, among other things:

- Eight emails with certain names blacked out

- A draft indictment with potential co-conspirators’ names obscured

- A 2019 email that mentions co-conspirators whose names were redacted

- Plus the requirement to release a redaction log listing each redaction made (as required by law)

- And (separately) whether DOJ must release interview notes behind certain FBI documents summarizing unverified allegations against Trump 

## Why Now

In the court’s reasoning as reported, Sullivan found Phang had standing and that FOIA wasn’t an adequate remedy here, and he treated DOJ’s failure to respond substantively to the court’s directions as effectively conceding Phang’s merits arguments in the motion. 

----

----
