# Dozens Of Chapters

Epstein + +

80 year SDN - Shadow Diplomacy Network

> Special thanks & shout-out to Bear Stearns ! ! !

## ZIP archive

Download all Markdown formatted text files

100s of files

 - https://github.com/sdnproject2026/Shadow Diplomacy Network

one-and-done

- https://sdnproject2026.github.io/Shadow Diplomacy Network

no redactions

## EFTA Files

- https://github.com/sdnproject2026/Shadow Diplomacy Network/tree/main/EFTA-Index

## Research

Each SDN Chapter Title represents one stand-alone document.

### Prescription

From research to prescription, changing the focus from "abusing" to "trafficking", and international RICO - merci French Magistrate - and the UN 'crimes against humanity' determination! 

Two very nice legal precedents!!

### Legal Strategy


- 13 Legal 14 Perps LLM Query

    - https://rentry.co/bfuppbc4

- 13 Legal 15 Perps LLM Response Perplexity

    - https://rentry.co/txx3yftp

- 13 Legal 16 Perps LLM Response Duck AI
 
    - https://rentry.co/audyoemi 

- 13 Legal 17 Perps LLM Response ChatGPT

    - https://rentry.co/5gayihtd 

### Prequel

But, on the first day...

- 00 Purpose

- 00 01 Elevator Pitch

- 00 02 Familia Wiki

- 00 03 Familia Shadows

- 00 04 List Of Names Wiki URLs

- 00 04 List Of Names

- 00 05 List Of Docs

- 00 06 Dozens Of Chapters

## History

### Ancient

- 01 Accounts

- 02 Shadows

- 02 Shadows 01 Power Pyramid

- 02 Shadows 02 Bible Study

- 02 Shadows 03 Leventine

- 02 Shadows 04 Bible Study 2026

### Recent

- 03 1940s

- 04 1950s

- 05 1960s

- 06 1970s

- 07 Next Gen

## Families

- 08 Epstein Family

- 09 Maxwell Family

- 10 Barr Family

### Kushner Family

- 11 Kushner Family

- 11 Kushner Family 01 Corruption 2026

- 11 Kushner Family 02 Charities

- 11 Kushner Family 03 Orthodox Networks

### Khashoggi Family

- 12 Khashoggi Family

## Audit Trails

### Legal

- 13 Legal

- 13 Legal 01 Zoro Ranch

- 13 Legal 02 Ruemmler 2018

- 13 Legal 03 Sex Offenders

- 13 Legal 04 Pizzagate 2026

- 13 Legal 05 No Civil Immunity

- 13 Legal 06 No Civil Immunity Epstein

- 13 Legal 07 Trafficking v Assault

- 13 Legal 08 Should Have Known

- 13 Legal 09 2007 FBI Draft Indictment

- 13 Legal 10 Watchdog Groups

- 13 Legal 11 Zoro Ranch Commission

- 13 Legal 12 Zoro Ranch Remedy

- 13 Legal 13 Lost 53 Docs

- 13 Legal 14 Perps LLM Query

- 13 Legal 15 Perps LLM Response Perplexity

- 13 Legal 16 Perps LLM Response Duck

- 13 Legal 17 Perps LLM Response ChatGPT

- 13 Legal 18 Zoro Ranch Subpoenas

- 13 Legal 19 EFTA OIG Audit

- 13 Legal 20 Phang vs Blanche

- 13 Legal 21 Trumps 1970s Mafia

- 13 Legal 22 July 2026 Subpoena

- 13 Legal 23 Massie EFTA II

- 13 Legal 24 Ossoff

- 13 Legal 25 Massie History

- 13 Legal 26 UN Epstein Crimes

- 13 Legal 27 Special Master

- 13 Legal 28 Zorro Ranch Findings 2026 08

- 13 Legal 29 EFTA Blanche

- 13 Legal 30 EFTA Blanche Persons

- 13 Legal 31 EFTA Blanche Legal Risk

- 13 Legal 32 Blanche Excusable Neglect

- 13 Legal 33 Blanche Excusable Neglect Legal Risk

- 13 Legal 34 Epstein FBI 2028 08 Legal Risk Files

- 13 Legal 35 Epstein FBI 2028 08 Legal Risk Spreadsheet

- 13 Legal 36 Epstein FBI 2028 08 Legal Charging Theory

- 13 Legal 37 Zorro Ranch Blanche

- 13 Legal 38 Blanche Excusable Neglect Contempt

- 13 Legal 39 Phang vs Blanche 2026 08

### Financial

- 14 Financial

- 14 Financial 01 Emmy Tayler

- 14 Financial 02 Bondi Wire Transfer

- 14 Financial 03 Bank SARs

- 14 Financial 04 Bank SARs - CapitolOne

## Files

### Deleted 

- 15 Deleted Files 

### Bondi

- 16 Bondi Nothing

- 16 Bondi Nothing 01 Blanche Interview

- 16 Bondi Nothing 02 Missing Serial Docs

- 16 Bondi Nothing 03 Impeachment

- 16 Bondi Nothing 04 Oversight

- 16 Bondi Nothing 05 FL Bar

- 16 Bondi Nothing 06 April 2026

- 16 Bondi Nothing 07 Blanche Perjury

- 16 Bondi Nothing 08 Wiles Cannon

## Organizations

- 17 Government Officials

- 17 Government 01 Vance Theil

- 18 Miss Teen Pageants

- 19 Eugenics

- 19 Eugenics 01 Theil Anti Christ

- 20 Heritage Foundation

## Victim Litigation

- 21 Victim Litigation

- 21 Victim Litigation 01 Lawyers

- 21 Victim Litigation 02 Farmer

- 21 Victim Litigation 03 Perp Names

- 21 Victim Litigation 04 Faith Kates

### Perjures

- 22 Perjures

## Misc

- 23 Hills Family

- 24 Russia

- 24 Russia 01 RussianGate 2016

- 25 China

- 26 Siebold Teens

- 27 Chain Reaction 2010

### Lutnick Family

- 28 Lutnick Family

- 28 Lutnick Family 02 Bribe

- 28 Lutnick Family 03 Accomplices

- 28 Lutnick Family 04 Nanny

### More Families

- 29 Zelnicek Family

- 30 More Profiles

- 31 Rothschild Family

- 31 Rothschild Family 01 Illuminati 1990s

## Evidence

- 32 FedEx Receipts

## Melania

- 33 Melania

- 33 Melania 01 History

- 33 Melania 02 Next Steps

- 33 Melania 03 Ungaro Zampolli

## Misc

- 34 Sarah Keller

- 35 Tate Brothers

- 36 Wyden 00 Final Report

- 36 Wyden 01 Final Report

- 36 Wyden 02 Final Report

- 36 Wyden 03 Final Report

- 36 Wyden 04 Final Report

- 36 Wyden 05 Final Report

- 36 Wyden 06 Final Report

- 36 Wyden 07 Final Report

- 36 Wyden 08 Final Report

- 36 Wyden 09 Final Report

- 36 Wyden 10 Final Report
  
- 37 Kyrie Yahoo Emails

- 38 Panama Papers 1970s 2020s

- 38 Panama Papers 01 LLM Query

- 38 Panama Papers 02 Master Strategy

... to be continued

----

----

