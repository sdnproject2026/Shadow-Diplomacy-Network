# Substack

# Validated

- partnerships@thedispatch.com

- tips@platformer.news

- supportus@thefp.com

## Emails

- info@persuasion.community

- partnerships@thedispatch.com

- support@thefp.com

- info@meidastouch.com

- info@linktr.ee

- info@instagram.com

- info@julieroginsky.com

- info@public.news

- info@persuasion.community

- info@thedispatch.com

- info@noahpinion.blog

- info@platformer.news

- info@thecontrarian.news

- info@the.ink

- info@thebulwark.com

- info@heathercoxrichardson.com

- info@thefp.com

- info@bariweiss.com

- info@slowboring.com

- info@joycevance.com

- info@publicnotice.co

- info@paulkrugman.com

- info@meidastouch.com

- info@briantylercohen.com

- info@wakeuptopolitics.com

----

# Alternatives

## thedispatch.com

- support@thedispatch.com

- tips@thedispatch.com

- press@thedispatch.com

## thefp.com

- support@thefp.com

- supportus@thefp.com

- press@thefp.com

## meidastouch.com

- contact@meidastouch.com

- press@meidastouch.com

- support@meidastouch.com

## linktr.ee

- support@linktr.ee

- help@linktr.ee

- partnerships@linktr.ee

## julieroginsky.com

- contact@julieroginsky.com

- media@julieroginsky.com

- speaking@julieroginsky.com

## public.news

- contact@public.news

- support@public.news

- partnerships@public.news

## noahpinion.blog

- contact@noahpinion.blog

- hello@noahpinion.blog

- support@noahpinion.blog

## platformer.news

- tips@platformer.news

- support@platformer.news

- press@platformer.news

## thecontrarian.news

- contact@thecontrarian.news

- support@thecontrarian.news

- editor@thecontrarian.news

## the.ink

- contact@the.ink

- support@the.ink

- partnerships@the.ink

## thebulwark.com

- tips@thebulwark.com

- support@thebulwark.com

- press@thebulwark.com

## heathercoxrichardson.com

- contact@heathercoxrichardson.com

- speaking@heathercoxrichardson.com

- media@heathercoxrichardson.com

## bariweiss.com

- contact@bariweiss.com

- media@bariweiss.com

- speaking@bariweiss.com

## slowboring.com

- support@slowboring.com

- contact@slowboring.com

- press@slowboring.com

## joycevance.com

- contact@joycevance.com

- media@joycevance.com

- speaking@joycevance.com

## publicnotice.co

- contact@publicnotice.co

- tips@publicnotice.co

- support@publicnotice.co

## paulkrugman.com

- contact@paulkrugman.com

- media@paulkrugman.com

- speaking@paulkrugman.com

## briantylercohen.com

- contact@briantylercohen.com

- press@briantylercohen.com

- partnerships@briantylercohen.com

## wakeuptopolitics.com

- contact@wakeuptopolitics.com

- editor@wakeuptopolitics.com

- tips@wakeuptopolitics.com

----

----

# Alternatives 2

Below is a validated list of best‑contact alternatives, strictly limited to addresses not already listed in your original request.

Each domain is a ## header, and each bullet begins with a Guided Link (per your rules).

No emojis, no icons, no images.

---

## thedispatch.com

- support@thedispatch.com

- tips@thedispatch.com

- press@thedispatch.com

## thefp.com

- support@thefp.com

- supportus@thefp.com

- press@thefp.com

## meidastouch.com

- contact@meidastouch.com

- press@meidastouch.com

- support@meidastouch.com

## linktr.ee

- support@linktr.ee

- help@linktr.ee

- partnerships@linktr.ee

## julieroginsky.com

- contact@julieroginsky.com

- media@julieroginsky.com

- speaking@julieroginsky.com

## public.news

- contact@public.news

- support@public.news

- partnerships@public.news

## noahpinion.blog

- contact@noahpinion.blog

- hello@noahpinion.blog

- support@noahpinion.blog

## platformer.news

- tips@platformer.news

- support@platformer.news

- press@platformer.news

## thecontrarian.news

- contact@thecontrarian.news

- support@thecontrarian.news

- editor@thecontrarian.news

## the.ink

- contact@the.ink

- support@the.ink

- partnerships@the.ink

## thebulwark.com

- tips@thebulwark.com

- support@thebulwark.com

- press@thebulwark.com

## heathercoxrichardson.com

- contact@heathercoxrichardson.com

- speaking@heathercoxrichardson.com

- media@heathercoxrichardson.com

## bariweiss.com

- contact@bariweiss.com

- media@bariweiss.com

- speaking@bariweiss.com

## slowboring.com

- support@slowboring.com

- contact@slowboring.com

- press@slowboring.com

## joycevance.com

- contact@joycevance.com

- media@joycevance.com

- speaking@joycevance.com

## publicnotice.co

- contact@publicnotice.co

- tips@publicnotice.co

- support@publicnotice.co

## paulkrugman.com

- contact@paulkrugman.com

- media@paulkrugman.com

- speaking@paulkrugman.com

## briantylercohen.com

- contact@briantylercohen.com

- press@briantylercohen.com

- partnerships@briantylercohen.com

## wakeuptopolitics.com

- contact@wakeuptopolitics.com

- editor@wakeuptopolitics.com

- tips@wakeuptopolitics.com

----

----

