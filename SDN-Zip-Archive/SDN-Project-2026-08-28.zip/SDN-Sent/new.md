
- press@newamerica.org

  - Valid:

    - heidi@newamerica.org

  - Alternatives:

    - kportnoy@newamerica.org

    - etavenner@newamerica.org

    - elkin@newamerica.org

- books-partners@google.com

  - Alternatives:

    - press@google.com

    - publisher-support@google.com

- CeladonBooks@macmillan.com

  - Valid:

    - contact@celadonbooks.com

  - Alternatives:

    - foreignrights@celadonbooks.com

- macmillan@macmillan.com

  - Valid:

    - press.inquiries@macmillan.com

  - Alternatives:

    - macmillan.audio@macmillan.com

    - academic@macmillan.com

- FSGPublicity@macmillan.com

  - Valid:

    - fsg.publicity@fsgbooks.com

  - Alternatives:

    - sales@fsgbooks.com

    - fsg.subrights@fsgbooks.com

- FlatironPublicity@macmillan.com

  - Valid:

    - publicity@flatironbooks.com

  - Alternatives:

    - marketing@flatironbooks.com

- TorPublicity@macmillan.com

  - Valid:

    - tpgpublicity@tor.com

  - Alternatives:

    - foreignrights@stmartins.com

- press@asc.upenn.edu

  - Valid:

    - asccomm@asc.upenn.edu

  - Alternatives:

    - ascdept@asc.upenn.edu

- press@brookings.edu

  - Valid:

    - media@brookings.edu

  - Alternatives:

    - communications@brookings.edu

- publicity@harvard.edu

  - Valid:

    - news@harvard.edu

  - Alternatives:

    - mediarelations@harvard.edu

- mediarelations@springernature.com

  - Valid:

    - press@springernature.com

  - Alternatives:

    - hsscomms@springernature.com

    - ORSupport@springernature.com

