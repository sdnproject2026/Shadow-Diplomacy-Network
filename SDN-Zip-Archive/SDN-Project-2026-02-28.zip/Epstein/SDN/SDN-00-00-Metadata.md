### SDN-00-00-Metadata

# SDN Chapter Pastes

## Note

"NA" Not Available
- failed "purity test"

Markdown formatted displays:
- <code>i</code> | https://pastes.io
- <code>i</code> | https://rentry.co

30 day expirations:
- <code>i</code> | https://pastes.io
- <code>i</code> | https://pastee.dev

55 minute expirations:
- <code>i</code> | https://privatebin.net

## Encouraging everyone to repaste !

----

SDN-00-00-FOMO-Dist-List-TOC
- <code>b</code> | PB
- <code>i</code> | PI
- <code>e</code> | PE
- <code>v</code> | PV 55min
> HASH

SDN-00-01-Elevator-Pitch
- <code>b</code> | PB
- <code>i</code> | PI
- <code>e</code> | PE
- <code>v</code> | PV 55min
> HASH

^ SDN-01-Accounts
- <code>b</code> | https://pastebin.com/VcyucMis
- <code>i</code> | https://pastes.io/sdn-01-acc (03-26)
- <code>e</code> | https://pastee.dev/p/rNXxzbY6 (03-26)
- <code>r</code> | https://rentry.co/nbxaknhn
- <code>v</code> | PV 55min
> HASH

SDN-02-Shadows
- <code>b</code> | https://pastebin.com/J3XxYXvf
- <code>i</code> | https://pastes.io/sdn-02-sha-58259 (03-26)
- <code>e</code> | https://pastee.dev/p/8xsDeDDC (03-26)
- <code>e</code> | https://rentry.co/w9nwhkwv
- <code>v</code> | PV 55min
> HASH

SDN-03-1940s
- <code>b</code> | https://pastebin.com/w478AgQk
- <code>i</code> | https://pastes.io/sdn-03-194 (03-19)
- <code>e</code> | PE NA
- <code>v</code> | PV 55min
> HASH

SDN-04-1950s
- <code>b</code> | https://pastebin.com/M2WeByzh
- <code>i</code> | https://pastes.io/sdn-04-195 (03-19)
- <code>e</code> | PE NA
- <code>v</code> | PV 55min
> HASH

SDN-05-1960s
- <code>b</code> | https://pastebin.com/UxU6d5he
- <code>i</code> | https://pastes.io/sdn-05-196 (03-19)
- <code>e</code> | PE NA
- <code>v</code> | PV 55min
> HASH

SDN-06-1970s
- <code>b</code> | https://pastebin.com/2vFgZX9Q
- <code>i</code> | https://pastes.io/sdn-06-197 (03-19)
- <code>e</code> | https://pastee.dev/p/jDmH8lUu (03-23)
- <code>v</code> | PV 55min
> HASH

SDN-07-Next-Gen
- <code>b</code> | https://pastebin.com/inEELVfc
- <code>i</code> | https://pastes.io/sdn-07-nex (03-19)
- <code>e</code> | https://pastee.dev/p/HCrEBx2z (03-23)
- <code>v</code> | PV 55min
> HASH

SDN-08-Epstein-Family
- <code>b</code> | PB NA
- <code>i</code> | https://pastes.io/sdn-08-eps (03-19)
- <code>e</code> | https://pastee.dev/p/IH7IM6ue (03-23)
- <code>v</code> | PV 55min
> HASH

SDN-09-Maxwell-Family
- <code>b</code> | PB NA
- <code>i</code> | https://pastes.io/sdn-09-max-35769 (03-21)
- <code>e</code> | https://pastee.dev/p/B8KciEcn (03-23)
- <code>r</code> | https://rentry.co/iagb9a9y- 
- <code>v</code> | PV 55min
- 
> HASH

SDN-10-Barr-Family
- <code>b</code> | https://pastebin.com/NfHE41xC
- <code>i</code> | https://pastes.io/sdn-10-bar (03-19)
- <code>e</code> | https://pastee.dev/p/AvBbdT0w (03-23)
- <code>v</code> | PV 55min
> HASH

SDN-11-Kushner-Family
- <code>b</code> | NA
- <code>i</code> | https://pastes.io/sdn-11-kus (03-23)
- <code>e</code> | https://pastee.dev/p/L9J4vEgC (03-23)
- <code>r</code> |  https://rentry.co/tcmi9dqz 
- <code>v</code> | 55min

> HASH

SDN-12-Khashoggi-Family
- <code>b</code> | https://pastebin.com/Uzm9esA0
- <code>i</code> | https://pastes.io/sdn-12-kha (03-19)
- <code>e</code> | https://pastee.dev/p/iMQlntAR (03-23)
- <code>v</code> | PV 55min
> HASH

SDN-13-Legal
- <code>b</code> | https://pastebin.com/sVWL1KcY
- <code>i</code> | https://pastes.io/legal-web- (03-26)
- <code>e</code> | PE NA
- <code>r</code> | https://rentry.co/35ymf65a
- <code>v</code> | PV 55min

> HASH

SDN-14-Financial
- <code>b</code> | PB NA
- <code>i</code> | https://pastes.io/sdn-14-fin
- <code>e</code> |  https://pastee.dev/p/2ztrcTmG (03-23)
- <code>r</code> | https://rentry.co/5m7iqgmh
- <code>v</code> | PV 55min

> HASH

SDN-15-Xd-Files
- <code>b</code> | https://pastebin.com/CpFzBq1M
- <code>i</code> | https://pastes.io/sdn-15-xd- (03-21)
- <code>e</code> | https://pastee.dev/p/gky4uUb1 (03-23)
- <code>v</code> | PV 55min
> HASH

SDN-16-Bondi-Nothing
- <code>b</code> | PB NA
- <code>i</code> | https://pastes.io/sdn-16-bon-78467 (03-26)
- <code>e</code> | https://pastee.dev/p/ZxIJk5GY (03-23)
- <code>r</code> | https://rentry.co/5z4zbk2k
- <code>v</code> | PV 55min
> HASH

SDN-17-Government-Officials
- <code>b</code> | https://pastebin.com/Aesvu68F8
- <code>i</code> | https://pastes.io/sdn-17-gov (03-19)
- <code>e</code> | https://pastee.dev/p/2HzC4z5K (03-23)
- <code>r</code> | https://rentry.co/kxcafr5k
- <code>v</code> | PV 55min

> HASH

SDN-18-Miss-Teen-Pageants
- <code>b</code> | https://pastebin.com/zcm7b1fy
- <code>i</code> | https://pastes.io/sdn-18-mis (03-19)
- <code>e</code> | https://pastee.dev/p/PFkngF6n (03-21)
- <code>v</code> | PV 55min
> HASH

SDN-19-Eugenics
- <code>b</code> | https://pastebin.com/zcm7b1fy
- <code>i</code> | https://pastes.io/eugenics-h (03-19)
- <code>e</code> | https://pastee.dev/p/79bqYTWG (03-21)
- <code>r</code> | https://rentry.co/w3q5in3h
- <code>v</code> | PV 55min

> HASH

SDN-20-Heritage-Foundation
- <code>b</code> | https://pastebin.com/BHyYYGyA
- <code>i</code> | https://pastes.io/sdn-20-her (03-24)
- <code>e</code> | https://pastee.dev/p/hySxMrdE (03-24)
- <code>r</code> | https://rentry.co/6voh95dd
- PV 55min

> HASH

^ SDN-21-Victim-Litigation
- <code>b</code> | https://pastebin.com/dWgv3teb
- <code>i</code> | https://pastes.io/sdn-21-vic
- <code>e</code> | https://pastee.dev/p/M7e0grar
- https://rentry.co/qvdg4bqc
- <code>v</code> | PV 55min
> HASH

SDN-22-Perjures
- <code>b</code> | https://pastebin.com/ap54UuJq
- <code>i</code> | https://pastes.io/sdn-22-per
- <code>e</code> | https://pastee.dev/p/8zo7ynP0
- <code>e</code> | https://rentry.co/94nnroto
- <code>v</code> | PV 55min
> HASH

SDN-23-Hills-Family
- <code>b</code> | https://pastebin.com/zpF3xqcC
- <code>i</code> | https://pastes.io/sdn-23-hil
- <code>e</code> | https://pastee.dev/p/cJA0lEtL
- <code>r</code> | https://rentry.co/edxas365
- <code>v</code> | PV 55min
> HASH

SDN-24-Russia
- <code>b</code> | https://pastebin.com/Mhg210iu
- <code>i</code> | https://pastes.io/sdn-24-rus
- <code>e</code> | https://pastee.dev/p/TOIqsf8U
- <code>e</code> | https://rentry.co/mxmsqiqv
- <code>v</code> | PV 55min
> HASH

SDN-25-China
- <code>b</code> | https://pastebin.com/AKC11TKZ
- <code>i</code> | https://pastes.io/sdn-25-chi
- <code>e</code> | https://pastee.dev/p/aeOOArQU
- <code>r</code> | https://rentry.co/apuztghf
- <code>v</code> | PV 55min
> HASH

SDN-26-Siebold-Teens
- <code>b</code> | NA
- <code>i</code> | NA
- <code>e</code> | NA
- <code>r</code> | https://rentry.co/p7vde7ks
- <code>v</code> | PV 55min
> HASH


----

----



