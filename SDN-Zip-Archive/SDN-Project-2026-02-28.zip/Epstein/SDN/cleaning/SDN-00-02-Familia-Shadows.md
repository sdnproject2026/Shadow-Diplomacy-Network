# Epstein List-of-Lists SDN

> Given this, herein, list of URL's and Wiki name list, produce a non-duplicate list of people names found in the URL pages that are not also in the Wiki name list; format last name 1st, first name 2nd, etc. Alpha sort sublists within categories.

> In Broad categories, as found in the Wiki name list, for example, group the new names by primary profession or public role, assign "Miscellaneous" names to categories via known familial or associative ties to other names listed, where applicable create new categories.

# URLs

## SDN-00-00-Metadata-Subset-02

- ASCII text content
- Markdown / HTML formatted text
- Linux EOL characters

^ SDN-08-Epstein-Family
- https://pastee.dev/p/IH7IM6ue

SDN-09-Maxwell-Family
- https://rentry.co/iagb9a9y

SDN-10-Barr-Family
- https://pastebin.com/raw/NfHE41xC

SDN-11-Kushner-Family
- https://rentry.co/tcmi9dqz

SDN-12-Khashoggi-Family
- https://pastebin.com/raw/Uzm9esA0

SDN-13-Legal
- https://pastebin.com/raw/sVWL1KcY

SDN-14-Financial
- https://rentry.co/5m7iqgmh

SDN-16-Bondi-Nothing
- https://rentry.co/5z4zbk2k

SDN-17-Government-Officials
- https://rentry.co/kxcafr5k

SDN-18-Miss-Teen-Pageants
- https://pastebin.com/raw/zcm7b1fy

SDN-20-Heritage-Foundation
- https://rentry.co/6voh95dd

SDN-23-Hills-Family
- https://rentry.co/edxas365

SDN-24-Russia
- https://rentry.co/mxmsqiqv

SDN-25-China
- https://rentry.co/apuztghf

SDN-26-Siebold-Teens
- https://rentry.co/p7vde7ks

-----

# People

## Political Figures

- Biden, Joe
- Clinton, Bill
- Clinton, Hillary
- Kennedy Jr., Robert F.
- Gore, Al
- Lavrov, Sergey
- Lajčák, Miroslav
- Mitchell, George
- Pastrana, Andrés
- Plaskett, Stacey
- Putin, Vladimir
- Bush, George W.
- Bannon, Steve
- Trump Jr., Donald
- Trump, Donald

## Royalty

- Andrew, Prince
- Charles, Prince
- Harry, Prince
- Mountbatten‑Windsor, Andrew
- William, Prince

## Business Leaders

- Black, Leon
- Bloomberg, Michael
- Branson, Richard
- Brin, Sergey
- Buffett, Warren
- Diller, Barry
- Dubin, Glenn
- Gates, Bill
- Kahn, Richard
- Lutnick, Howard
- Musk, Elon
- Pritzker, Tom
- Tisch, Steve
- Wasserman, Casey
- Wexner, Les
- Schwarzenegger, Arnold
- Richardson, Bill

## Entertainment/Media

- Alphonsi, Maggie
- Beckham, Victoria
- Bradshaw, Terry
- Campbell, Naomi
- Emanuel, Ari
- Hathaway, Anne
- Hazell, Victoria
- Jagger, Mick
- Kutcher, Ashton
- Love, Courtney
- Ratner, Brett
- Rodriguez, Alex
- Van Susteren, Greta
- Allen, Woody
- Maples, Marla
- Trump, Tiffany

## Finance/Economics

- Greenspan, Alan
- Lauder, Ronald
- Summers, Larry
- Dimon, Arthur

## Legal/Academic

- Dershowitz, Alan
- Pinker, Steven
- Weinstein, Yehuda
- Barak, Ehud

## Epstein Associates/Staff

- Brunel, Jean‑Luc
- Groff, Lesley
- Junkermann, Nicole
- Juul, Mona
- Maxwell, Ghislaine
- Rodgers, Kristy
- Rodgers, Patsy
- Loffredo, Abigail
- Loria, Joseph
- Mullen, David
- Pagano, Joe
- Pigozzi, Jean
- Poole, Christopher
- Previn, Soon‑Yi
- Refregier, Laszlo
- Sawyer, Forest
- Nsumdi, Augustine

----

----
