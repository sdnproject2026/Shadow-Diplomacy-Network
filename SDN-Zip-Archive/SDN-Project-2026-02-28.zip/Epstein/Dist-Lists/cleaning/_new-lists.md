### _new-lists

SDN-00-22-FOMO-Dist-List-Deans-Poly-Sci
- University deans poly sci


SDN-00-23-FOMO-Dist-List-Book-Authors
- History book bibliography / authors


SDN-00-24-FOMO-Dist-List-Kirland
- Kirland officers partners era years


SDN-00-25-FOMO-Dist-List-Bear-Sterns
- Bear officers partners era years


SDN-00-26-FOMO-Dist-List-JP-Morgan
- JP Morgan officers partners era years


SDN-00-27-FOMO-Dist-List-Billionaires
- Billionaires

----

----
