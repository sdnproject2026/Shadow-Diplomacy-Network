Elizabeth G. "Liz" Oyer is a former Department of Justice (DOJ) official who served as the U.S. Pardon Attorney. She is currently a legal commentator and the creator of "Lawyer Oyer," a digital media platform including a website (lawyeroyer.com) and social media channels where she discusses the rule of law and federal legal actions.

### Professional Events

-  2002 – 2012

Partner at Mayer Brown LLP: Practiced civil and criminal litigation at the trial and appellate levels and maintained an active pro bono practice.

-  2012 – 2022

Senior Litigation Counsel for the Federal Public Defender: Represented indigent defendants in the District of Maryland across a wide range of federal criminal cases and served as the office's ethics advisor.

-  April 2022

Appointed as United States Pardon Attorney: Became the first former public defender to lead the Office of the Pardon Attorney, responsible for advising the President on clemency, pardons, and commutations.

-  March 7, 2025

Termination from the Department of Justice: Removed from her position as Pardon Attorney by the administration, an event she later testified was retaliatory.

-  April 7, 2025

Congressional Testimony: Appeared before members of the House and Senate Judiciary Committees to provide a statement on accountability and perceived attacks on the rule of law within the DOJ.

-  August 15, 2025

Legal Challenge to Removal: Filed a legal brief with the Merit Systems Protection Board (MSPB) challenging her termination as an unlawful removal of a career Senior Executive Service member.

-  October 23, 2025

Bodiker Lecture Speaker: Delivered a lecture at the Moritz College of Law regarding her tenure overseeing more than 15,000 clemency cases and reforming the application process.

-  February 13, 2026

Presidential Pardon Power Panelist: Participated in a Miller Center event discussing the constitutional exercise of executive clemency and the role of the Pardon Attorney.

## Sources


- https://www.justice.gov/archives/pardon/staff-profile/former-pardon-attorney-oyer


- https://www.lawyeroyer.com/


- https://www.schiff.senate.gov/wp-content/uploads/2025/04/20250407-Liz-Oyer-Hearing-Statement-4.7.25.pdf


- https://democracyforward.org/news/press-releases/liz-oyer-doj/


- https://millercenter.org/news-events/events/presidential-pardon-power

# Questions

What are the primary responsibilities of the Office of the Pardon Attorney within the DOJ?

How does the Senior Executive Service (SES) protect career federal employees from political termination?

What is the process for a federal prisoner to apply for a commutation of sentence?

What legal arguments were presented in the brief filed with the Merit Systems Protection Board regarding Oyer's removal?

How has the clemency application process changed between 2022 and 2025?