## Department of Justice

### Emails

General US Department of Justice information and program inquiries

-  askdoj@usdoj.gov  

DOJ Office of Public Affairs

including OCDETF and its Fusion Center

-  press@usdoj.gov  

Main DOJ “Contact” portal:

- https://www.justice.gov/contact-us  

## The Drug Enforcement Administration 

(DEA) 

The primary federal agency responsible for enforcing US controlled substance laws and dismantling major drug trafficking and related criminal organizations.

It operates under the Department of Justice, runs domestic and international offices, and conducts intelligence-driven investigations, seizures, and prosecutions in partnership with other federal, state, local, and foreign authorities.

The DEA focuses on disrupting drug supply chains, targeting cartels and large trafficking networks, and combating diversion of legal pharmaceuticals into illegal markets.

### Emails

Drug Enforcement Administration 

(DEA)

General information: 

- info@dea.gov  

Public affairs / media: 

- dea.public.affairs@usdoj.gov  

Community outreach / education:

- community.outreach@dea.gov  

General contact page:

-  https://www.dea.gov/who-we-are/contact-us  

## Organized Crime Drug Enforcement Task Forces

(OCDETF)

The Organized Crime Drug Enforcement Task Forces (OCDETF) program is a Justice Department framework that coordinates multi-agency, prosecutor-led investigations against major drug trafficking, money laundering, and transnational organized crime networks.

It supports complex, long-term cases by bringing together agencies such as DEA, FBI, and Homeland Security Investigations, along with federal prosecutors, to target high-impact criminal organizations and their financial infrastructure.

## OCDETF Fusion Center

The OCDETF Fusion Center in Virginia serves as a centralized intelligence and data hub within the OCDETF framework.

It aggregates and analyzes drug and drug-related financial information from multiple federal agencies and databases to support active investigations.

By performing cross-agency data fusion, link analysis, and identification of key organizational targets, the OCDETF Fusion Center helps investigators build comprehensive pictures of high-priority criminal networks and generate actionable leads for coordinated enforcement operations.

-----