# 2016 Business Proposition

## Ramsey Elkholy

The email thread is an authentic document.

It was unsealed and released by the U.S. Department of Justice (DOJ) as part of a massive trove of investigative files.

## OCR

```

From: "jeffrey E." <jeevacation@gmail.com>

To: Ramsey Elkholy

Subject: Re: Info

Date: Sun, 02 Oct 2016 19:54:24 +1000

Ok

On Sunday, 2 October 2016, Ramsey Elkholy

wrote

Ok will meet w him tomorrow, he's preparing a nda. Wed should work but in case I end up swamped.on.my

first day back are you around Thur as well? Wed should be ok tho...

Sent from my iPhone

On Oct 2, 2016, at 5:52 AM, jeffrey Erevanion@gmail.com wrote:

you can sign thie oda and get ford numbers, i ain around on wed if you have time in new york

On Sun, Oct 2, 2016 at 3-43 AM. Ramsey Elkholy <

Hey Jeffrey, here's some preliminary info

wrote:

For the contest they need about 500% USD to do it right, basically the same way Elite did it when it was called the Elue Model Look comest. 9 months, 30-40 cities, something like 200,000 girls, which then narrows down 10 10.000, then 1,000, then 100 etc Mach of the $ goes to tv advertising, venues, the "finals" which is a huge event, etc. They basically scour the country anal tms of girls show us. That's how they discovered mist of the top Humzilian models that made in big in NY. They are saying they have 50% of the S from advertisers, so hasically you can have the contest for 250k, This would involve havmg access 10 all the girls, which you can decide what to do with. It's nawe that thr winner of these contests goes on to make it big, it's usually mother overlooked girl, which is why I like this for you I mean. You could basically fly these gris to wherever in the US (there's a Brudlin agency that does the US vums), or Parve or Caribbean. You can get more info from the PDF Iseni you and I have the 5 breakdown which I can send you if you're umerested in exploring this finiber. Just wanted to get you a mumber and let you know that t met with the two man organizers and they are well known scouts contest organizers im Brazil. It's basically the same contest as the Elite Model Look but they need to change the name because they don't own Elite anymore.

Models: they are the biggest in Brazil now and following in the footsteps of IMG world ar ler's say Mi world as a prototype: representing top athieres, actors, sponsoring fashion weeks, as well as model. They Imve about 120 out of their 300 models workmg outside Brazil now in foreign The other big agencies are Mega and Way, both with wealthy sponsors befund them, so they don't the uvestment. Ford is run by one gay and he has never had mvestors. He expressed to me that e open to having some backing so he can fully restize the agency's goals-witich is to become Brazil He has some good ideas, like an app they have developed for models to submt to the agency, so instead of traviching all the way to SP girls from any part of Brazil can uplo the app, III in the personal info section and just hit send: Ue ackoowledges that the reinvent itself and based on my other meetings with other agency owners he seemed 87 together (good friends w. Kady Fond been in the busitiess for 30+ years, etc) This vestiment if you weamied to build on an already established brand, anil of counse many set models, but I guess not the same direct access as the content, where the girls are pkms and not experienced models. He wouldn't give me a omber without an NDA t SD you could own a sizablu chunk. I'm not sure you want to owa 100% of any аgепсy...

```

## OCR Cleaned

```

From: "Jeffrey E." <jeevacation@gmail.com>

To: Ramsey Elkholy

Subject: Re: Info

Date: Sun, 02 Oct 2016 19:54:24 +1000

Ok.

On Sunday, 2 October 2016, Ramsey Elkholy wrote:

Ok, will meet with him tomorrow, he's preparing an NDA.

Wednesday should work, but in case I end up swamped on my first day back, are you around Thursday as well?

Wednesday should be ok though.

Sent from my iPhone.

On Oct 2, 2016, at 5:52 AM, jeffrey <Erevanion@gmail.com> wrote:

You can sign the NDA and get Ford numbers, I ain't around on Wednesday if you have time in New York.

On Sun, Oct 2, 2016 at 3:43 AM, Ramsey Elkholy wrote:

Hey Jeffrey, here's some preliminary info.

For the contest they need about 500k USD to do it right, basically the same way Elite did it when it was called the Elite Model Look contest.

Nine months, 30–40 cities, something like 200,000 girls, which then narrows down to 10,000, then 1,000, then 100, etc.

Much of the money goes to TV advertising, venues, the finals, which is a huge event, etc.

They basically scour the country and tons of girls show up.

That's how they discovered most of the top Brazilian models that made it big in NY.

They are saying they have 50% of the funding from advertisers, so basically you can have the contest for 250k.

This would involve having access to all the girls, which you can decide what to do with.

It's rare that the winner of these contests goes on to make it big, it's usually another overlooked girl, which is why I like this for you.

I mean, you could basically fly these girls to wherever in the US (there's a Brazilian agency that does the US visas), or Paris or the Caribbean.

You can get more info from the PDF I sent you, and I have the full breakdown which I can send you if you're interested in exploring this further.

Just wanted to get you a number and let you know that I met with the two main organizers and they are well-known scouts and contest organizers in Brazil.

It's basically the same contest as the Elite Model Look, but they need to change the name because they don't own Elite anymore.

### Models

they are the biggest in Brazil now and following in the footsteps of IMG, let's say IMG Worldwide as a prototype, representing top athletes, actors, sponsoring fashion weeks, as well as models.

They have about 120 out of their 300 models working outside Brazil now in foreign markets.

The other big agencies are Mega and Way, both with wealthy sponsors behind them, so they don't need investment.

Ford is run by one guy and he has never had investors.

He expressed to me that he's open to having some backing so he can fully realize the agency's goals, which is to become the top in Brazil.

He has some good ideas, like an app they have developed for models to submit to the agency, so instead of traveling all the way to São Paulo, girls from any part of Brazil can upload through the app, fill in the personal info section, and just hit send.

He acknowledges that the industry needs to reinvent itself, and based on my other meetings with other agency owners, he seemed very together (good friends with Katie Ford, been in the business for 30+ years, etc.).

This investment, if you wanted to build on an already established brand, would of course include many set models, but I guess not the same direct access as the contest, where the girls are unknown and not experienced models.

He wouldn't give me a number without an NDA, but said you could own a sizable chunk.

I'm not sure you want to own 100% of any agency...

```

## Business Proposition

The "business proposition" described within the email was highly misleading. The underlying intent of the proposal was a facade.

## Who the People Are

### "jeffrey E."

- (jeevacation@gmail.com)

- He frequently used "jeevacation" and other pseudonyms for his private communications.

### Ramsey Elkholy

- A U.S.-based model agent, anthropologist, and musician.

## Behind the Email

While the email frames the $250,000 request as a legitimate investment into a Brazilian modeling contest or an acquisition of a Ford Models license, investigative records and lawsuits paint a completely different picture:

### The Business Was a Cover

- Released DOJ emails show that Elkholy and Epstein corresponded for nearly a decade. They used the guise of investing in fashion, pageants, and modeling agencies in Brazil primarily to secure what Elkholy described in a subsequent December 2016 email as a "steady stream" of young women for Epstein.

### The Agencies Denied Involvement

- When these files were made public, the owners of the modeling agencies mentioned in the wider correspondence (including the head of Ford Models Brazil) stated unequivocally that their businesses were never for sale, and they had absolutely no contact with Epstein or his intermediaries.

He claimed he was "star-struck" by Epstein's orbit and was unaware at the time of the true extent of Epstein's sexual predation and manipulation.

## Sources

- https://www.bbc.com/news/articles/cm2kn7nj00ro

- https://www1.folha.uol.com.br/internacional/en/world/2026/02/epstein-discussed-buying-a-modeling-agency-in-brazil.shtml

- https://www.valimail.com/blog/3-fast-facts-about-sender-identity-and-email/

- https://www.miamiherald.com/news/local/article315791782.html

- https://www.oklahoman.com/story/news/2026/02/09/jeffrey-epstein-files-released-oklahoma/88537306007/

----

# Dates

## 2016-10-02

- Email exchange between Ramsey Elkholy and Jeffrey Epstein regarding a proposed Brazilian modeling contest and potential investment

- Elkholy states he is meeting an unnamed agency representative and that an NDA is being prepared

- Discussion references a proposed modeling contest requiring approximately $500,000 USD, with advertisers allegedly covering half the cost

- Discussion includes possible investment interest in Ford Models operations in Brazil and access to prospective modeling talent

## 2016-12

- According to the analysis provided, later correspondence allegedly described the modeling and agency discussions as a means of obtaining a "steady stream" of young women for Epstein

## 2026-02

- News reports cited in the analysis discuss the public release and interpretation of the email correspondence and related investigative records

# Entities

### Ramsey Elkholy

- Recipient and author within the email chain

- Presented information regarding a Brazilian modeling contest and possible investment opportunities

- Described meetings with modeling agency operators and contest organizers in Brazil

### Jeffrey Epstein

- Sender and recipient within the email chain

- Discussed signing an NDA and obtaining financial information relating to Ford

- Identified in the analysis as the ultimate target of the business proposal

### Ford Models

- Discussed as a potential investment opportunity

- Allegedly open to outside backing according to the email

- Mentioned as seeking growth within the Brazilian modeling market

### IMG

- Described as representing athletes, actors, and models

### Mega Model Brasil

- Identified as a major Brazilian agency

- Described as already having substantial financial backing

### Way Model Management

- Identified as a major Brazilian agency

- Described as having wealthy sponsors and not requiring investment

### Katie Ford

- Mentioned as a friend of the Ford representative discussed in the email

### United States Department of Justice

- Identified in the analysis as the agency that released the email records

# Associates

### Ramsey Elkholy

Jeffrey Epstein

- Email correspondent and intended recipient of the proposal

Katie Ford

- Mentioned as a professional acquaintance connected to Ford Models

United States Department of Justice

- Released records containing the correspondence

### Jeffrey Epstein

Ramsey Elkholy

- Long-term correspondent according to the analysis

Ford Models

- Discussed as a potential investment target

United States Department of Justice

- Released investigative files containing the emails

### Katie Ford

Ford Models

- Associated through family and business leadership history

Ramsey Elkholy

- Mentioned her in describing industry relationships

IMG

- Operates in the broader fashion and talent-management industry

# Opinions

### Primary Sources

- BBC reporting on the released correspondence and reactions to it

- Folha de S.Paulo reporting on discussions involving Brazilian modeling agencies

- Miami Herald reporting on investigative and legal developments

### Secondary Sources

- Public commentary and discussion forums interpreting the released records

- Independent blogs and commentators reviewing the correspondence and related allegations

# Sources

- https://www.bbc.com/news/articles/cm2kn7nj00ro

- https://www1.folha.uol.com.br/internacional/en/world/2026/02/epstein-discussed-buying-a-modeling-agency-in-brazil.shtml

- https://www.valimail.com/blog/3-fast-facts-about-sender-identity-and-email

- https://www.miamiherald.com/news/local/article315791782.html

- https://www.oklahoman.com/story/news/2026/02/09/jeffrey-epstein-files-released-oklahoma/88537306007

# Questions

What evidence exists beyond this email to support or contradict the stated business proposal?

How did the Brazilian modeling agencies respond after the correspondence became public?

What role did NDAs play in the discussions described in the email chain?

Which individuals mentioned in the released records were confirmed participants versus subjects of discussion?

How do investigative records characterize the relationship between Ramsey Elkholy and Jeffrey Epstein over time?

----

# Answers

### What evidence exists beyond this email to support or contradict the stated business proposal?

- The email itself presents a modeling contest and agency investment proposal

- Subsequent correspondence described in the analysis allegedly characterized the effort as a means of obtaining access to young women for Jeffrey Epstein

- Public statements from individuals associated with Brazilian modeling agencies reportedly contradicted the notion that their businesses were for sale or involved in negotiations

### How did the Brazilian modeling agencies respond after the correspondence became public?

- According to the analysis, representatives of agencies mentioned in the correspondence denied involvement

- Agency figures reportedly stated they had no direct dealings with Epstein

- They also reportedly denied that their agencies were being offered for sale

### What role did NDAs play in the discussions described in the email chain?

- NDAs were described as a prerequisite for receiving financial details and ownership information

- The correspondence suggests certain business figures would not disclose valuation or investment terms without a signed NDA

- The NDA appears to have functioned as a confidentiality mechanism during exploratory discussions

### Which individuals mentioned in the released records were confirmed participants versus subjects of discussion?

- Confirmed participants in the email chain include Ramsey Elkholy and Jeffrey Epstein

- Individuals associated with modeling agencies were discussed but are not shown as participants in the quoted email

- Katie Ford is mentioned as part of industry context rather than as a participant in the correspondence

### How do investigative records characterize the relationship between Ramsey Elkholy and Jeffrey Epstein over time?

- The analysis states that they corresponded over a period of years

- Their communications reportedly involved discussions related to modeling, fashion, pageants, and talent recruitment

- Later investigations examined whether some of those business discussions served purposes different from those explicitly described in the emails

----

# Primary Documents

The underlying correspondence appears to originate from U.S. Department of Justice document releases. Public reporting indicates the emails were part of a large DOJ file release, but the complete DOJ archive is distributed across multiple document sets rather than a single consolidated public webpage. Reports discussing the specific correspondence include:

- https://www1.folha.uol.com.br/internacional/en/world/2026/02/epstein-discussed-buying-a-modeling-agency-in-brazil.shtml

- https://www1.folha.uol.com.br/mundo/2026/02/epstein-discutiu-compra-de-agencia-de-modelos-do-brasil-para-ter-acesso-a-garotas.shtml

- https://www.oklahoman.com/story/news/2026/02/09/jeffrey-epstein-files-released-oklahoma/88537306007/

# Secondary Documents

- https://ca.news.yahoo.com/agent-begged-epstein-sex-model-004201756.html

- https://www.yahoo.com/news/articles/agent-begged-epstein-sex-model-004201756.html

- https://www.aol.com/news/model-agent-begged-epstein-sex-105655023.html

- https://www.digitalmusicnews.com/2026/02/10/musician-ramsey-elkholy-monotronic-epstein-emails/

- https://www.metropoles.com/mundo/arquivos-epstein-empresario-negociou-com-agencia-de-modelos-no-brasil

# Citations

Where Ramscy Or Ramsey Elkholy Is Mentioned

- Folha identifies Ramsey Elkholy as a musician and anthropologist who was previously described in a Wall Street Journal investigation as having introduced several women to Jeffrey Epstein

- The October 2016 emails discussed Brazilian modeling agencies, including Ford Models, and were exchanged between Elkholy and Epstein according to the released files

- BBC reporting summarized in Yahoo states that Ramsey Elkholy and Epstein corresponded for almost a decade regarding models and women introduced through the modeling industry

- Elkholy reportedly told the BBC that he regretted his language and association with Epstein and said he had not understood the extent of Epstein's abuse at the time

## Ramsey Elkholy

### Identity

- Full name commonly reported as Ramsey Elkholy

- American model agent during the 2000s and 2010s

- Anthropologist

- Musician, songwriter, and producer

### Academic Background

- Holds a PhD in Anthropology

- Conducted fieldwork among the Orang Rimba people of Sumatra, Indonesia

- Author of the anthropology book "Being and Becoming: Embodiment and Experience Among the Orang Rimba of Sumatra"

### Music Career

- Founder and frontman of the band Monotronic

- Works as a guitarist, producer, and songwriter

- Describes his music as influenced by anthropology, travel, and field research experiences

### Modeling Industry

- Worked as a model agent

- Appears in released correspondence concerning models, agencies, and talent recruitment

- Was identified in reporting as having introduced women to Epstein through modeling-industry connections

# Current Status

## 2026

- Publicly active as a musician and leader of Monotronic

- Public reporting in 2026 focused heavily on newly released DOJ correspondence involving Jeffrey Epstein and Elkholy

- Through statements reported by the BBC, Elkholy expressed regret regarding his association with Epstein and stated that he did not understand the full extent of Epstein's conduct at the time of the correspondence

- No source located during this search indicates that Elkholy has been criminally charged in connection with the correspondence discussed in the cited reports as of the referenced 2026 publications

    - https://www1.folha.uol.com.br/internacional/en/world/2026/02/epstein-discussed-buying-a-modeling-agency-in-brazil.shtml "Epstein Discussed Buying a Modeling Agency in Brazil - 05/02/2026 - World - Folha"

    - https://ca.news.yahoo.com/agent-begged-epstein-sex-model-004201756.html "Agent begged Epstein to have sex with model, emails show - Yahoo News Canada"

    - https://gravatar.com/ramseyelkholy "Ramsey Elkholy | New York | Guitarist, Producer, So..."

##  Source Material 
 
Discussing the October 2016 proposal, the alleged ulterior motive, and later communications between Ramscy (Ramsey) Elkholy and Jeffrey Epstein includes:

### Primary reporting

- https://www1.folha.uol.com.br/internacional/en/world/2026/02/epstein-discussed-buying-a-modeling-agency-in-brazil.shtml

- https://www1.folha.uol.com.br/mundo/2026/02/epstein-discutiu-compra-de-agencia-de-modelos-do-brasil-para-ter-acesso-a-garotas.shtml

- https://www.metropoles.com/mundo/arquivos-epstein-empresario-negociou-com-agencia-de-modelos-no-brasil

- https://jornaldebrasilia.com.br/noticias/mundo/epstein-discutiu-compra-de-agencia-de-modelos-do-brasil-para-ter-acesso-a-garotas/

### Document References

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00816365.pdf

###  Later Communications

Reporting and investigations referencing

- https://www.bbc.com/news/articles/cm2kn7nj00ro

- https://www.miamiherald.com/news/local/article315791782.html

- https://www.oklahoman.com/story/news/2026/02/09/jeffrey-epstein-files-released-oklahoma/88537306007/

Sources specifically discussing later Elkholy-Epstein communications

- https://epsteinexposed.com/news/the-model-and-the-morgue-korshunova-elkholy-epstein

- https://www.thesun.co.uk/news/38659324/modelling-agent-begged-epstein-try-model-in-bed/

### Key allegations 

reported about later communications include:

- Folha reported that released emails concerning Brazilian modeling agencies and contests were interpreted by investigators and journalists as potentially providing access to young women rather than representing a straightforward business investment. 

- Metrópoles reported that documents were interpreted as showing interest in agency acquisitions "to have access to girls," citing released correspondence involving Ramsey Elkholy and Epstein. 

- The Epstein Exposed article cites later November 2016 and January 2017 communications allegedly discussing acquisitions of modeling agencies and maintaining a "steady stream of fresh new faces." That article is an advocacy/investigative site rather than a mainstream news organization, so its claims should be independently verified against underlying documents where possible. 

- Additional reporting in 2026 described a broader pattern of correspondence between Elkholy and Epstein over many years involving introductions of women, modeling-industry contacts, and discussions about recruiting talent. 

### Important distinction

- Public reporting contains allegations, interpretations, and investigative conclusions regarding intent. 

- I am not aware of any public court finding specifically concluding that the October 2016 Brazilian contest proposal itself became an operational trafficking venture.

- The strongest publicly reported claim is that investigators and journalists interpreted the modeling-agency and contest discussions as part of a broader effort to obtain access to young women, based on later communications and the wider body of released emails. 

## Sources

- https://www1.folha.uol.com.br/internacional/en/world/2026/02/epstein-discussed-buying-a-modeling-agency-in-brazil.shtml

    -  "Epstein Discussed Buying a Modeling Agency in Brazil - 05/02/2026 - World - Folha"

- https://www.metropoles.com/mundo/arquivos-epstein-empresario-negociou-com-agencia-de-modelos-no-brasil

    -  "Arquivos Epstein: empresário negociou com agência de modelos no Brasil"

- https://epsteinexposed.com/news/the-model-and-the-morgue-korshunova-elkholy-epstein

    -  "The Model and the Morgue: How the Man Who Handled Ruslana Korshunova's Estate Became Epstein's Chief Procurer - Epstein Exposed | Epstein Exposed"

- https://www.thesun.co.uk/news/38659324/modelling-agent-begged-epstein-try-model-in-bed/

    -  "Modelling agent told Epstein about girl 'desperate for cash' as he begged paedo to 'try her in bed', emails show"

- https://www1.folha.uol.com.br/mundo/2026/02/epstein-discutiu-compra-de-agencia-de-modelos-do-brasil-para-ter-acesso-a-garotas.shtml

    -  "Epstein discutiu compra de agência Ford Models do Brasil - 04/02/2026 - Mundo - Folha"

----

----

