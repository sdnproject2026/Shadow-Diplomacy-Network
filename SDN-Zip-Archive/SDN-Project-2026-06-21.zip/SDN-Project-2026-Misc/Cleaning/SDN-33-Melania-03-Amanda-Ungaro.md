It's out! The interview that will begin to tear down the Trumps!

Amanda Ungaro: From sharing soirées with the Trumps to being deported by ICE 

The former Brazilian model and ex-ambassador to the United Nations speaks in an interview about her expulsion from the United States, which she attributes to maneuvers by her former partner, and about a flight on Epstein’s plane. 

Naiara Galarraga Gortázar
Rio de Janeiro - APR 12, 2026 - 00:00 EDT

After spending nearly half her life in the United States, 41-year-old Brazilian Amanda Ungaro was deported from the country last October. She endured three hellish months in a detention center until she was expelled, like more than 600,000 immigrants since Donald Trump returned to the White House in January 2025 and set out to carry out “the largest deportation in history.”

What is unusual in the case of this former model who worked at the United Nations is that, alongside her former partner and the father of her son, businessman Paolo Zampolli, Ungaro had in the past shared evenings with the Trumps at the family’s Mar-a-Lago mansion, including a party to ring in 2022, which she now recalls as one of those “incredibly boring six-hour events.”

The two couples also spent other New Year’s Eves together, a White House Easter children’s party, a Fourth of July celebration… All meticulously documented on Instagram by Zampolli, the man who introduced Melania to the president and who was appointed special envoy for global partnerships by his friend. The Brazilian woman and the Italian American, who separated in 2023 after two decades together, are engaged in a bitter custody battle over their 16-year-old son, G.

“Now it’s war. We’ll see who wins. I kept quiet for years, and because of that, people judge me. They ask me, why are you speaking now? Because the man would not let me live in peace! I tried. I left the relationship with nothing, left my son at boarding school, and went to work,” Ungaro said last Tuesday in an interview at her new home, a penthouse in Rio de Janeiro. “It was not enough for him to destroy me during 20 years of relationship: he wanted to destroy me again when I started a new life, when I got married.”

Ungaro left New York and Washington behind. Having settled in Aventura, Florida, with her husband, everything fell apart last June. “Ten police officers stormed into our home, arrested me, and took my son to the police station,” she says. She and her husband, a Brazilian doctor, were arrested and charged with fraud at a cosmetic clinic following anonymous tips. She denies the charges, emphasizing that her deportation from the U.S. prevented her from defending herself. She insists that “the truth will come to light.” They put her in a cell, “with child murderers!” “Me, who has no criminal record. I was terrified,” she recalls.

When Zampolli learned that his ex-girlfriend was being held in custody, he contacted a senior official at U.S. Immigration and Customs Enforcement (ICE) so that she would remain jailed and be deported, thereby allowing him to secure the custody of their son that he had long sought, according to The New York Times. ICE complied with his request. Zampolli, reached by phone by EL PAÍS, denies any wrongdoing.

Deportation
Handcuffed at the hands and feet, she was transferred to an immigration detention center in Miami, where she spent three and a half months in complete horror. Her husband, who had a green card (permanent residency permit), was released. “I volunteered to scrub the floors at six in the morning so I wouldn’t go crazy. I spent the whole day crying; I read the Bible from beginning to end,” she says. She helped others, sharing with them her phone credit to make calls. She claims that there were detainees with residency permits, an octogenarian handcuffed in a wheelchair, and a young woman who had just lost a baby and had to wait a long time to receive medical care…

To proceed with the deportation, she was taken to Louisiana. “It was a hall with more than 120 people, the floor was wet, there were no windows, four days without seeing the sun… I came out infested with lice,” she recounts. She landed in Brazil wearing the prison uniform, with nothing, not even a cell phone. “I spent a month depressed in a room.”

Ungaro regrets not having left Zampolli sooner — and not having reported him. “I was living at the mercy of a sick psychopath who abused me psychologically, sexually, and physically. I asked many people for help. No one ever helped me. But I couldn’t leave without my son, and he would not sign [the authorization],” she says.

Zampolli denies the allegations: “I made her an [alternate] ambassador; we were invited to the White House… What kind of abuse is that? We had a telenovela-style relationship — a very toxic one,” he says.

Ungaro had left her hometown of Londrina, Brazil, at the age of 13 to become a model. She traveled extensively: São Paulo, Milan, Germany, Japan, South Korea… At first, her mother accompanied her, but she soon struck out on her own and set her sights on making it big in New York.

A flight with Epstein
In 2002, when she had not yet turned 17, she flew from Paris to New York on the Lolita Express, the private plane of convicted sex offender Jeffrey Epstein. “My agent told me, ‘We’re going with a couple of friends, a private plane just for us.’ There were around 30 very young women there, 14, 15, 16 years old. I said, ‘What is this?’ And he replied, ‘Don’t worry.’” That is how she recalls a trip she first revealed to the Brazilian newspaper O Globo.

Ungaro claims that she didn’t interact with anyone on the flight, except to greet the hosts, Epstein and Ghislaine Maxwell, his accomplice, who is currently serving a sentence for sex trafficking. “Amanda, let me introduce you to Jeffrey,” her agent said. “He came over and asked, ‘Where are you from? How old are you? Which modeling agency do you work for?’ And he introduced me to Ghislaine.” She claims she never saw Epstein again; he was found dead in his cell in 2019. The same fate befell the modeling agent who put Ungaro on that plane, Jean-Luc Brunel, who was arrested in connection with the Epstein case and died in a Parisian prison in 2022.

United Nations
When she became a mother in 2010, she left the fashion industry. Her husband secured her a position at the United Nations, where, for a few years, she served as a diplomat for the island of Grenada, and he represented another small Caribbean island: Dominica. That’s where their titles as ambassadors come from. Two tiny countries, each with barely 100,000 inhabitants, that each hold one vote at the U.N. — just like China.

“At first, I didn’t understand anything. But I started making contacts, building a professional network. And it went very well for me,” she recalls. She appears in U.N. documents as Grenada’s representative in sessions on the International Criminal Court or the Nuclear Non-Proliferation Treaty.

She exchanged her model visa for a tax-exempt diplomatic passport. At the time, Zampolli preferred that his then-girlfriend retain that status because it was more advantageous from a tax perspective, according to an apparent out-of-court settlement to which this newspaper has had access. “Paolo used to tell me, ‘Wait for Trump to win the election [for the second time], and we’ll sort out your papers and he’ll give you an American passport,’” she says.

After several years with an expired residence permit, Ungaro was applying for a visa linked to her husband, the doctor, when she was arrested. He remains in Florida, trying to reach a legal settlement.

Zampolli, a well-known figure in New York’s nightlife scene for decades, was the owner of ID Models. And in that milieu, he occasionally crossed paths with Epstein. His name is mentioned a handful of times — in press clippings and an email he sent to the sex offender via a third party with a link to a luxury magazine — among the millions of documents released by the U.S. Department of Justice. Zampolli told The New York Times that they were not close.

The sun is setting over Rio de Janeiro as Ungaro finishes recounting her story, with all the countless twists and turns of the legal cases she is dealing with, including the bitter custody battle over her teenage son. While she continues to hold endless meetings with her lawyers, she dreams of reuniting with him and with her husband.

It is time for the photographs. She puts on her jacket, slips into a pair of heels, and poses with a serious expression.

----

If you wonder why Melania gave a speeeeeeech about Epstein and threatened retribution against those who post about her, let me help you decode this considering I work on brain decoding and I have been with many models, supermodels, actresses and beauty queens whose brains often appear brand new for lack of use, and I know how they think, or at times, don’t, and speak. Look at what former model and former Grenada Ambassador to the UN, Amanda Ungaro, whose ex, Paolo Zampolli, a former modeling agency executive and current Presidential envoy, successfully lobbied the Trump administration to have deported by ICE while she was in a custody battle with him, has been posting just hours before Melania’s statement. It looks like she is about to tell Melania and Donald’s couple’s origin story and more, beyond what is in the files, and has the receipts. Zampolli is said to have introduced Trump to Melania in New York, but the Epstein files point to them having met via Epstein during a weekend in Palm Beach, in which case, Amanda is about to blow the cover off and then some. Melania may be pointing to Congress where Zampolli said, after Melania’s speech, he would be willing to testify under oath, to suppress Amanda, knowing she will not come back to the USA during her husband’s administration to give sworn testimony, but she can do so remotely, as well as go public now, especially if Trump’s goons on Capitol Hill block her. It looks like, if she plays her cards right, and extremely fast, and does not use her leverage to have Trump pressure Zampolli regarding their custody battle to have her kid back, and avoids high floors, she is about to do to Melania & co., what I did in 2025 to Elon (who I warned when I fired him in 2021 that if anything happened to me, my lawyers around the world had standing instructions to release a lot of materials about him*): brutally rip the mask off. It should be noted that Amanda made her remarks hours after a book alleging Melania had had sex with Epstein a year before she started going out with Donald Trump came out, a book which Melania has very much fought against and against which she needs both Zampolli’s backing, and, given her threats, Amanda’s silence: https://www.instagram.com/reel/DW7e6_PlYE8/?igsh=NTc4MTIwNjQ2YQ== 
——————————————————————————

*Stop telling me to “do it”. Catch up if you obviously missed a couple of episodes. While I made it public in 2021 that I fired him, there was no election interference data on him in 2021 and I took him on right after the Nazi Salutes and called for the Tesla Boycott, and exposed Elon, despite a nonstop barrage of death threats, for being, in my view, a poser and a manipulator whose very presence in the White House was a grave danger to the US and to the rest of the world, when the world, gaslighted by him and Grok, was silent and gave him a pass for his “awkward gesture”. I also took on Zuckerberg, forcing him to reinstate my post about Elon under penalty of litigation in every single state of the union where he could not be pardoned, and Trump when the world was still asleep, including Congress. In fact, on the very day Elon left the White House, he was confronted by a reporter in the Oval Office, in front of Trump, about a New York Times article in which I was quoted and which Trump referred to repeatedly since. I also warned Trump about Elon via 60 Minutes Australia, the BBC and Politico, forcing a response from the White House. I have done what needed to be done, at significant personal risk, on social media (despite heavy censorship with followers dumped by FB by the hundreds of thousands, by Linked LinkedIn which temporarily locked me out of my account despite its original founder publicly agreeing with me about Elon, and X which I warned the EU about before they slapped heavy fines), in the domestic and international press, to get him out. As predicted, this prompted Elon to lash out, which he did by publicly implicating Trump in the Epstein scandal and backing Massie who spearheaded the effort to release the files, which is where the fuck we are now. 

I was the very first Silicon Valley CEO since the inauguration to publicly denounce Elon, Zuckerberg or Trump, and it took one year for one other tech CEO to whisper something about ICE in a sheepish X post to Elon, I was the first public figure to openly call for Trump’s impeachment in this term, and yes, I am the man who called for the Tesla Boycott—check it out if you have not done your homework.

I did this while running a multibillion dollar company, introducing a new technology recognized by TIME as one of the best inventions of 2025, filing dozens of patents, rescuing dozens of dogs, throwing off the FB algorithm, having my mail intercepted and checked for explosives, hiring armed security, changing my digital footprint while on the move or even walking my lady’s dog, blocking hotels from releasing my information, refusing to take the easy way out and leaving the country, avoiding public and private airports, and while being myself at risk of deportation, despite having advised the military and other agencies, considering I am an immigrant, receiving calls from my mother asking where I wanted to be buried given my fight for Freedom and the US Constitution and having to publicly declare that I am physically and mentally fit and have no wish to harm myself or anyone else. 

You’re fucking welcome. 

ELON’S NAZI SALUTES

----

This just in..
BREAKING: “Be careful with me, b*tch!” Melania’s Epstein scandal EXPLODES as former Brazilian model trafficked by Epstein, Amanda Ungaro, threatens legal action and airing of dirty laundry in wild Twitter spree!

Amanda Ungaro made the headlines a few weeks ago when it was revealed that Paolo Zampolli, the Epstein associate who reportedly introduced Trump to Melania, had collaborated with the Trump administration to have Ungaro, his former “girlfriend” and the mother of his child, deported after a vicious custody battle.

Ungaro was brought to the US on Epstein’s plane by his partner-in-pedophilia, Jean-Luc Brunel, when she was just 17 years old. Zampolli was the “modeling agent” for both Ungaro and Melania.

Now it seems Ungaro is out for revenge. Replying to old Melania tweets, Ungaro wrote 'I have nothing left to lose in my life. I will tear down the entire system—be careful with me b*tch,' she wrote. In a follow-up post, she added: “I will tear down your corrupt system, even if it's the last thing I do in my life. I will go all the way—I am not afraid…Maybe you should be afraid of what I know... of who you are, and who your husband is.”

In another post, she claimed she would “take legal action” against Melania and her “pedophile husband.”

“I have known you for 20 years. You knew I was detained in ICE. You were present in my life—every year on my son's birthday, even sending Secret Service and being the first to congratulate him, back in 2016.”

Wow. First of all, someone get this woman to safety. Secondly, ma’am, please go all the way. We would very much like to know what you know about who Donald Trump really is.

Because we have a pretty good idea, and if any of it is true, he needs to spend the rest of his life behind bars.

----


# Melania

Alex Woodward in New York

Friday 20 March 2026 20:15 GMT

Melania describes herself as a visionary during 

The Independent is trusted by Americans across the entire political spectrum. And unlike many other quality news outlets, we choose not to lock Americans out of our reporting and analysis with paywalls. We believe quality journalism should be available to everyone, paid for by those who can afford it.

Paolo Zampolli, the man who has long been credited as introducing then-New York City nightlife fixture Donald Trump to future first lady Melania, routinely touts his connections to the president on social media.

So when the former modeling agent-turned-government official learned his Brazilian ex-girlfriend had been arrested in Miami last year, he allegedly called a top official at Immigration and Customs Enforcement to ensure she would be placed in federal custody.

According to The New York Times, Zampolli reached out to David Venturella, a former veteran of private prison firm Geo Group who is now a high-ranking ICE official overseeing immigration detention centers, as well as Corey Lewandowski, a close Trump ally working as a top adviser to Homeland Security Secretary Kristi Noem.

Zampolli, who was reportedly engaged in a legal battle with Amanda Ungaro over the custody of their teenage son, has denied asking ICE to detain her or for any other favors from the administration. A spokesperson for Homeland Security said “any suggestion that she was arrested and removed for political reasons or favors is FALSE.”

It remains unclear whether his efforts worked, though Zampolli’s ex was moved into ICE custody and deported shortly after his alleged call to Venturella, according to The Times.

Paolo Zampolli has denied asking ICE to detain the mother of his child following The New York Times’ reporting that he sought the help of a top official at the agency

----

----


