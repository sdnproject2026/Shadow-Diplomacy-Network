# DOJ OIG Audit

## May 29th, 2026

The Department of Justice Office of the Inspector General (OIG) officially announced its probe into the handling of the Epstein documents. 

The political details concerning Pam Bondi, Todd Blanche, and the ongoing congressional friction are accurate.

## Verified Fact Check

### The OIG Audit is Real

- On April 23, 2026, the DOJ OIG announced a formal audit to evaluate compliance with the Epstein Files Transparency Act.

- The watchdog is specifically investigating the identification, collection, and "redaction errors" that improperly exposed survivor data.

### Bondi Deflected to Blanche

- During her highly anticipated, closed-door interview with the House Oversight Committee on May 29, 2026, former Attorney General Pam Bondi explicitly testified that she delegated day-to-day oversight of the Epstein document review and redactions to her then-deputy (and current Acting AG), Todd Blanche.

### The Political Fallout

- Lawmakers from the House Oversight Committee, led by Democrats like Rep.

- Robert Garcia, confirmed that Bondi frequently claimed she did not recall specific operational details and directed the committee to question Blanche and FBI Director Kash Patel instead.

- The independent investigation by the Inspector General is actively moving forward alongside separate congressional inquiries.

## Sources

- https://oig.justice.gov/news/doj-oig-announces-initiation-audit

- https://www.cnn.com/2026/04/23/politics/jeffrey-epstein-justice-department-inspector-general

- https://www.cnn.com/2026/05/29/politics/pam-bondi-epstein-files-house-interview

- https://www.theguardian.com/us-news/2026/apr/23/epstein-files-transparency-act-audit

- https://www.courthousenews.com/doj-inspector-general-probing-agency-compliance-with-epstein-files-transparency-law/

- https://www.youtube.com/watch?v=cNxM5ALemQI

- https://www.nytimes.com/2026/05/29/us/politics/pam-bondi-epstein-files-testimony.html

- https://www.youtube.com/watch?v=hdjwWwnPceU

- https://www.politico.com/news/2026/04/28/gao-epstein-files-investigation-00895594

----

----

