

- SDN-02-Shadows-01-Power-Pyramid-Meta
    - https://controlc.com/063x12vb
    - do 3 more

- SDN - Pizza code > emails > to/from

- SDN - EFTA list -> paste -> DB sort, group, etc. 

- SDN - List all Fed reps and empls Purity Oath
