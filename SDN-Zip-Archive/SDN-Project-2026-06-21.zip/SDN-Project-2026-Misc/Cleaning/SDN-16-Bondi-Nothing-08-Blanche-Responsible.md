## ###House Oversight Committee transcript

- https://oversight.house.gov/wp-content/uploads/2026/06/Final-Bondi-Transcript.pdf

This is the transcript released by the committee and referenced in reporting about Pam Bondi's testimony regarding Todd Blanche and the Epstein files.



