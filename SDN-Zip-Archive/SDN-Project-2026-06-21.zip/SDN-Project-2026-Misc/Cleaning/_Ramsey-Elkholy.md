# Ramsey Elkholy

## Synopsis

According to a Washington Post investigation published June 8, 2026, former New York modeling agent Ramsey Elkholy is among a network of modeling-industry associates who introduced women to Jeffrey Epstein after Epstein's release from jail and while he was under house arrest. The article examines emails and records contained in recently released Epstein files, showing how Epstein maintained and rebuilt connections in the modeling world despite his criminal history.

The Post reports that Elkholy communicated with Epstein about women he believed Epstein should meet, including one email in which he described a woman in highly sexualized terms and encouraged Epstein to see her before she left the country. The investigation places Elkholy within a broader network of lesser-known associates who helped bring women into Epstein's orbit after his conviction.

The article's focus is not only on Epstein himself but also on the role of intermediaries in the modeling industry and Elkholy's current efforts to explain his past interactions with Epstein.

## Names

### Primary Individuals

- Jeffrey Epstein

- Ramsey Elkholy

- Amy Brittain (article author)

### Related Coverage

- Les Wexner

- Naomi Campbell

- Vera Wang

## Key Points

- The investigation centers on Epstein's post-jail efforts to cultivate relationships in the modeling industry.

- Newly released files reveal communications between Epstein and associates who offered introductions to women.

- Elkholy, then a modeling agent and anthropology PhD student, is highlighted as one such associate.

- The report explores how lesser-known industry figures, not only prominent elites, played roles in maintaining Epstein's social network.

## Sources

"This agent sent models to meet Jeffrey Epstein. Now he's trying to ..."

-  https://www.washingtonpost.com/investigations/2026/06/08/this-agent-sent-models-meet-jeffrey-epstein-now-hes-trying-explain-why/

"Amy Brittain - The Washington Post"

- https://www.washingtonpost.com/people/amy-brittain/

"Ramsey Elkholy introduced Epstein to models after he was released ..."

- https://www.instagram.com/p/DZVH5U_kfTQ/

----

----
