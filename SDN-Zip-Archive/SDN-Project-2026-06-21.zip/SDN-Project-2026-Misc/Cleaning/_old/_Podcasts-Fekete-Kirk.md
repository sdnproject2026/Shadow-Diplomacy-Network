# Christine Knapp Fekete

## ID

- Christine Knapp Fekete (@what..fekete) 

## Roles

Christine Knapp Fekete is a comedian, actor, and political commentator.

In late 2025 and early 2026, she gained significant attention for her social media commentary regarding Turning Point USA and  conflict between Candace Owens and Erika Kirk. 

Christine Knapp Fekete is a content creator on platforms like TikTok who has been sharing and amplifying segments from Owens' investigation into  circumstances surrounding Charlie Kirk's death and Erika's leadership of Turning Point USA. 

## Background and Career

### Entertainment

- Fekete is a SAG actor and stand-up comedian who has performed at venues like  World Famous Comedy Store and  Ice House.

- She has appeared on shows such as  Goldbergs and created  gift brand Think Happy Stuff.

### Political Commentary

- She describes herself on Threads as a "biased political commentator".

- Her content often involves analyzing current events within conservative media circles.

### Personal Life

- Originally from Franklin, Tennessee, she spent 11 years in evangelical ministry before moving to Los Angeles at age 47.

- She has eight children - four biological and four adopted. 

### Candace Owens and Turning Point USA 

- Fekete has been a vocal figure in  online discourse surrounding  assassination of Charlie Kirk in September 2025 and  subsequent leadership of his widow, Erika Kirk, at Turning Point USA.

### "Bride of Charlie" Series 


- Candace Owens has launched an investigative documentary series titled "Bride of Charlie - A Wrinkle In Time". 

Assassination ories

- Owens has expressed skepticism regarding  official account of Charlie Kirk's murder, suggesting potential involvement by insiders or foreign entities, though authorities have charged a 22-year-old man named Tyler Robinson for  crime.

Erika Kirk's Background

-  "Bride of Charlie" series questions Erika's personal narrative, including her past relationships and family history.

Turning Point USA Leadership

- Following her husband's death, Erika Kirk took over as CEO of Turning Point USA.

- Owens has criticized this transition, alleging a lack of professional qualifications and internal turmoil, including claims that staff members were fired for being critical of  new direction.

Legal and Personal Tensions

- Erika Kirk has reportedly issued a cease and desist letter to Owens and has publicly asked her to "stop" spreading unverified ories. 

-  two held a private four-hour meeting in December 2025 to address se issues, but tensions have only escalated since n. 

## Media Presence

### Candace Owens

 Candace Owens Show

- Continues to release episodes of her investigation on YouTube and her podcast, 

### Erika Kirk

- Recently appeared in a CBS News town hall to discuss her husband's legacy and respond to  ongoing controversy. 

### Christine Knapp Fekete

Social Media Analysis

- Fekete frequently posts video analysis and commentary on her TikTok account regarding Erika Kirk’s public statements and  controversy sparked by Candace Owens’ investigative series, "Bride of Charlie".

Amplifying  Conflict

- Her content often highlights  tensions between Owens and Erika Kirk, specifically focusing on body language analysis and  "peacemaker" vs. "accountability" narratives within  movement. 

