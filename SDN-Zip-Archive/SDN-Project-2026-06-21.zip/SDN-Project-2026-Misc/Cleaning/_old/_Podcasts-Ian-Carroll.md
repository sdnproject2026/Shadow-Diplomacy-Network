# Ian Carroll

## 2026 Episode & Appearance List

### January 2, 2026

- Ian Carroll on America's Deadliest Mass Shooting

- Synopsis: Ian presents his research into the unanswered questions and anomalies surrounding the Las Vegas mass shooting.

- Transcript

    -  https://singjupost.com/tucker-carlson-show-w-ian-carroll-on-deadliest-mass-shooting-transcript/

- https://www.youtube.com/watch?v=r_Vt_Lo5SiE

### February 6, 2026

- The Epstein Files & Pizzagate 

- Synopsis: A discussion on the latest document releases regarding Jeffrey Epstein's network and historical context of elite misconduct allegations.

- Transcript

    -  https://singjupost.com/tucker-carlson-show-w-ian-carroll-on-epstein-files-pizzagate-transcript/

- https://open.spotify.com/episode/4dhV8F3MH07rY74WjiAT4o

### February 21, 2026

- Exposing "Fedslop" & Credibility 

- Synopsis: A solo deep dive into media narrative crafting and methods for identifying state-sponsored content versus organic news.

- Transcript

    -  https://www.listennotes.com/top-podcasts/ian-carroll/
- (Search "Fedslop")

- https://www.youtube.com/watch?v=0A1K9Irq5xo

### March 3, 2026

- Benjamin Netanyahu & Gaza Strategy (Julian Dorey Daily)

- Synopsis: An analysis of Israeli geopolitical maneuvers and long-term strategic goals in the Middle East.

- https://metacast.app/podcast/julian-dorey-daily/v9U7d0Dd/

### March 17, 2026

- Ian Carroll on Epstein, Israel, and the AI Antichrist (Fight Back with Jake Shields Ep. 169)

- Synopsis: A conversation on the intersection of intelligence blackmail, regional conflicts, and the rise of autonomous technology.

- https://music.youtube.com/podcast/LtFk3NpOcQ0

### March 31, 2026

- The Future of Humanoid Robots 

- Synopsis: Ian explores breakthroughs in robotics and potential "secrets" regarding their workforce integration.

- Transcript

    -  youtube.com (Use YouTube CC)

- https://www.instagram.com/reel/DWjle7FklX-

## Sources

- https://singjupost.com/tucker-carlson-show-w-ian-carroll-on-deadliest-mass-shooting-transcript

- https://podcasts.apple.com/si/podcast/ian-carroll-on-americas-deadliest-mass-shooting-and/id1719657632

- https://singjupost.com/tucker-carlson-show-w-ian-carroll-on-epstein-files-pizzagate-transcript

- https://open.spotify.com/episode/4dhV8F3MH07rY74WjiAT4o

- https://www.listennotes.com/top-podcasts/ian-carroll/

- https://www.youtube.com/watch?v=0A1K9Irq5xo

- https://music.youtube.com/podcast/LtFk3NpOcQ0

- https://www.instagram.com/reel/DWjle7FklX-/

