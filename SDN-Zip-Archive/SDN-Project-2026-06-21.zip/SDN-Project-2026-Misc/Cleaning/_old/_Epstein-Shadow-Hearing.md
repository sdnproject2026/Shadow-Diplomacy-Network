# Epstein Shadow Hearing

## May 2026 

### Overview

- House Democrats are holding an unofficial 'shadow hearing' on May 12, 2026, in Palm Beach, Florida, focused on the Jeffrey Epstein case.

- A shadow hearing is organized by the minority party when they do not control formal congressional hearings, allowing them to gather testimony and public attention without subpoena power.

- The event is led by Representative Robert Garcia, a senior Democrat on the House Oversight Committee.

## What The Hearing Is About

### Purpose

- Examine how Epstein was able to abuse victims for years without being stopped.

- Highlight failures by law enforcement, prosecutors, and institutions.

- Put survivor testimony into the public and congressional record.

### Why Palm Beach

- Palm Beach is where Epstein's crimes first came to public attention in the early 2000s.

- It is also near Mar-a-Lago, linking the event politically to scrutiny of Donald Trump's past association with Epstein.

## Who Will Speak

### Witnesses

- Survivors of Jeffrey Epstein and Ghislaine Maxwell.

- Experts on human trafficking, legal accountability, and systemic failures.

- Some names are being withheld for privacy and safety reasons.

## Political Context

- The hearing comes amid ongoing disputes in Congress over access to Epstein-related files.

- Recent testimony from Commerce Secretary Howard Lutnick about his past connections to Epstein has added pressure and attention.

- Democrats are using this format to keep the issue visible despite not controlling the House agenda.

## Key Takeaway

- This is not a formal trial or official congressional hearing, but it is designed to shape public opinion, elevate survivor voices, and push for further investigation into Epstein's network and institutional failures.

## Associates

### Jeffrey Epstein

- Ghislaine Maxwell - Associate convicted of sex trafficking and recruitment of victims

- Donald Trump - Former U.S. President who had past social interactions with Epstein

- Bill Clinton - Former U.S. President who was reported to have known Epstein

### Robert Garcia

- Jamie Raskin - Senior Democrat on House Oversight Committee

- Alexandria Ocasio-Cortez - Prominent House Democrat involved in oversight efforts

- James Comer - Republican Chair of House Oversight Committee

### Donald Trump

- Ivanka Trump - Daughter and former advisor

- Ron DeSantis - Florida Governor and political figure in same regional sphere

- Jeffrey Epstein - Former acquaintance

### Ghislaine Maxwell

- Jeffrey Epstein - Longtime associate and co-conspirator

- Scott Borgerson - Former spouse and business executive

- Prince Andrew - British royal linked to Epstein scandal

### Howard Lutnick

- Donald Trump - Political associate

- Cantor Fitzgerald - Financial firm he leads

- Jeffrey Epstein - Past social connection referenced in testimony

## Opinions

- Primary sources include major outlets like NYT, NBC News, and CBS, which frame the hearing as a political move to maintain scrutiny on Epstein-related accountability.

- Secondary commentary on platforms like Reddit and independent blogs often debates whether the hearing is substantive or symbolic, with some viewing it as necessary exposure and others as partisan theater.

## Sources

- https://www.wpbf.com/article/florida-palm-beach-epstein-shadow-hearing-victims-unanswered-questions/71245307

- https://cbs12.com/news/local/jeffrey-epstein-probe-returns-to-palm-beach-convening-survivors-witnesses-and-lawmakers

- https://www.wlrn.org/law-justice/2026-05-08/epstein-sex-trafficking-investigation-palm-beach

- https://oversightdemocrats.house.gov/news/press-releases/ranking-member-robert-garcia-announces-oversight-democrats-to-hold-shadow-field-hearing-on-epstein-investigation-in-palm-beach-florida

- https://www.nbcnews.com/politics/politics-news/howard-lutnick-congressional-showdown-epstein-files-island-visit-rcna343523

# Questions

What is the difference between a shadow hearing and a formal congressional hearing?

Why is the Epstein case still politically important years after his death?

What new information could realistically come out of this hearing?

How do survivor testimonies influence public policy or investigations?

What role do political motivations play in events like this hearing?

## Hearing Overview

- House Oversight Committee Democrats held an unofficial 'shadow hearing' in West Palm Beach, Florida focused on survivor testimony, institutional failures, and continued disputes surrounding unreleased Jeffrey Epstein investigative files.

- The hearing was organized by Representative Robert Garcia because Democrats did not control formal committee subpoena authority.

- The hearing took place near Epstein's former Palm Beach residence, described repeatedly by lawmakers and media organizations as 'the scene of the crime.'

## Chronology

## 1996

- Maria Farmer reported Jeffrey Epstein's conduct to authorities years before broader public investigations emerged.

- Farmer later stated investigators failed to aggressively pursue the allegations and failed to protect victims from retaliation.

## 2004-2005

- Dani Hannah Bensky testified she was abused by Jeffrey Epstein beginning at age 17 while working as a dancer in New York City.

- Bensky later became a survivor advocate and public critic of DOJ handling of Epstein-related records.

## 2005

- Palm Beach police investigations into Jeffrey Epstein intensified after complaints involving underage girls and recruitment activity at Epstein's Palm Beach mansion.

- The Palm Beach investigations later became central to criticism of prosecutorial decisions and the 2008 non-prosecution agreement.

## 2007-2008

- Then-U.S. Attorney Alexander Acosta negotiated a controversial federal non-prosecution agreement allowing Epstein to avoid broader federal prosecution.

- The agreement later became widely criticized as a 'sweetheart deal' that allowed Epstein to continue operating internationally.

## 2008-2009

- Survivor Roza testified she was trafficked from Uzbekistan to the United States through modeling industry contacts connected to Jean-Luc Brunel.

- Roza stated Epstein abused her for approximately three years, including periods while Epstein was under Florida work-release and house arrest supervision.

## 2019

- Jeffrey Epstein died in federal custody while awaiting federal sex trafficking prosecution in New York.

- Public scrutiny intensified regarding institutional failures, prosecutorial decisions, intelligence handling, and possible protection of powerful associates.

## 2025-04-24

- Virginia Giuffre, one of Epstein's most publicly recognized accusers, died by suicide according to statements referenced during the hearing.

- Her death became a major emotional focus during testimony from family members and survivor advocates.

## 2026-05-04

- Oversight Democrats publicly announced plans for the Palm Beach shadow hearing focused on survivor testimony and institutional accountability.

- Social media and independent commentary communities rapidly amplified the announcement.

## 2026-05-05

- Representative Robert Garcia publicly stated the hearing would focus on centering survivor testimony and maintaining investigative pressure regarding unreleased Epstein files.

## 2026-05-12

- House Oversight Democrats held the shadow hearing in West Palm Beach, Florida.

- Survivors, victim advocates, attorneys, and family members testified regarding abuse allegations, prosecutorial failures, DOJ disclosure controversies, and institutional protection systems.

- Democrats released a report titled 'The Price Of Non-Prosecution' criticizing the 2008 plea agreement negotiated with Epstein.

- Lawmakers and witnesses criticized the Department of Justice for allegedly exposing victim identities while continuing to redact names of powerful individuals.

- Representative Robert Garcia stated the hearing was intended to continue investigative pressure regardless of formal committee limitations.

- Multiple survivors delivered emotional testimony regarding trauma, coercion, immigration exploitation, financial manipulation, and long-term institutional failures.

## 2026-05-13

- Survivor testimony clips and hearing excerpts circulated widely across social media, Reddit communities, independent journalism channels, and legal commentary forums.

- Coverage increasingly focused on DOJ handling of survivor identities and unreleased investigative files.

## 2026-05-14

- Representative Robert Garcia and Oversight Democrats continued publicly criticizing DOJ disclosure practices and alleged institutional obstruction.

- Additional hearing footage, survivor opening statements, and committee materials were distributed online.

- Survivor advocates increased public pressure regarding unreleased DOJ and Treasury records.

## Victim And Witness Testimony

### Roza

- Survivor originally from Uzbekistan who testified she was recruited through modeling industry channels connected to Jean-Luc Brunel.

- Stated she arrived in the United States under a talent visa arrangement and was quickly sent to Epstein's residence.

- Testified Epstein abused her over a multi-year period including periods while Epstein remained under criminal supervision.

- Criticized DOJ handling of released records after her previously protected identity was allegedly exposed through inadequate redactions.

- Became visibly emotional during portions of the hearing while discussing long-term trauma and institutional failures.

### Dani Hannah Bensky

- Epstein survivor, choreographer, dance instructor, and survivor advocate.

- Testified she was abused beginning at age 17 in New York City.

- Criticized DOJ document releases and alleged mishandling of survivor identities.

- Referenced civil litigation involving Epstein estate figures Darren Indyke and Richard Kahn.

### Courtney Wild

- One of Epstein's earliest publicly known Palm Beach victims.

- Testified she was abused by Epstein beginning at age 14.

- Became nationally known for legal efforts challenging federal prosecutors over victim notification rights.

- Told lawmakers she wanted safeguards ensuring similar institutional failures never occur again.

### Maria Farmer

- Early whistleblower who reported Epstein conduct to authorities in 1996.

- Testified investigators failed to aggressively pursue allegations despite early warning signs.

- Criticized institutional failures involving law enforcement, prosecutors, and intelligence handling systems.

### Jena-Lisa Jones

- Survivor and public advocate critical of DOJ disclosure practices.

- Warned lawmakers that limited and selective file releases risked enabling institutional cover-up concerns.

- Emphasized the importance of continued congressional oversight pressure.

### Sky Roberts

- Brother of Virginia Giuffre.

- Spoke emotionally regarding Giuffre's advocacy work, trauma, and death in 2025.

- Argued survivors spent years fighting systems that protected powerful individuals.

### Amanda Roberts

- Sister-in-law of Virginia Giuffre.

- Appeared alongside Sky Roberts in support of survivor accountability efforts.

- Emphasized long-term emotional consequences affecting survivor families.

## Significant Media Coverage

### WLRN

- Coverage focused heavily on emotional survivor testimony and allegations that powerful individuals remained institutionally protected.

- Reporting emphasized survivor criticism regarding DOJ redaction failures and disclosure practices.

### The Guardian

- Framed the hearing as an effort by Democrats to maintain investigative pressure regarding Epstein files and institutional accountability.

- Highlighted warnings against any future pardon considerations involving Ghislaine Maxwell.

- Focused on the hearing's symbolic location near Epstein's Palm Beach residence.

### Local 10 News

- Focused extensively on Roza's testimony involving immigration recruitment, modeling industry exploitation, and abuse during Epstein's house arrest period.

- Emphasized connections involving Jean-Luc Brunel and allegations regarding fraudulent visa arrangements.

### FOX Local

- Characterized the hearing as an emotionally charged but unofficial congressional proceeding intended to build public pressure for additional disclosures.

- Emphasized that witnesses were not compelled under subpoena authority because Republicans did not participate.

### Reddit And Independent Commentary

- Reddit communities dedicated extensive discussion to survivor testimony, DOJ disclosure disputes, and allegations involving institutional protection systems.

- Online discussions widely circulated hearing clips, opening statements, and media excerpts.

- Commentary frequently debated whether the hearing represented meaningful accountability efforts or symbolic political theater.

## Associates

### Robert Garcia

- United States Representative from California and Ranking Democrat on the House Oversight Committee.

Jamie Raskin

- Senior Democratic oversight figure involved in institutional accountability investigations.

Ayanna Pressley

- Democratic congresswoman participating in survivor-centered oversight initiatives.

James Comer

- Republican Chair of the House Oversight Committee.

### Roza

- Epstein survivor originally recruited through modeling industry channels.

Jean-Luc Brunel

- French modeling agent accused of trafficking-related recruitment activity.

Jeffrey Epstein

- Financier accused of sexually abusing and trafficking underage girls and young women.

Robert Garcia

- Congressional organizer of the shadow hearing where Roza testified.

### Dani Hannah Bensky

- Epstein survivor and public advocate.

Darren Indyke

- Epstein attorney sued in litigation connected to estate management and enabling allegations.

Richard Kahn

- Epstein accountant referenced in survivor litigation.

Jeffrey Epstein

- Financier accused of abuse and trafficking crimes.

### Courtney Wild

- Palm Beach survivor and victims' rights advocate.

Jeffrey Epstein

- Central subject of the criminal investigations.

Alexander Acosta

- Former U.S. Attorney criticized regarding the 2008 plea agreement.

Maria Farmer

- Early whistleblower and survivor advocate.

### Maria Farmer

- Early Epstein whistleblower who contacted authorities in 1996.

Jeffrey Epstein

- Financier accused of abuse and trafficking operations.

Ghislaine Maxwell

- Convicted Epstein associate accused of recruitment activity.

Annie Farmer

- Sister and fellow survivor connected to early allegations.

### Sky Roberts

- Brother of Virginia Giuffre.

Virginia Giuffre

- Prominent Epstein accuser and survivor advocate.

Amanda Roberts

- Family member participating in survivor advocacy.

Robert Garcia

- Congressional organizer of the hearing.

## Opinions

## Primary Sources

- Congressional Democrats framed the hearing as necessary to preserve survivor testimony in the public record and maintain pressure regarding unreleased investigative material.

- Mainstream media organizations focused heavily on emotional survivor testimony, DOJ disclosure controversies, and criticism of historical prosecutorial failures.

- Broadcast coverage emphasized the symbolic importance of holding the hearing in Palm Beach near Epstein's former residence.

## Secondary Sources

- Reddit communities extensively circulated hearing footage, survivor statements, and commentary regarding alleged institutional protection systems.

- Independent legal commentators debated whether unofficial hearings can materially influence future investigations or public opinion.

- Online discussion frequently centered on DOJ redaction controversies, survivor privacy concerns, and unreleased Treasury financial intelligence records.

## Sources

- https://www.wlrn.org/law-justice/2026-05-12/survivors-jeffrey-epstein-congressional-hearing-west-palm-beach

- https://randall.house.gov/media/press-releases/randall-hears-epstein-survivors-west-palm-beach-oversight-field-hearing

- https://www.wusf.org/courts-law/2026-05-12/powerful-remained-protected-survivors-recall-epstein-crimes-at-congressional-hearing

- https://www.wuwf.org/florida-news/2026-05-12/powerful-remained-protected-survivors-recall-epstein-crimes-at-congressional-hearing-in-west-palm-beach

- https://www.theguardian.com/us-news/2026/may/12/jeffrey-epstein-survivor-palm-beach-hearing

- https://www.local10.com/news/politics/2026/05/12/epsteins-survivors-testify-during-hearing-in-west-palm-beach/

- https://www.fox.com/watch/clip/fmc-9j1ragaendk8ia7u/shadow-hearing-epstein-survivors-testify-in-palm-beach

- https://www.thetimes.com/us/american-politics/article/new-epstein-victim-palm-beach-press-conference-790jr08pc

- https://nypost.com/2026/05/13/us-news/epstein-victim-says-he-raped-her-while-he-was-under-house-arrest/

- https://www.reddit.com/r/Epstein/comments/1tb9hrg/live_exclusive_house_oversight_democrats_hold/

- https://www.reddit.com/r/Epstein/comments/1tbgsvo/epstein_survivor_courtney_wilds_opening_statement/

- https://www.reddit.com/r/Epstein/comments/1tbc1y6/epstein_survivor_ms_rozas_opening_statement_at/

- https://www.reddit.com/r/Epstein/comments/1tcy4xx/that_is_a_coverup_robert_garcia_opening_statement/

# Questions

How much unreleased investigative material discussed during the hearing remains outside public disclosure?

Could unofficial congressional shadow hearings influence future formal investigations or prosecutions?

What legal remedies remain available for survivors whose identities were allegedly exposed through DOJ disclosure failures?

How extensively did financial institutions, prosecutors, and intelligence systems identify risks connected to Epstein before broader public exposure?

Will congressional investigators seek additional testimony involving Treasury officials, DOJ leadership, or financial compliance executives following the Palm Beach hearing?

-----

-----