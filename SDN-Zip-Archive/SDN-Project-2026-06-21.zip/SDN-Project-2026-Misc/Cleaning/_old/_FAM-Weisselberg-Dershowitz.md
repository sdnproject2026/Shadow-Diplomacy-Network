# Weisselberg and Dershowitz

Based on the recent search and available information, here is a list of individuals connected to Jeffrey Epstein’s financial network who are also associated with the Allen Weisselberg family and the Alan Dershowitz family, including reasons for association and estimated date ranges.

##  Allen Weisselberg Family

### Allen Weisselberg

Reason

- Longtime CFO of the Trump Organization, reportedly connected indirectly to Epstein through Trump and shared social/business circles.

Date

- (1990s–2020s)

### Donald Trump

Reason

- Business partner and social associate of Weisselberg and Epstein; overlapping real estate and social networks.

Date

- (1980s–2019)

### Jeffrey Epstein

Reason

- Social and financial connections overlapping with Weisselberg’s network through Trump Organization and New York elite circles.

Date

- (1980s–2019)

### Jared Kushner

Reason

- Connected to Weisselberg through Trump Organization and family business dealings; tangentially linked to Epstein’s network.

Date

- (2000s–present)

### Ivanka Trump

Reason

- Part of the Trump family business network involving Weisselberg; social and business circles intersect with Epstein’s associates.

Date

- (2000s–present)

##  Alan Dershowitz Family

### Alan Dershowitz

Reason

- High-profile lawyer and associate of Epstein and Maxwell; involved in legal defense and social circles.

Date

- (1990s–2019)

### Jeffrey Epstein

Reason

- Legal client and associate of Dershowitz; involved in social and legal networks.

Date

- (1980s–2019)

### Ghislaine Maxwell

Reason

- Close associate of Epstein and involved in social/legal networks overlapping with Dershowitz.

Date

- (1990s–2019)

### Les Wexner

Reason

- Financial backer connected to Epstein and indirectly linked to Dershowitz through legal and social networks.

Date

- (1980s–2019)

### Prince Andrew, Duke of York

Reason

- Social and legal circles overlapping with Dershowitz and Epstein networks.

Date

- (1990s–2019)

### Sources

International Moneyman of Mystery “Terrific guy,” Donald ... 

- https://www.facebook.com/groups/2235625136712757/posts/4115677142040871/

What MAGA Got Right About ... 

- https://gregolear.substack.com/p/deconstructing-the-epstein-myth-what

Donald Trump and Jeffrey Epstein hanging out at Victoria's ... 

- https://www.reddit.com/r/Fauxmoi/comments/1m7eryd/donald_trump_and_jeffrey_epstein_hanging_out_at/

----

