# Inside Jeffrey Epstein’s Push to Cleanse His Past Online

- Anthony Gerace
- March 19, 2026, 
- Section A, Page 1 
- New York edition

> Al Seckel, a professed expert on optical illusions who was in a romantic relationship with an older sister of Ghislaine Maxwell

After he left jail in 2009, Mr. Epstein hired a host of people to make him look better on Google, Wikipedia and many other places on the web.

An email sent to Jeffrey Epstein in September 2010 presented an intriguing opportunity. 

> "Would you be interested," it read, "in having all that crap that comes up on Google search on your name basically disappear?"

Mr. Epstein had been released from jail about a year earlier after a conviction for sex crimes involving a minor. His online reputation was a shambles. Less than two hours after receiving the email, he responded:

> Yes.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00896733.pdf

That helped kick-start a yearslong quest by Mr. Epstein to overhaul his online reputation, according to a New York Times review of thousands of pages of emails, financial records and other records released by the Justice Department. The documents make it clear that Mr. Epstein became deeply invested in hiding his criminal past in Google searches and on Wikipedia.

He never fully sanitized his web presence before he was arrested again, in 2019, and charged with sex trafficking. But the effort at times allowed Mr. Epstein to maintain an air of respectability and preserve social contacts he might have lost had his crimes been more prominent online.

To accomplish that, Mr. Epstein first turned to the author of the 2010 email  -  Al Seckel, a professed expert on optical illusions who was in a romantic relationship with an older sister of Ghislaine Maxwell, Mr. Epstein’s longtime associate. Over time, a rotating cast of friends, assistants and hired guns was enlisted to contribute to the project, including professional search engine optimization experts, self-described hackers and crews of content writers in the Philippines. While some, such as Mr. Seckel, worked for free, others charged tens of thousands of dollars.

Al Seckel pitched to Jeffrey Epstein that he could make online references to the financier’s conviction on sex crimes with a minor "basically disappear."

The people manipulated search results and pulled all-nighters to distort Mr. Epstein’s Wikipedia profile, hide negative news articles, score fawning puff pieces in major media outlets and create dozens of online profiles, canned interviews and websites like "jeffreyepsteinsports.com" that pushed a fake persona, the documents show.

- https://www.justice.gov/epstein/files/DataSet%2011/EFTA02417620.pdf

Collectively, the loosely organized team managed to downplay records of his criminal past and promote him as a philanthropist and an intellectual. At times those efforts appeared to contribute to the willingness of some people and organizations to engage with him.

Between 2012 and 2017, officials at M.I.T.’s Media Lab accepted $750,000 in donations from Mr. Epstein. A subsequent investigation commissioned by the university cited edits to his Wikipedia page that "could be read as undercutting the strength of some of the allegations" against him as potentially influencing the decision to take the money. Naomi Campbell, a supermodel with ties to the financier, said recently through her lawyer that she "had no idea that Epstein was a registered sex offender" until his 2019 arrest.

- https://factfindingjan2020.mit.edu/files/MIT-report.pdf

- https://www.nytimes.com/2026/02/15/style/epstein-files-naomi-campbell.html

Many of the attempts to launder Mr. Epstein’s web presence, including changes to his Wikipedia page, often overstepped normally accepted lines. Team members created networks of fake Wikipedia editing accounts, sometimes known as sock puppets, to sneak changes past administrators, whose accounts they also tried to disrupt by hacking. They drummed up sham websites and fictitious personas solely to fool search algorithms. Such practices may not have broken any laws but are frowned upon by many working in online reputation management.

- https://en.wikipedia.org/wiki/Wikipedia:Wikipedia_Signpost/2020-03-29/In_focus

> This world has a light side and a dark side

said Bill Beutler, whose firm, Beutler Ink, focuses on improving Wikipedia entries for corporate clients including Archer-Daniels-Midland and The New York Times. Rule followers, he said, look for transparent ways to propose positive edits on Wikipedia entries and tell customers not to expect miracles.

> That’s completely anathema to what Epstein’s crew was doing.

Mr. Beutler said.

Mr. Epstein was never satisfied. In late 2010, in one of his many ungrammatical messages, he wrote to Mr. Seckel demanding information about other reputation management firms that might be able to further aid his quest.

> Nothing for me more important, 

he wrote.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00896585.pdf)," 

## A Long Shadow

Online reputation management is a big business, valued at billions of dollars, according to several estimates. Clients include corporations and individuals who rely on highly targeted internet engineering to manipulate or enhance the trail they leave on the internet.

Mr. Epstein’s 2008 guilty plea left a long shadow online. In one early email, Mr. Seckel laid out the scope of the challenge: On Google’s search alone, there were more than 75 pages of "derogatory material" about the convicted sex offender.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00754643.pdf

> You have absolutely NO good references on yourself on the web at all, nothing for you to point anything to, and all that is out there, is very bad

he wrote to Mr. Epstein.

- https://www.justice.gov/age-verify?destination=/epstein/files/DataSet%209/EFTA00754670.pdf

But Mr. Seckel had a plan: to 

> build a very positive humanitarian successful presence for Jeff that is pervasive on the web, an image

he said

> that would bore the hell out of any tabloid journalist. 

> > Mr. Seckel died in France in 2015 in what the local authorities ruled a suicide.

- https://www.justice.gov/age-verify?destination=/epstein/files/DataSet%209/EFTA00751527.pdf

- https://www.dailymail.co.uk/news/article-10712491/Mystery-death-Ghislaine-Maxwells-brother-law-finally-declared-suicide.html

The nature of Mr. Epstein’s conviction made him persona non grata to many reputation rehabilitation companies. But the files also reveal that, with his wealth and powerful connections, he invariably found experts eager to please.

At the time Mr. Seckel made his pitch, Mr. Epstein had already paid him $25,000 to organize a conference at a hotel in the U.S. Virgin Islands, with excursions to Mr. Epstein’s private island. In one planning email, Mr. Seckel described the speakers as 

> "very bright, out-of-the box thinkers."

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00731043.pdf
- https://www.justice.gov/epstein/files/DataSet%209/EFTA00900788.pdf
- https://www.justice.gov/epstein/files/DataSet%2011/EFTA02417214.pdf

Among them was Pablos Holman, who describes himself as a futurist who has helped invent a mosquito-killing laser, a hurricane-suppressing machine, a malaria-diagnosing microscope powered by artificial intelligence and more. At the conference, he was scheduled to demonstrate lock picking.

- https://www.nytimes.com/2018/03/22/technology/at-mars-jeff-bezos-hosted-roboticists-astronauts-other-brainiacs-and-me.html

Mr. Holman would also chip in on the reputation management project, according to Mr. Seckel, who requested that Mr. Epstein wire $20,000 to start a "hacking" team. Mr. Seckel insisted he wouldn’t keep a penny personally, but also repeatedly asked Mr. Epstein to fund an educational nonprofit he co-founded, help raise money for other projects and even float him a $3.5 million loan.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00751367.pdf
- https://www.justice.gov/epstein/files/DataSet%2010/EFTA02034541.pdf
- https://www.justice.gov/epstein/files/DataSet%2011/EFTA02439549.pdf

In response to a query from The Times, Mr. Holman wrote that his mentions in Mr. Seckel’s emails 

> are not accurate" and that Mr. Seckel was "fraudulent and untrustworthy in many ways.

> "I never did any work for Epstein," Mr. Holman wrote. "I have never done any ‘reputation management’ work for anyone."

## Google and Wikipedia

Google was a top priority for the team, which soon expanded to include Mike Keesling, a search optimization expert in California. Mr. Seckel described him as a longtime friend who was willing to charge Mr. Epstein a discount to the reputation rehabilitation he offered to movie stars because he owed Mr. Seckel favors. Mr. Epstein paid Mr. Keesling at least $22,500; in financial spreadsheets released by the Justice Department, the payments were labeled "gifts."

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00754643.pdf
- https://www.justice.gov/epstein/files/DataSet%209/EFTA00727516.pdf

The goal was to promote content that could displace negative stories about Mr. Epstein’s misdeeds from the first page of Google results. To do that, the team built websites highlighting Mr. Epstein’s interest in science and philanthropy, while boosting search results for other people with the same name, including a former chief financial officer of Oracle and a hair transplant doctor. They manufactured "a pseudo Jeffrey Epstein"  -  creating a fake persona with a sports-focused website to "bury" negative content about their client, according to emails. They called these efforts "pimping."

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00751523.pdf
- https://www.justice.gov/epstein/files/DataSet%209/EFTA00751527.pdf
- https://www.justice.gov/epstein/files/DataSet%209/EFTA00751523.pdf
- https://www.justice.gov/epstein/files/DataSet%2011/EFTA02418024.pdf

It was "laborious work," Mr. Seckel wrote. The fake pages  -  he described them as "spam sites"  -  "can’t appear to be ‘forced,’" and required original links and copy rewritten hundreds of times by a "crew" of content writers in the Philippines. 

> Ultimately, the team created sites like jeffreyepstein.org, jeffreyepsteinfoundation.com and jeffreyepstein.net. Mr. Epstein also ended up with accounts on Blogspot, LinkedIn, MySpace, Pinterest and Vimeo.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00751527.pdf

They also landed glowing pieces about Mr. Epstein in publications that at that time regularly accepted outside contributors, including HuffPost and Forbes. They then meticulously tracked whether the articles, which omitted Mr. Epstein’s sex offender status, displaced news of his crimes in Google’s rankings.

- https://www.nytimes.com/2019/07/21/business/media/jeffrey-epstein-media.html

A Forbes spokeswoman said the outlet was aware of one article written by a former contributor in 2013 that was removed from the site in 2019 because it failed to meet editorial standards. HuffPost said it was not affiliated with and did not endorse the views expressed by the articles, which it said were published on its long-defunct unpaid contributor platform.

> Contributor content on that platform was created independently and was not subject to HuffPost’s rigorous editorial oversight or journalistic standards

the outlet said in a statement.

Mr. Epstein’s team also tried to remove what it called "toxic" terms that Google automatically suggested whenever his name was searched  -  such as "jail" and "pedophile."

- https://www.justice.gov/epstein/files/DataSet%2010/EFTA01785713.pdf

Those sites, articles and links would be critical for a second major focus: sanitizing the Wikipedia entry for Mr. Epstein, which as of fall 2010 mentioned his criminal background in the first section and included a mug shot.

"Everybody wants their Wikipedia page changed," said Juda Engelmayer, a crisis public relations expert who has represented Harvey Weinstein and Sean Combs, known as Diddy, among other clients. 

> But it’s the hardest one to do.

By November 2010, Mr. Seckel reported that he had managed to 

> tone it down considerably

by replacing the mug shot and a description of the 2008 guilty plea with a more flattering photo captioned as "American financier and philanthropist." Links to graphic accounts of Mr. Epstein’s crimes were removed, and "large sections" on philanthropy inserted.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00751527.pdf

That December, Mr. Seckel informed Mr. Epstein in an email that 

> your wiki entry now is pretty tame, and bad stuff has been muted.

Mr. Seckel called it 

> a big success.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00899885.pdf

A major goal was sanitizing Mr. Epstein’s Wikipedia entry, which mentioned his conviction in the first paragraph. But Wikipedia editors quickly reversed changes attempted by Mr. Seckel’s team. Credit...Jeff Chiu/Associated Press

But it wasn’t easy, and wouldn’t last. Mr. Seckel noted that 27 Wikipedia editors had been watching over Mr. Epstein’s entry and reversing every tweak attempted by his team, often within 15 minutes.

Wikipedia records and Mr. Epstein’s emails show how damning content  -  "the nasties," Mr. Keesling called them  -  inexorably crept back. The site’s volunteer editors eventually blocked multiple editing accounts that seemed focused on cleaning content about Mr. Epstein.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00632492.pdf

> "Wikipedia is an ongoing effort and battle," Mr. Keesling wrote.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00710769.pdf

## Epstein’s Frustration

Mr. Epstein compounded the challenge with his impatience and frequent rebukes. Just weeks into the project with Mr. Seckel, he wrote that 

> unfortunately we have failed big time.

He questioned the expense, demanding detailed reckonings of spending and complaining about fees that reputation management experts described as downright modest.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00752508.pdf

In February 2012, Mr. Epstein paid $2,499 for the "advanced package" from Integrity Defenders, a company that described itself in emails as a "tech group that gets bad press off the internet." By mid-March, he complained that his Google results "appear worse than last month." A contributor to the reputation management work, whose name was redacted in the files, proposed in May that Mr. Epstein claw back the fee, writing that he

> shouldn’t have to pay for it.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00928789.pdf
- https://www.justice.gov/epstein/files/DataSet%2010/EFTA01770366.pdf
- https://www.justice.gov/epstein/files/DataSet%209/EFTA00709668.pdf

Later that year, Mr. Epstein signed up for a one-month $12,500 trial with another firm, Reputation Changer, which laid out a personalized 10-page "Reputation Clearing Action Plan" to "flood the first four pages of Google, Bing and Yahoo" with content designed to produce "an overwhelmingly positive impression." Four months later, he again was unsatisfied, prompting his accountant to speculate that Reputation Changer might be intentionally "promoting negative articles to make it appear that we need them."

- https://www.justice.gov/epstein/files/DataSet%2010/EFTA01999447.pdf
- https://www.justice.gov/epstein/files/DataSet%2011/EFTA02700902.pdf
- https://www.justice.gov/epstein/files/DataSet%209/EFTA00955188.pdf

Integrity Defenders and Reputation Changer could not be reached for comment.

Mr. Epstein also took his frustrations out on Tyler Shears, described in emails as an expert in search engine optimization, who asked for as much as $15,000 upfront plus $125 an hour and expenses for internet cleanup services when he was hired in July 2013. Emails show that he managed to remove Mr. Epstein’s mug shot from his Wikipedia entry, push down negative links on multiple search engines and secure positive articles.

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00636868.pdf

Still, Mr. Epstein was dissatisfied  -  unhappy that Mr. Shears had billed him nearly $51,000 in seven months, and he was unwilling to pay for more credibility-boosting articles. To keep his client, Mr. Shears offered to drop his fees to as low as $1,000 a month to cover expenses, if only Mr. Epstein would meet with him in person. 

> I admire your accomplishments and views and would be honored if you would give up some of your time to meet and allow me to learn from you.

he wrote, calling the prospect of such a get-together 

> a big bonus.

- https://www.justice.gov/epstein/files/DataSet%2010/EFTA01932501.pdf
- https://www.justice.gov/epstein/files/DataSet%2010/EFTA01935347.pdf
- https://www.justice.gov/epstein/files/DataSet%2010/EFTA01935347.pdf

Just four months later, Mr. Epstein was once again unhappy. 

> Results still very bad

he wrote to Mr. Shears.

> No excuses here i’m not pleased with where it is at and am still working to make it happen

Mr. Shears responded.

## Sources

- https://www.nytimes.com/2026/03/18/business/media/jeffrey-epstein-online.html?unlocked_article_code=1.UVA.vmd4.RUytqAuEY04d&smid=nytcore-android-share

- https://www.nytimes.com/by/tiffany-hsu 
    - reports on the information ecosystem, including foreign influence, political speech and disinformation

----

----
