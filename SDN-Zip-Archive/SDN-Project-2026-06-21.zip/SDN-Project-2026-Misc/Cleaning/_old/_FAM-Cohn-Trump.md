# Roy Cohn and Fred Trump

Here is a list of individuals connected to Jeffrey Epstein’s financial network who are also associated with the Roy Cohn family and the Fred Trump family, including reasons for association and estimated date ranges.

##  Roy Cohn Family

### Donald Trump

Reason

- Mentored by Roy Cohn early in his career; Cohn was a powerful lawyer and political fixer who influenced Trump's legal and business strategies. Epstein was part of Trump’s social and financial circles.

Date

- (1970s–2019)

### Jeffrey Epstein

Reason

- Connected indirectly through Trump and New York elite social networks influenced by Roy Cohn’s legacy.

Date

- (1980s–2019)

### Roy Cohn 

(Deceased, but influential figure)

Reason

- Lawyer and political fixer who shaped the legal and political environment of New York elites, including Trump and Epstein’s circles.

Date

- (1950s–1986)

### Alan Dershowitz

Reason

- Legal figure connected to Epstein and part of the New York legal elite influenced by Cohn’s era.

Date

- (1980s–2019)

### Les Wexner

Reason

- Billionaire with ties to Epstein and part of the New York financial elite shaped by Cohn’s influence.

Date

- (1980s–2019)

##  Fred Trump Family

### Donald Trump

Reason

- Son of Fred Trump, inherited and expanded the family real estate business; Epstein was connected to the Trump family through social and business networks.

Date

- (1970s–2019)

### Fred Trump (Deceased)

Reason

- Patriarch of the Trump family real estate empire; established the foundation for Donald Trump’s business ventures.

Date

- (1930s–1999)

### Jared Kushner

Reason

- Son-in-law of Donald Trump; involved in real estate and political networks overlapping with Epstein’s associates.

Date

- (2000s–present)

### Ivanka Trump

Reason

- Daughter of Donald Trump; involved in family business and political activities intersecting with Epstein-related circles.

Date

- (2000s–present)

### Jeffrey Epstein

Reason

- Connected socially and financially to the Trump family network, which originated with Fred Trump’s real estate empire.

Date

- (1980s–2019)

### Sources

Hulu doc explores Victoria's Secret, Jeffrey Epstein ties 

- https://apple.news/AlUMWS0jAQnO7qtcGXagY-w

How Donald Trump Echoes Joe McCarthy 

- https://apple.news/AuAxKYfl1SYqCi30zVWefIg

FBI Vault (reading room) 

- https://vault.fbi.gov/reading-room-index

----
