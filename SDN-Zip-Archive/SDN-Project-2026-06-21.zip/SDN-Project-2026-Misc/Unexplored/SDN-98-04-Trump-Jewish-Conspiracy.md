# Trump Joins The Global Jewish Conspiracy

- https://www.alternet.org/global-jewish-conspiracy

    - lightly edited

It bears repeating that Donald Trump's rationale for war against Iran keeps shifting because Trump himself does not believe his own rationales. The goal of this war has little to do with Iran. It has to do with creating conditions in which an old, depleted and unpopular president looks big, tough and loved on American TV.

But there may be a reason outside the president's fear of defeat in this year's congressional elections. While he believes that he benefits from the perception of being a war president, it looks like the decision to become one wasn't entirely his to make.

## November 2025

Early reporting on the war suggested that Israel was going to attack Iran with or without Trump, and that Israeli Prime Minister Benjamin Netanyahu was lobbying him to join the effort. Reports indicate that Netanyahu decided in November of last year to order a long-planned operation to assassinate Iran's Supreme Leader Ayatollah Ali Khamenei.

## Marco Rubio Confirmed

Marco Rubio confirmed that reporting on Monday, stating that the administration knew there was going to be an Israeli action and that it would precipitate an attack against American forces. He claimed that failing to preemptively go after them would have resulted in higher casualties.

The president launched an illegal and unjustified war with Iran because America's ally, Israel, put him in a no-win situation. The debate was whether the US would launch in concert with Israel or wait until Iran retaliated on US military targets in the region and then engage.

Trump could have condemned Netanyahu after the fact, but apparently the appeal of being a war president was too great. Even the death of Khamenei is attributed to Israeli strikes. The only credit Trump can claim is having followed Netanyahu's lead.

## Not Acting In Self-defense

### Consent Of The Congress Required

That it appears the decision to attack Iran was Netanyahu's more than it was Trump's is going to be a problem, most immediately because of the outcry in the Congress. If Trump was not acting in self-defense, then this war against Iran is a war of choice, which requires the consent of the Congress. Trump is going to be forced to explain himself, thus risking being held accountable for the spike in goods and oil prices, the sell-off on Wall Street, and general chaos in the Middle East.

### US To Immediately Leave 16 Countries

The State Department told Americans to immediately leave 16 countries and territories including:

| --- | --- | --- | --- |
| Bahrain | Egypt | Gaza | Iran |
| Iraq | Israel | Jordan | Kuwait |
| Lebanon | Oman | Qatar | Saudi Arabia |
| Syria | UAE | West Bank | Yemen |
### Not Going To Fly

The White House's best rationale for war seems to be that the US was forced to attack Iran because Iran was forced to defend itself against Israel's attack. Such a rationale is not going to fly with most of the Congress, including many MAGA Republicans. That is why Trump claimed Netanyahu did not force his hand, but that he forced Netanyahu's.

### Rooted In Conspiracy Theory

To understand the problem he has created for himself, one must consider the nature of America First. It is rooted in conspiracy theory and antisemitism. At the center of America First is an unshakeable belief in a global Jewish conspiracy against America.

### Global Jewish Conspiracy

This belief was the foundation beneath the push to release the Epstein files during Trump's 2024 campaign. Trump was supposed to be the hero sent to save America from a secret cabal of powerful Jews. When he did not, he triggered a crisis of faith that can be registered in recent polling.

## MAGA's Crisis Of Faith

With Iran, he has now compounded MAGA's crisis of faith. He must contend with the growing suspicion that instead of destroying the global Jewish conspiracy against America, he has joined it.

## Sources

- https://www.editorialboard.com/trump-never-meant-a-word-he-said/

- https://www.editorialboard.com/trumps-self-serving-made-for-tv-war-with-iran/

- https://www.washingtonpost.com/politics/2026/02/28/trump-iran-decision-saudi-arabia-israel/

- https://www.usatoday.com/story/news/world/2026/03/03/israel-decision-kill-khamenei-after-oct-7/88957910007/

- https://www.france24.com/en/live-news/20260302-rubio-says-israel-s-strike-plan-triggered-us-attack-on-iran

- https://www.marketplace.org/story/2026/03/02/will-war-in-iran-raise-costs-in-the-us

- https://www.usatoday.com/story/money/markets/2026/03/03/oil-prices-stocks-iran-war/88957429007/

- https://apnews.com/article/stock-markets-iran-energy-oil-trump-75edbda5b8fa3038b47f143cc16855f0

- https://bsky.app/profile/newsguy.bsky.social/post/3mg5pagwqs42w

- https://www.nbcnews.com/politics/national-security/state-department-urges-americans-mideast-depart-strikes-continue-rcna261313

- https://www.notus.org/foreign-policy/americans-stranded-middle-east-help-state-department-iran-war

- https://x.com/kaitlancollins/status/2028876824051093805

- https://apnews.com/article/trump-iran-maga-regime-change-2758513ac034ffb75beaa12db68c7bd7

- https://www.editorialboard.com/the-epstein-scandal-is-not-a-distraction-its-the-ball-game/

- https://www.editorialboard.com/dam-breaking-coverup-in-view-en-epstein-class-under-threat/

- https://www.nytimes.com/2026/03/03/us/politics/trump-israel-iran.html

# Questions

What specific evidence supports the claim that Israeli Prime Minister Benjamin Netanyahu pressured Donald Trump into entering a war with Iran?

How does the current conflict with Iran impact the domestic economic situation in the United States regarding oil prices and the stock market?

In what ways does the author suggest that the America First movement is fundamentally linked to antisemitic conspiracy theories?

What are the legal implications for a president engaging in a war of choice without the explicit consent of the United States Congress?

How has the failure to release the Epstein files contributed to the perceived crisis of faith among Donald Trump's core MAGA supporters?

----

# Evidence Isreal Lead

## 2017-02-15

During a joint press conference at the White House, Netanyahu emphasized the threat of a nuclear Iran and praised Trump's willingness to challenge the 2015 nuclear deal, setting the stage for a coordinated shift in Middle East policy.

## 2018-04-30

Netanyahu delivered a televised presentation showcasing a massive haul of documents allegedly stolen from a Tehran warehouse by Israeli intelligence, claiming to prove Iran lied about its nuclear weapons program. This event was widely seen as a direct appeal to provide Trump with the political justification to withdraw from the Joint Comprehensive Plan of Action (JCPOA).

## 2018-05-08

Donald Trump officially announced the United States withdrawal from the Iran nuclear deal, a move Netanyahu had lobbied for since the deal's inception. Reports indicated that Netanyahu was a primary influence on the decision through frequent phone calls and strategic intelligence sharing.

## 2019-02-13 - 2019-02-14

During the Warsaw Middle East Summit, Netanyahu was caught on video in a since-deleted social media post speaking in Hebrew about a common interest in war with Iran, though the official English translation was later softened to 'combating' Iran.

## 2020-01-03

Following the US drone strike that killed Iranian General Qasem Soleimani, reports surfaced that Israel provided critical intelligence support for the operation, with Netanyahu being one of the few foreign leaders briefed in advance, signaling deep coordination in escalating military tension.

## 2021-12

Former Trump administration officials, including Jared Kushner, detailed in various memoirs and interviews how Netanyahu consistently pushed for a more 'maximum pressure' approach, often sidelining more cautious advisors in the Pentagon who feared a full scale armed conflict.

## 2025-04-07

During a second-term meeting at the White House, Netanyahu and Trump discussed expanding the 'maximum pressure' campaign, with Netanyahu advocating for tougher limits on Iran's ballistic missile program and regional proxy groups.

## 2025-06-12 - 2025-06-24

During the Twelve-Day War, Netanyahu announced Israeli airstrikes on Iranian nuclear and ballistic missile sites. Trump later stated the US and Israel had 'obliterated' Iranian capabilities, though he eventually pressured Netanyahu to accept a ceasefire to avoid a prolonged war of attrition.

## 2025-11-06

Iranian IRGC officials claimed that Netanyahu and Trump had met two months prior to the June 2025 conflict to plot the overthrow of the Iranian government within three days, citing alleged Israeli media broadcasts as evidence of the coordination.

## 2026-02-11

Netanyahu met with Trump in Washington to push for even stricter conditions in ongoing nuclear negotiations, insisting that Iran stop all uranium enrichment and ballistic missile development while threatening 'many surprises' for the next phase of conflict.

## Interested Parties

- Benjamin Netanyahu

    - Prime Minister of Israel

- Yossi Cohen

    - Former Director of Mossad

- Ron Dermer

    - Former Israeli Ambassador to the United States

- Sara Netanyahu

    - Spouse of the Prime Minister

- Donald Trump

    - 45th and 47th President of the United States

- Mike Pompeo

    - Former Secretary of State and CIA Director

- John Bolton

    - Former National Security Advisor

- Jared Kushner

    - Senior Advisor to the President

- Steve Witkoff

    - US Special Envoy for Peace Missions

- Israel Katz

    - Israeli Defense Minister

- Abbas Araghchi

    - Iranian Minister of Foreign Affairs

- Pete Hegseth

    - US Secretary of Defense

## Sources

- https://www.nytimes.com/2018/04/30/world/middleeast/israel-iran-nuclear-deal.html

- https://www.reuters.com/article/us-usa-iran-nuclear-netanyahu-idUSKBN1I92S0

- https://www.theguardian.com/world/2019/feb/14/netanyahu-accidental-call-for-war-with-iran-warsaw-summit

- https://www.rollingstone.com/politics/politics-news/netanyahu-trump-iran-war-1234812345/

- https://www.pbs.org/newshour/nation/trump-insisted-to-netanyahu-that-iran-talks-continue-as-israel-pushes-for-tougher-limits

- https://www.cfr.org/global-conflict-tracker/conflict/confrontation-between-united-states-and-iran

- https://www.iranintl.com/en/202511066311

- https://www.jpost.com/arab-israeli-conflict/netanyahu-stirs-controversy-in-warsaw-with-mistaken-iran-war-tweet-580602

# Questions

How did the specific intelligence provided by Mossad regarding the Tehran nuclear archive influence Donald Trump's decision to withdraw from the JCPOA in 2018?

What was the nature of the disagreement between Donald Trump and Benjamin Netanyahu regarding the ceasefire that ended the Twelve-Day War in June 2025?

To what extent did Jared Kushner's role as a primary intermediary facilitate the alignment of US and Israeli military objectives toward Iran?

What evidence exists to support the IRGC's claim that a meeting occurred two months prior to the June 2025 war to discuss regime change in Tehran?

How has the introduction of Pete Hegseth as Secretary of Defense altered the US military's direct communication with the Israeli Ministry of Defense regarding Iranian targets?

----

# War Of Choice

When a President initiates a "war of choice"—an offensive military conflict not prompted by an immediate attack on US territory or forces—they navigate a complex web of domestic and international legalities.

## Domestic Constitutional Framework

The US Constitution creates a "shared" zone of power between the Executive and Legislative branches.

### Article I, Section 8 (Declare War Clause)

- Explicitly grants Congress the power to declare war and to "raise and support" military forces. This is generally interpreted as giving the legislature exclusive authority to initiate offensive hostilities.

### Article II, Section 2 (Commander-in-Chief Clause)

- Designates the President as the head of the military. Historically

    - this allows the President to "repel sudden attacks" without waiting for Congress, but does not grant the power to start a war.

### The "Zone of Twilight"

- As defined by Justice Jackson in Youngstown Sheet & Tube Co. v. Sawyer (1952)

    - when a President acts without congressional approval, their power is at its "lowest ebb."

### Statutory Limitations

- The War Powers Resolution (WPR)

- Enacted in 1973 over a presidential veto

    - the WPR attempted to codify the "shared" nature of war powers:

### Notification

- The President must notify Congress within 48 hours of introducing forces into hostilities.

### The 60-Day Clock

- Military action must terminate within 60 days (with a 30-day extension for withdrawal) unless Congress grants an Authorization for Use of Military Force (AUMF) or declares war.

### Enforcement Gaps

- Many Presidents argue the WPR is unconstitutional

    - viewing it as a legislative infringement on their Article II powers. They often report actions "consistent with" rather than "pursuant to" the Act to avoid admitting it is legally binding.

## International Legal Implications

Outside of domestic law, a war of choice may violate the United Nations Charter, which the US ratified as a treaty (making it "the supreme Law of the Land" under the Constitution's Supremacy Clause).

### Article 2(4)

- Prohibits the "threat or use of force against the territorial integrity or political independence of any state."

### Act Of Aggression

- Under international law

    - force is only legal in self-defense (Article 51) or when authorized by the UN Security Council. A war of choice that meets neither criteria is technically an "act of aggression."

## Consequences of Unauthorized War

While the legal theory is clear, the practical consequences are often political rather than judicial.

### Power of the Purse

- Congress can defund the military operation

    - effectively forcing a withdrawal.

### Impeachment

- Unilateral war-making can be categorized as a "High Crime or Misdemeanor," providing grounds for removal from office.

### Judicial Deference

- Federal courts usually refuse to rule on these cases

    - labeling them "political questions" better settled between the President and Congress.

### War Crimes Liability

- Under extreme circumstances

    - initiating an illegal war (a "Crime of Aggression") can lead to international prosecution, though the US is not a member of the International Criminal Court (ICC).

## Sources

- https://constitution.congress.gov/browse/essay/artI-S8-C11-1/ALDE_00001244/

- https://www.law.cornell.edu/wex/war_powers_resolution

- https://www.cfr.org/backgrounder/us-war-powers

- https://history.state.gov/milestones/1969-1976/war-powers-resolution

- https://www.un.org/en/about-us/un-charter/full-text

# Questions

What specific legal arguments have past presidential administrations used to justify military interventions that lasted longer than the 60 day window allowed by the War Powers Resolution?

How does the 'political question doctrine' prevent the judicial branch from providing a definitive ruling on the constitutionality of a war of choice?

In what ways do modern Authorizations for Use of Military Force (AUMF) differ from formal declarations of war in terms of their legal scope and duration?

What are the potential legal risks for individual military commanders who execute orders for a war of choice that has been declared illegal by international bodies?

Could a President be held civilly liable in domestic or international courts for damages resulting from an unauthorized offensive military campaign?

----

# Domestic Civil Liability

The question of whether a President can be held civilly liable for an unauthorized military campaign involves distinct legal hurdles at both the domestic and international levels.

In the United States, the President possesses a unique legal status regarding civil lawsuits arising from official actions.

### Absolute Immunity

- In the landmark case Nixon v. Fitzgerald (1982)

    - the Supreme Court ruled that the President is entitled to absolute immunity from damages liability for acts within the 'outer perimeter' of their official responsibility.

### Official vs. Private Acts

- While Clinton v. Jones (1997) established that a President can be sued for actions taken before entering office or for private acts

    - a military campaign is inherently an exercise of official executive power.

### The Westfall Act

- This federal statute generally protects all federal employees from being sued personally for torts committed within the scope of their employment. If a President orders a military strike

    - the US government is typically substituted as the defendant, and the case is usually dismissed under the doctrine of sovereign immunity.

# International Civil Liability

The prospects for civil liability in international forums are governed by different sets of rules regarding state immunity and individual responsibility.

### State Immunity

- Under international law

    - the principle of 'par in parem non habet imperium' (equals have no authority over one another) generally prevents the courts of one country from sitting in judgment on the official acts of another state's head of state.

### The International Criminal Court (ICC)

- While the ICC focuses on criminal prosecution for the 'crime of aggression,' it does have a Trust Fund for Victims. If a leader were convicted

    - the court could order reparations. However, the US is not a party to the Rome Statute, making this path legally unavailable for a US President.

### Alien Tort Statute (ATS)

- Foreign plaintiffs have attempted to use the ATS to sue US officials in American courts for violations of international law. However

    - recent Supreme Court rulings, such as Kiobel v. Royal Dutch Petroleum Co., have significantly narrowed the ability to use this law for actions occurring outside US territory.

## Interested Parties

- Richard Nixon

    - 37th President of the United States

- A. Ernest Fitzgerald

    - Air Force Management Analyst and Whistleblower

- Bill Clinton

    - 42nd President of the United States

- Paula Jones

    - Former Arkansas State Employee

- John Marshall

    - Former Chief Justice of the Supreme Court

- Lewis F. Powell Jr.

    - Former Associate Justice of the Supreme Court

- Stephen Breyer

    - Former Associate Justice of the Supreme Court

## Sources

- https://supreme.justia.com/cases/federal/us/457/731/

- https://www.law.cornell.edu/constitution-conan/article-2/section-3/presidential-immunity-to-civil-lawsuits

- https://www.ic-cpi.int/about/trust-fund-for-victims

- https://www.fjc.gov/history/administration/westfall-act-1988

- https://www.un.org/en/genocideprevention/documents/atrocity-crimes/Doc.27_Rome%2520Statute%2520ICC.pdf

# Questions

What is the 'outer perimeter' test established in Nixon v. Fitzgerald, and how does it apply to military decisions?

How does the Foreign Sovereign Immunities Act (FSIA) protect or expose a head of state to litigation in foreign domestic courts?

Are there any historical precedents where a world leader was successfully sued for civil damages following an illegal war?

Could a President's immunity be waived by Congress through specific legislation targeting unauthorized military actions?

What role does the 'act of state' doctrine play in preventing US courts from reviewing the legality of foreign military operations?

----

# Individual Responsibility

## 1945-10-24 - 1946-10-01

The Nuremberg Trials established the principle of individual responsibility for crimes against peace. While the focus was criminal, the seizure of assets from high ranking officials represented an early form of financial accountability for state led aggression.

- Robert H. Jackson

    - Chief US Prosecutor at Nuremberg

- Hermann Goering

    - Reichsmarschall of Nazi Germany

- Joachim von Ribbentrop

    - Foreign Minister of Nazi Germany

## 1980-06-30

The US Court of Appeals for the Second Circuit ruled in Filartiga v. Pena-Irala that foreign officials could be sued in US courts for violations of international law. This opened the door for civil litigation against individuals acting under state authority for human rights abuses associated with war.

- Joel Filartiga

    - Plaintiff and Father of Victim

- Americo Pena-Irala

    - Former Inspector General of Police

- Dolly Filartiga

    - Plaintiff and Sister of Victim

## 2000-08-10

In Doe v. Karadzic, a US federal jury awarded 4.5 billion dollars in compensatory and punitive damages to victims of genocide and war crimes. The defendant was the leader of the Bosnian Serbs, marking a successful civil judgment against a head of state for acts related to an illegal war.

- Radovan Karadzic

    - President of Republika Srpska

- Catharine MacKinnon

    - Lead Attorney for Plaintiffs

- S. James Anaya

    - Human Rights Attorney

## 2022-04-14

The Supreme Court of Ukraine ruled that the Russian Federation does not have sovereign immunity regarding damages caused by its military aggression. This decision allows individual citizens to seek civil redress against the state and its leadership in domestic courts.

- Vladimir Putin

    - President of Russia

- Denys Shmyhal

    - Prime Minister of Ukraine

- Markiyan Kliuchkovskyi

    - Executive Director of the Register of Damage

## 2024-04-02

The Register of Damage for Ukraine became operational in The Hague. This international mechanism serves as a record for claims of evidence and damages caused by the acts of aggression, facilitating a future path for civil compensation and reparations.

- Denys Shmyhal

    - Prime Minister of Ukraine

- Markiyan Kliuchkovskyi

    - Executive Director of the Register of Damage

- Vladimir Putin

    - President of Russia

## Interested Parties

- Robert H. Jackson

    - Chief US Prosecutor at Nuremberg

- Hermann Goering

    - Reichsmarschall of Nazi Germany

- Joachim von Ribbentrop

    - Foreign Minister of Nazi Germany

- Joel Filartiga

    - Plaintiff and Father of Victim

- Americo Pena-Irala

    - Former Inspector General of Police

- Dolly Filartiga

    - Plaintiff and Sister of Victim

- Radovan Karadzic

    - President of Republika Srpska

- Catharine MacKinnon

    - Lead Attorney for Plaintiffs

- S. James Anaya

    - Human Rights Attorney

- Vladimir Putin

    - President of Russia

- Denys Shmyhal

    - Prime Minister of Ukraine

- Markiyan Kliuchkovskyi

    - Executive Director of the Register of Damage

# Questions

How does the doctrine of sovereign immunity typically protect world leaders from being sued in the domestic courts of foreign nations?

What specific legal mechanisms allow for the seizure of a world leader's private offshore assets to satisfy a civil judgment?

In what ways does the Alien Tort Statute differ from the Torture Victim Protection Act when pursuing damages for war related atrocities?

Has any world leader ever actually paid a civil settlement out of their personal wealth following a court order for an act of aggression?

What role do international claims commissions play in bypassing the traditional court system to provide reparations to victims of illegal wars?

## Sources

- https://www.icj-cij.org/en/decisions

- https://judicial.gov.ua/eng

- https://www.state.gov/key-topics-office-of-the-legal-adviser/

- https://rd4u.org/

- https://caselaw.findlaw.com/court/us-2nd-circuit/1131105.html

----

----