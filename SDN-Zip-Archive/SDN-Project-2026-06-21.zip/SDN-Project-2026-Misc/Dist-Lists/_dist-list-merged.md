### SDN-00-01-FOMO-Dist-List-ACLU-Lawyers-mailto

- mailto:media@aclu.org
- mailto:aclufl@aclufl.org
- mailto:media@nyclu.org
- mailto:media@acluaz.org
- mailto:media@acludc.org
- mailto:media@aclum.org

----


### SDN-00-18-FOMO-Dist-List-US-State-AGs-mailto

# Attorneys General

- mailto:ConsumerInterest@AlabamaAG.gov
- mailto:consumerprotection@alaska.gov
- mailto:attorney.general@alaska.gov
- mailto:consumerinfo@azag.gov
- mailto:Attorney.General@azag.gov
- mailto:consumer@ArkansasAG.gov
- mailto:Attorney.General@ct.gov
- mailto:attorney.general@delaware.gov
- mailto:oag@dc.gov
- mailto:oagpress@dc.gov
- mailto:contactag@myfloridalegal.com
- mailto:consumerprotection@law.ga.gov
- mailto:hawaiiag@hawaii.gov
- mailto:idahoag@ag.idaho.gov
- mailto:PressOffice@ilag.gov
- mailto:constituent@atg.in.gov
- mailto:webteam@ag.iowa.gov
- mailto:consumer.consumer@ag.iowa.gov
- mailto:info@ag.ks.gov
- mailto:attorney.general@ag.ky.gov
- mailto:constituentservices@ag.louisiana.gov
- mailto:attorney.general@maine.gov
- mailto:oag@oag.state.md.us
- mailto:consumer@oag.state.md.us
- mailto:ago@mass.gov
- mailto:miag@michigan.gov
- mailto:attorney.general@ag.state.mn.us
- mailto:info@ago.state.ms.us
- mailto:attorney.general@ago.mo.gov
- mailto:consumer.help@ago.mo.gov
- mailto:ago.info.help@nebraska.gov
- mailto:ago.consumer@nebraska.gov
- mailto:AGInfo@ag.nv.gov
- mailto:DOJ-CPB@doj.nh.gov
- mailto:nmag@nmag.gov
- mailto:ndag@nd.gov
- mailto:ConsumerProtection@oag.ok.gov
- mailto:AttorneyGeneral@doj.state.or.us
- mailto:consumerhelp@state.sd.us
- mailto:scdca@scconsumer.gov
- mailto:consumerhelp@state.sd.us
- mailto:uag@agutah.gov
- mailto:ago.info@vermont.gov
- mailto:CRC@atg.wa.gov
- mailto:consumer@wvago.gov
- mailto:ag.consumer@wyo.gov

----
### SDN-00-03-FOMO-Dist-List-Project-2025-mailto

- mailto:kevin.roberts@heritage.org
- mailto:paul.dans@heritage.org
- mailto:steven.groves@heritage.org
- mailto:roger.severino@heritage.org
- mailto:spencer.chretien@heritage.org
- mailto:derrick.morgan@heritage.org
- mailto:wesley.coopersmith@heritage.org
- mailto:therese.pennefather@heritage.org
- mailto:william.poole@heritage.org
- mailto:marla.hess@heritage.org
- mailto:jessica.lowther@heritage.org
- mailto:hellojesslowther@gmail.com
- mailto:karina.rollins@heritage.org
- mailto:jordan.embree@heritage.org
- mailto:sarah.calvis@heritage.org
- mailto:jonathan.moy@heritage.org
- mailto:info@citizensforethics.org
- mailto:contact@americancornerstone.org
- mailto:info@heritage.org
- mailto:John-Ratcliffe@heritage.org
- mailto:info@heritage.org
- mailto:Peter-Navarro@heritage.org
- mailto:daren.bakst@cei.org
- mailto:info@claremont.org
- mailto:info@heritage.org
- mailto:Chad-Padgett@heritage.org
- mailto:info@heritage.org
- mailto:Leah-Pedersen@heritage.org
- mailto:contact@americancornerstone.org
- mailto:emma.waters@heritage.org
- mailto:rachael.wilfong@heritage.org
- mailto:thepowerhour@heritage.org

----
### SDN-00-04-FOMO-Dist-List-Streamers-mailto

- mailto:info@joerogan.net
- mailto:support@tuckercarlson.com
- mailto:press@dailywire.com
- mailto:info@bongino.com
- mailto:info@candaceowens.com
- mailto:info@devilmaycaremedia.com
- mailto:tim@timcast.com
- mailto:info@louderwithcrowder.com
- mailto:piers@piersmorgan.com
- mailto:info@valuetainment.com
- mailto:rachel@msnbc.com
- mailto:info@crooked.com
- mailto:brian@briantylercohen.com
- mailto:producers@majority.fm
- mailto:ezrakleinshow@nytimes.com
- mailto:info@longwellpartners.com
- mailto:staytuned@cafe.com
- mailto:info@davidpakman.com
- mailto:support@tyt.com
- mailto:hasanpikerbiz@gmail.com
- mailto:rogan@dcdraino.com
- mailto:jessica@houseinhabit.com
- mailto:liz@lizwheeler.com
- mailto:jack@humanityprojects.com
- mailto:chaya@libsoftiktok.com
- mailto:liz@lawyeroyer.com

----
### SDN-00-05-FOMO-Dist-List-US-Victim-Lawyers-mailto

- mmailto:info@bsfllp.com
- mmailto:media@bsfllp.com
- mmailto:recruiting@bsfllp.com
- mmailto:info@ecbawm.com
- mmailto:intake@ecbawm.com
- mmailto:careers@ecbawm.com
- mmailto:communications@law.utah.edu
- mmailto:admissions@law.utah.edu
- mmailto:career@law.utah.edu
- mmailto:info@kaplanhecker.com
- mmailto:media@kaplanhecker.com
- mmailto:rkaplan@kaplanhecker.com
- mmailto:info@edwardspottinger.com
- mmailto:intake@edwardspottinger.com
- mmailto:bedwards@edwardspottinger.com
- mmailto:newyork@quinnemanuel.com
- mmailto:contactus@quinnemanuel.com
- mmailto:alexspiro@quinnemanuel.com
- mmailto:gallred@amglaw.com
- mmailto:info@amglaw.com
- mmailto:info@mersonlaw.com
- mmailto:intake@mersonlaw.com
- mmailto:help@marsh.law
- mmailto:intake@marsh.law
- mmailto:glassman@psblaw.com
- mmailto:info@psblaw.com
- mmailto:info@sokolovelaw.com
- mmailto:lwolosky@jenner.com
- mmailto:communications@jenner.com

----

----
### SDN-00-06-FOMO-Dist-List-US-Academics-mailto

- mailto:aharberg@wbur.org
- mailto:mdallek@gwu.edu
- mailto:mtaylor@icjs.org
- mailto:srhbukhari@jrsr.edu
- mailto:mkashif@jrsr.edu

----
### SDN-00-07-FOMO-Dist-List-US-Media-mailto

- mailto:msisak@ap.org  
- mailto:adurbin@ap.org  
- mailto:etucker@ap.org  
- mailto:ben@meidastouch.com  
- mailto:ron@meidastouch.com  
- mailto:brett@meidastouch.com  
- mailto:macfarlanes@cbsnews.com  
- mailto:kaia.hubbard@cbsinteractive.com  
- mailto:melissa.quinn@cbsinteractive.com  
- mailto:sfowler@npr.org  
- mailto:jdiaz@npr.org  
- mailto:sneuman@npr.org  
- mailto:llanders@newshour.org  
- mailto:ldesjardins@newshour.org  
- mailto:mfinnegan@newshour.org  
- mailto:john@other98.com  
- mailto:andy@other98.com  
- mailto:action@other98.com  
- mailto:omar@occupydemocrats.com  
- mailto:omar@tribel.com  
- mailto:rafael@occupydemocrats.com  
- mailto:grant@occupydemocrats.com  
- mailto:news@axios.com  
- mailto:info@axios.com  
- mailto:pips@axios.com  
- mailto:press@axios.com  

----
### SDN-00-08-FOMO-Dist-List-US-Govt-Cabinet-mailto

- mailto:comments@whitehouse.gov
- mailto:vice_president@whitehouse.gov
- mailto:president@whitehouse.gov
- mailto:newsadmin@whitehouse.gov
- mailto:press@who.eop.gov
- mailto:vice_president@whitehouse.gov
- mailto:press@state.gov
- mailto:osd.pa.dutyofficer@mail.mil
- mailto:press@treasury.gov
- mailto:press@usdoj.gov
- mailto:interior_press@ios.doi.gov
- mailto:press@usda.gov
- mailto:publicaffairs@doc.gov
- mailto:press@dol.gov
- mailto:press@hhs.gov
- mailto:hudpressoffice@hud.gov
- mailto:pressoffice@dot.gov

----

### SDN-00-09-FOMO-Dist-List-US-Govt-House-mailto

- mailto:sara.guerrero@mail.house.gov
- mailto:Crgdistrict@mail.house.gov
- mailto:Raskin.Casework@mail.house.gov
- mailto:info@summerforpa.com
- mailto:press@summerforpa.com
- mailto:melvin.soto@mail.house.gov
- mailto:us@ocasiocortez.com

----
### SDN-00-10-FOMO-Dist-List-US-Govt-Senate-mailto

- mailto:adan_sanchez@lujan.senate.gov
- mailto:allison_biasotti@schumer.senate.gov
- mailto:angela_ramponi@murkowski.senate.gov
- mailto:audrey_cook@blackburn.senate.gov
- mailto:ausan_al-eryani@merkley.senate.gov
- mailto:bobby_andres@schumer.senate.gov
- mailto:caty_payette@heinrich.senate.gov
- mailto:clare_slattery@grassley.senate.gov
- mailto:david_bader@grassley.senate.gov
- mailto:emily_hampsten@durbin.senate.gov
- mailto:HSGACPress_Paul@hsgac.senate.gov
- mailto:josh_sorbe@judiciary-dem.senate.gov
- mailto:kaleb_froehlich@murkowski.senate.gov
- mailto:luis_soriano@heinrich.senate.gov
- mailto:natalie_yezbick@cornyn.senate.gov
- mailto:paul_schedule@paul.senate.gov
- mailto:press@baldwin.senate.gov
- mailto:press@barrasso.senate.gov
- mailto:press@bennet.senate.gov
- mailto:press@brown.senate.gov
- mailto:press@cantwell.senate.gov
- mailto:press@cardin.senate.gov
- mailto:press@casey.senate.gov
- mailto:press@fischer.senate.gov
- mailto:press@hirono.senate.gov
- mailto:press@kaine.senate.gov
- mailto:press@murphy.senate.gov
- mailto:press@peters.senate.gov
- mailto:press@tester.senate.gov
- mailto:press@warner.senate.gov
- mailto:press@whitehouse.senate.gov
- mailto:press_paul@paul.senate.gov
- mailto:tatum_wallace@cornyn.senate.gov

----

### SDN-00-11-FOMO-Dist-List-US-Newspapers-National-mailto

- mailto:newsroom@washpost.com
- mailto:op-ed@washpost.com
- mailto:tips@politico.com
- mailto:oped@politico.com
- mailto:newseditors@wsj.com
- mailto:letters@wsj.com
- mailto:news-tips@nypost.com
- mailto:tips@nypost.com
- mailto:news-tips@nytimes.com
- mailto:oped@nytimes.com
- mailto:oped@usatoday.com
- mailto:news@usatoday.com
- mailto:newsroom@chicagotribune.com
- mailto:news@startribune.com
- mailto:tips@startribune.com
- mailto:newsroom@post-dispatch.com
- mailto:news@bostonglobe.com
- mailto:news@newsday.com
- mailto:oped@newsday.com
- mailto:news@nydailynews.com
- mailto:metro@latimes.com
- mailto:news@sfchronicle.com
- mailto:chronicleletters@sfchronicle.com
- mailto:newstips@seattletimes.com
- mailto:opinsight@seattletimes.com

----
### SDN-00-12-FOMO-Dist-List-US-Newspapers-Local-mailto

- mailto:newsroom@bayareanewsgroup.com
- mailto:news@presstelegram.com
- mailto:op-ed@latimes.com
- mailto:metro@latimes.com
- mailto:opeds@baltimoresun.com
- mailto:tips@baltimoresun.com
- mailto:newsroom@post-gazette.com
- mailto:oped@post-gazette.com
- mailto:insight@orlandosentinel.com
- mailto:oped@sptimes.com
- mailto:news@tampabay.com
- mailto:news@courier-journal.com
- mailto:news@knoxnews.com
- mailto:news@journalstar.com
- mailto:oped@journalstar.com
- mailto:news@houstonchronicle.com

----
### SDN-00-13-FOMO-Dist-List-US-Agency-mailto

- mailto:press@epa.gov
- mailto:press@ntia.gov
- mailto:press@gsa.gov
- mailto:press@fec.gov
- mailto:press@cftc.gov
- mailto:press@dnfsb.gov
- mailto:press@osec.doc.gov
- mailto:press@cms.hhs.gov
- mailto:press@fincen.gov
- mailto:press@stb.gov
- mailto:press@pbgc.gov
- mailto:media@omb.eop.gov
- mailto:media@uscis.dhs.gov
- mailto:media@frb.gov
- mailto:media@fcc.gov
- mailto:media@eeoc.gov
- mailto:media@osmre.gov
- mailto:media@oge.gov
- mailto:media@peacecorps.gov
- mailto:publicaffairs@doc.gov
- mailto:publicaffairs@fws.gov
- mailto:publicaffairs@trade.gov
- mailto:newsmedia@nps.gov
- mailto:newsmedia@bia.gov
- mailto:doenews@hq.doe.gov
- mailto:ocpa@bis.doc.gov
- mailto:m-dolpublicaffairs@dol.gov
- mailto:PAPressDuty@state.gov
- mailto:mediarequests@state.gov
- mailto:Interior_Press@ios.doi.gov
- mailto:blm_press@blm.gov
- mailto:askdoj@usdoj.gov
- mailto:press@usdoj.gov
- mailto:dea.public.affairs@usdoj.gov
- mailto:info@dea.gov
- mailto:community.outreach@dea.gov

----
### SDN-00-14-FOMO-Dist-List-US-Foreign-Relations-mailto

- mailto:lhcenter@iu.edu
- mailto:lhhamilt@indiana.edu
- mailto:shelby.senate@mail.senate.gov
- mailto:contact@hillsandcompany.com
- mailto:info@clarkhill.com
- mailto:info@unfoundation.org

----
### SDN-00-22-FOMO-Dist-List-Deans-Poly-Sci

- mailto:govdept@fas.harvard.edu  
- mailto:polisci@stanford.edu  
- mailto:politics@princeton.edu  
- mailto:politicalscience@yale.edu  
- mailto:polisci@berkeley.edu  
- mailto:polisci@mit.edu  
- mailto:polisci@columbia.edu  
- mailto:polisci-info@umich.edu  
- mailto:polisci@uchicago.edu  
- mailto:polisci@duke.edu  
- mailto:polisci@ucsd.edu  
- mailto:government@cornell.edu  
- mailto:polisci@ucla.edu  
- mailto:polisci@polisci.wisc.edu  
- mailto:polisci@unc.edu  
- mailto:government@georgetown.edu  
- mailto:polisci@uw.edu  
- mailto:polisci@osu.edu  
- mailto:government@austin.utexas.edu  
- mailto:polisci@jhu.edu

----
