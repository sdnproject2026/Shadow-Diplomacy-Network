# Legacy Senators

```
info@theabrahamgroup.com, info@ashcroftlawfirm.com, info@baucusinstitute.org, president@whitehouse.gov, steyer-taylor@law.stanford.edu, info@mercuryllc.com, info@allen-co.com, info@thencrf.org, clientservices@fennemorelaw.com, info@bipartisanpolicy.org, info@parkstrategies.com, info@afslaw.com, press@atlanticcouncil.org, info@galvanizeclimate.com, communications@tenethealth.com, info@moffitt.org, info@usadf.gov, info@patriotvoices.com, info@snoweleadershipinstitute.org, info@rosemontassociates.com
```