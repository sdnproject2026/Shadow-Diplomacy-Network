
- bloodinthesinkcontact@gmail.com
    - theparanormalfiles
    - facebook