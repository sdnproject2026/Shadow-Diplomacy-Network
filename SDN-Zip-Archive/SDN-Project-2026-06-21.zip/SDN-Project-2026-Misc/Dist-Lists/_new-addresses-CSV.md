# new addresses

```
media@infowars.com, warroom@pandemic.warroom.org, repjayapal@mail.house.gov, info@spanbergerforva.com, comer@mail.house.gov, info@historyauthors.org, info@kirklandwa.gov, media@jpmorgan.com, contact@justice.gouv.fr, info@justice.gc.ca, postmottak@politiet.no, info@justice.gov.sk, public.enquiries@cps.gov.uk

```

NYT

```
tiffany.hsu@nytimes.com, ken.bensinger@nytimes.com
```
