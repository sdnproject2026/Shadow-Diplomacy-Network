# Drudge URLs Emails

### wsj.com

- NA

### hollywoodreporter.com

- tips@thr.com

### the-express.com

- NA

### mmafighting.com

- tips@mmafighting.com

### cnn.com

- cnn.tips@cnn.com

### metro.co.uk

- news@metro.co.uk

### economist.com

- letters@economist.com

### washingtonpost.com

- tips@washpost.com

### cnbc.com

- cnbctips@nbcuni.com

### archive.is

- NA

### deadline.com

- tips@deadline.com

### telegraph.co.uk

- dtinvestigations@telegraph.co.uk

### archive.ph

- NA

### nytimes.com

- tips@nytimes.com

### nbcnews.com

- tips@nbcuni.com

### trends.google.com

- press@google.com

### pressreader.com

- support@pressreader.com

### news.sky.com

- news@skynews.com

### boxofficemojo.com

- NA

### ustvdb.com

- NA

### apnews.com

- info@ap.org

### abcnews.com

- news.tips@abc.com

### theatlantic.com

- letters@theatlantic.com

### axios.com

- tips@axios.com

### bbc.co.uk

- haveyoursay@bbc.co.uk

### billboard.com

- tips@billboard.com

### boston.com

- feedback@boston.com

### bostonherald.com

- news@bostonherald.com

### breitbart.com

- tips@breitbart.com

### businessinsider.com

- tips@businessinsider.com

### cbsnews.com

- newsdesk@cbsnews.com

### cbslocal.com

- NA

### c-span.org

- comments@c-span.org

### suntimes.com

- newsroom@suntimes.com

### chicagotribune.com

- ctc-news@chicagotribune.com

### csmonitor.com

- letters@csmonitor.com

### crazydaysandnights.net

- NA

### thedailybeast.com

- tips@thedailybeast.com

### dailycaller.com

- tips@dailycaller.com

### elnuevodia.com

- cartas@elnuevodia.com

### ew.com

- letters@ew.com

### foxnews.com

- newsmanager@foxnews.com

### thefp.com

- tips@thefp.com

### thehill.com

- tips@thehill.com

### huffingtonpost.com

- corrections@huffpost.com

### theintercept.com

- tips@theintercept.com

### dailynewslosangeles.com

- NA

### latimes.com

- tips@latimes.com

### marketwatch.com

- feedback@marketwatch.com

### mediaite.com

- tips@mediaite.com

### motherjones.com

- tips@motherjones.com

### thenation.com

- letters@thenation.com

### nationalreview.com

- corner@nationalreview.com

### thenewrepublic.com

- letters@tnr.com

### nymag.com

- tips@nymag.com

### nydailynews.com

- voicers@nydailynews.com

### nypost.com

- tips@nypost.com

### newyorker.com

- themail@newyorker.com

### newsmax.com

- tips@newsmax.com

### newzit.com

- NA

### people.com

- editor@people.com

### politico.com

- tips@politico.com

### rawstory.com

- tips@rawstory.com

### reason.org

- info@reason.org

### rollcall.com

- tips@rollcall.com

### rollingstone.com

- tips@rollingstone.com

### salon.com

- letters@salon.com

### sfgate.com

- tips@sfgate.com

### semafor.com

- tips@semafor.com

### showbiz411.com

- roger@showbiz411.com

### thesmokinggun.com

- tips@thesmokinggun.com

### stateline.org

- letters@stateline.org

### tmz.com

- tips@tmz.com

### usnews.com

- editor@usnews.com

### usatoday.com

- tips@usatoday.com

### vanityfair.com

- vfmail@vf.com

### variety.com

- tips@variety.com

### washingtonexaminer.com

- tips@washingtonexaminer.com

### washingtontimes.com

- tips@washingtontimes.com

### worldofreel.com

- jordan@worldofreel.com

### thewrap.com

- tips@thewrap.com

### pagesix.com

- tips@nypost.com

### theguardian.com

- guardian.readers@theguardian.com

### studyfinds.com

- tips@studyfinds.org

### futurism.com

- tips@futurism.com

### africanews.com

- contact@africanews.com

### arabnews.com

- editor@arabnews.com

### bild.de

- info@bild.de

### en.people.cn

- webmaster@people.cn

### clarin.com

- cartas@clarin.com

### welt.de

- redaktion@welt.de

### zeit.de

- leserbriefe@zeit.de

### elmundo.es

- cartasdirector@elmundo.es

### english.elpais.com

- defensor@elpais.es

### ft.com

- letters.editor@ft.com

### folha.uol.com.br

- leitor@uol.com.br

### wyborcza.pl

- listy@wyborcza.pl

### gbnews.com

- news@gbnews.uk

### haaretz.com

- letters@haaretz.co.il

### hindustantimes.com

- letters@hindustantimes.com

### hurriyetdailynews.com

- letters@hurriyetdailynews.com

### japantimes.co.jp

- letters@japantimes.co.jp

### jpost.com

- letters@jpost.com

### la-prensa.com.mx

- NA

### repubblica.it

- lettere@repubblica.it

### lefigaro.fr

- courrier@lefigaro.fr

### lemonde.fr

- courrier-des-lecteurs@lemonde.fr

### lesoir.be

- courrier@lesoir.be

### themoscowtimes.com

- newsroom@themoscowtimes.com

### theneweuropean.co.uk

- letters@theneweuropean.co.uk

### asia.nikkei.com

- letters@nikkei.com

### riotimesonline.com

- editor@riotimesonline.com

### smh.com.au

- letters@smh.com.au

### timesofindia.indiatimes.com

- toi.news@timesgroup.com

### dailymail.co.uk

- tips@dailymail.com

### mirror.co.uk

- newsdesk@mirror.co.uk

### dailystar.co.uk

- news@dailystar.co.uk

### express.co.uk

- newsdesk@express.co.uk

### independent.co.uk

- newsdesk@independent.co.uk

### standard.co.uk

- news@standard.co.uk

### thesun.co.uk

- exclusive@the-sun.co.uk

### thetimes.com

- letters@thetimes.co.uk

### theyeshivaworld.com

- editor@theyeshivaworld.com

### japannews.yomiuri.co.jp

- webmaster@yomiuri.com

### france24.com

- observers@france24.com

### bloomberg.com

- tips@bloomberg.net

### nordot.app

- support@nordot.jp

### dw.com

- info@dw.com

### interfax.com

- office@interfax.com

### itar-tass.com

- office@tass.ru

### english.kyodonews.net

- english@kyodonews.jp

### mcclatchydc.com

- NA

### nhk.or.jp

- comments@nhk.or.jp

### pravdareport.com

- editor@pravdareport.com

### ptinews.com

- feedback@ptinews.com

### reuters.com

- tips@thomsonreuters.com

### xinhuanet.com

- english@news.cn

### english.yonhapnews.co.kr

- english@yna.co.kr

----

----
