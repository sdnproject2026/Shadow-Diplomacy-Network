# Epstein 2019

## Hidden Handwritten Suicide

### May 6th, 2026

In May 2026, The NYT successfully petitioned a federal judge to unseal a previously hidden handwritten suicide note. 

### July 2019

The document was reportedly penned by convicted sex offender Jeffrey Epstein inside Manhattan's Metropolitan Correctional Center (MCC) following his first, unsuccessful suicide attempt in July 2019. 

### Nicholas Tartaglione

Because it was tucked away in an unrelated case file belonging to his former cellmate, Nicholas Tartaglione, the Department of Justice and federal investigators were completely unaware of its existence for nearly seven years. 

### Second Note

Forensic document examiners have since concluded that the writing almost certainly matches a second note discovered in Epstein’s cell after his actual death, providing rare insight into his frame of mind.

## Timeline

### July 6, 2019

- Jeffrey Epstein is arrested on federal sex trafficking charges involving minors and placed in MCC New York.

### July 23, 2019

- Epstein is discovered injured in his cell from a suspected first suicide attempt. His cellmate, Nicholas Tartaglione, claims he found a handwritten note written on a yellow legal pad tucked inside a graphic novel shortly after. 

### July 27, 2019

- Fearing he would be blamed for assaulting Epstein, Tartaglione informs his defense attorney of the note's existence to prove Epstein was actively suicidal.

### August 10, 2019

- Epstein dies by suicide in a different jail cell. Authorities find a separate note in the cell containing the phrase "NO FUN".

### 2021

- Tartaglione’s legal team quietly files the first note under seal as part of a dispute in Tartaglione's unrelated legal proceedings. The DOJ misses it during its massive investigative review. 

### Late April 2026

- The New York Times discovers the note's existence and files a legal petition demanding it be unsealed. 

### May 6, 2026

- U.S. District Judge Kenneth Karas orders the immediate public unsealing of the document. 

## Key Persons

### Jeffrey Epstein

- The disgraced millionaire financier and convicted sex offender who allegedly wrote the note detailing his bleak outlook on his pending trial.

### Nicholas Tartaglione

- Epstein's cellmate in July 2019. A former police officer convicted of a quadruple homicide, Tartaglione intercepted the note and utilized it within his own legal files.

### Judge Kenneth M. Karas

- The U.S. District Judge for the Southern District of New York who granted the motion to make the secret text public.

### Bruce Barket & John Wieder

- Tartaglione's defense attorneys who received the physical note in 2019 and protected it under attorney-client privilege.

## Sources

- https://www.nytimes.com/2026/05/06/nyregion/epstein-suicide-note.html





- April 30, 2026

   - https://www.nytimes.com/2026/04/30/us/jeffrey-epstein-suicide-note-sealed.html

- May 6, 2026

   - https://www.nytimes.com/2026/05/06/nyregion/epstein-suicide-note.html

- May 6, 2026

   - https://nymag.com/intelligencer/article/jeffrey-epstein-alleged-suicide-note.html

- May 7, 2026

   - https://www.npr.org/2026/05/07/nx-s1-5814808/jeffrey-epstein-suicide-note

- May 6, 2026

   - https://www.theguardian.com/us-news/2026/may/06/jeffrey-epstein-alleged-suicide-note

- May 7, 2026

   - https://www.bbc.com/news/articles/cd7pd0rqwreo

- May 7, 2026

   - https://www.reuters.com/world/us/new-york-judge-releases-purported-epstein-suicide-note-2026-05-07/

- May 6, 2026

   - https://www.pbs.org/newshour/nation/judge-releases-note-that-cellmate-says-he-found-after-epsteins-suspected-suicide-attempt

- May 6, 2026

   - https://www.courthousenews.com/supposed-epstein-jail-cell-suicide-note-unsealed/

- May 1, 2026

   - https://www.independent.co.uk/news/world/americas/epstein-suicide-note-hidden-judge-b2968446.html

- May 6, 2026

   - https://www.wbaltv.com/article/judge-unseals-jeffrey-epstein-suicide-note/71234795

- January 30, 2026

   - https://www.justice.gov/opa/pr/department-justice-publishes-35-million-responsive-pages-compliance-epstein-files

- July 30, 2026

   - https://www.britannica.com/topic/The-Epstein-Files-A-Timeline

----

----
