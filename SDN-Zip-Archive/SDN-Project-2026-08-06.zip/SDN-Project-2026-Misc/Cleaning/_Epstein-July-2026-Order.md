Trump's Justice Department spent months insisting it could not show anyone the unredacted Epstein files. On Thursday afternoon, with thirty-two minutes left on a federal judge's deadline, it hand-delivered them to his chambers.

Nobody volunteered this. A journalist and attorney named Katie Phang sued Todd Blanche, Trump's former criminal defense lawyer and now his acting attorney general, to shake the files loose. 

Last week, Judge Emmet Sullivan gave Blanche until 3 p.m. Thursday to produce the unredacted records for his private review, along with something more dangerous: documentation proving the redactions are what the department claims they are.

Phang laid it out when the order came down: "In my lawsuit against Todd Blanche for the Epstein Files, Judge Sullivan has just ordered Blanche to produce, in camera, the UNREDACTED emails & documents, and Blanche must bring documentation supporting his representations the DOJ's redactions are what he claims they are."

In other words: prove it.

Here is what the judge's own order says the disputed records contain. 

At least eight email exchanges with Epstein about a "torture video" and sexual activity with young women, including minors. And FBI interview notes about a woman who alleges Trump assaulted her when she was a minor. 

That allegation is unproven. What's not in dispute is that this Justice Department blacked it out, and it took a federal court to force it into the light of even one judge's chambers.

Be clear about what happened and what didn't. The files are not public. No names came out Thursday. 

They went to a single judge behind a closed door.

But for the first time since this administration began sitting on them, someone who does not answer to Donald Trump is reading them without the black ink, and the government has to justify every redaction instead of just asserting it.

And that was the better half of Blanche's week.

On Wednesday night, the Senate Judiciary Committee postponed the vote on his confirmation as attorney general. The votes were not there. Epstein survivors had camped in Senator John Cornyn's office urging exactly that outcome. 

Annie Farmer, who testified against Epstein, met with Blanche and came away calling him "abrasive, condescending, and intentionally noncommittal to survivors."

Trump responded the way he responds. "Todd Blanche is a STAR, and everyone knows it!" he posted. "He has the potential to go down as one of the Greatest Attorney Generals of All Time." 

Then he claimed he had personally ended the careers of John Cornyn and Thom Tillis, the two Republican holdouts, adding that Blanche "will remain, in any event, as Acting."

Cornyn answered in public, in one cold sentence: "POTUS is mistaken if he believes concerns about the provisions in his tax lawsuit settlement are limited to me and Senator Tillis."

The holdouts' stated objection is Trump's sweetheart IRS settlement, not Epstein. It doesn't change the arithmetic. 

The nominee can't get out of committee, the survivors are in the hallway, and the files he fought to keep dark are open on a judge's desk.

Trump made his own defense lawyer the nation's top law enforcement officer.

The defense is starting to crack.

—