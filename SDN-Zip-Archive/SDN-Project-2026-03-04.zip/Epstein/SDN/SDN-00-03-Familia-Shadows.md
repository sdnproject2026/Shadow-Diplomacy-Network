# Epstein List-of-Lists SDN

> Given this, herein, list of URL's,  a non-duplicate list of people names found in the URL pages; list lines format last name 1st, first name 2nd, etc. Alpha sort sublists within categories.

> In Broad categories, as found below, group the people names by primary profession or public role, assign "Miscellaneous" names to categories via known familial or associative ties to other names listed; where applicable create new categories. keep this as a flat category list for clarity.

-----

# Categories

- Political
- Royalty
- Business
- Entertainment / Media
- Finance / Economics
- Legal
- Academic
- Epstein Associates / Staff

# URL's

## SDN-00-00-Metadata-Subset-02
- ASCII text content
- Markdown / HTML formatted text
- Linux EOL characters

## pastebin.com

SDN-10-Barr-Family
- https://pastebin.com/raw/NfHE41xC

SDN-12-Khashoggi-Family
- https://pastebin.com/raw/Uzm9esA0

SDN-13-Legal
- https://pastebin.com/raw/sVWL1KcY

SDN-18-Miss-Teen-Pageants
- https://pastebin.com/raw/zcm7b1fy


^ ## tinyurl.com


^ Each tinyurl references a controlc.com URL, where each controlc.com URL expires 72 hours after creation.

- Tuesday, March 3, 2026, at 11:00 PM

SDN-00-02-Familia-Wiki

^ - https://tinyurl.com/SDN-00-02-Familia-Wiki

SDN-08-Epstein-Family

^ - https://tinyurl.com/SDN-08-Epstein-Family2

SDN-09-Maxwell-Family

^ - https://tinyurl.com/SDN-09-Maxwell-Family

SDN-11-Kushner-Family

^ - https://tinyurl.com/SDN-11-Kushner-Family-002

SDN-14-Financial

^ - https://tinyurl.com/SDN-14-Financial

SDN-16-Bondi-Nothing

^ - https://tinyurl.com/SDN-16-Bondi-Nothing

SDN-17-Government-Officials

^ - https://tinyurl.com/SDN-17-Government-Officials

SDN-20-Heritage-Foundation

^ - https://tinyurl.com/SDN-20-Heritage-Foundation

SDN-23-Hills-Family

^ - https://tinyurl.com/SDN-23-Hills-Family

SDN-24-Russia

^ - https://tinyurl.com/SDN-24-Russia

SDN-25-China

^ - https://tinyurl.com/SDN-25-China

SDN-26-Siebold-Teens

^ - https://tinyurl.com/SDN-26-Siebold-Teens

SDN-27-Chain-Reaction-2010

^ - https://tinyurl.com/SDN-27-Chain-Reaction-2010

----

----
