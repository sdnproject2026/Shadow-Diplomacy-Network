# SDN Distribution List TOC

In early 2026, the implementation of the _Epstein Files Transparency Act_ led to the release of over 3.5 million pages of Department of Justice records.

This massive data dump has shifted reporting from traditional investigation to high-speed digital analysis, with academic researchers and independent voices playing a significant role in dissecting the files alongside established media outlets.

### SDN-00-01-FOMO-Dist-List-ACLU-Lawyers-mailto
- [https://pastebin.com/raw/dg185jjy](https://pastebin.com/raw/dg185jjy)
- [https://rentry.co/62iev8n6](https://rentry.co/62iev8n6)

### SDN-00-02-FOMO-Dist-List-US-State-AGs-mailto
- [https://pastebin.com/raw/CYEHDXFJ](https://pastebin.com/raw/CYEHDXFJ)
- [https://rentry.co/g8gbicmk](https://rentry.co/g8gbicmk)

### SDN-00-03-FOMO-Dist-List-Project-2025-mailto
- [https://pastebin.com/raw/6L8uPdUs](https://pastebin.com/raw/6L8uPdUs)
- [https://rentry.co/y3wyt9hc](https://rentry.co/y3wyt9hc)

### SDN-00-04-FOMO-Dist-List-Streamers-mailto
- [https://pastebin.com/raw/v9VS5grJ](https://pastebin.com/raw/v9VS5grJ)
- [https://rentry.co/gb5bioc7](https://rentry.co/gb5bioc7)

### SDN-00-05-FOMO-Dist-List-US-Victim-Lawyers-mailto
- [https://pastebin.com/raw/ArwTH6yX](https://pastebin.com/raw/ArwTH6yX)
- [https://rentry.co/vzxrryoh](https://rentry.co/vzxrryoh)

### SDN-00-06-FOMO-Dist-List-US-Academics-mailto
- [https://pastebin.com/raw/bjrSFZNY](https://pastebin.com/raw/bjrSFZNY)
- [https://rentry.co/anieo9cu](https://rentry.co/anieo9cu)

### SDN-00-07-FOMO-Dist-List-US-Media-mailto
- [https://pastebin.com/raw/w0A5bD9m](https://pastebin.com/raw/w0A5bD9m)
- [https://rentry.co/osihr4hx](https://rentry.co/osihr4hx)

### SDN-00-08-FOMO-Dist-List-US-Govt-Cabinet-mailto
- [https://pastebin.com/raw/KK0X9Grz](https://pastebin.com/raw/KK0X9Grz)
- [https://rentry.co/kv5ahbtt](https://rentry.co/kv5ahbtt)

### SDN-00-09-FOMO-Dist-List-US-Govt-House-mailto
Fill out online "contact" forms
- [https://pastebin.com/raw/mXXfj5Dz](https://pastebin.com/raw/mXXfj5Dz)
- [https://rentry.co/shm8hd54](https://rentry.co/shm8hd54)

### SDN-00-10-FOMO-Dist-List-US-Govt-Senate-mailto
Fill out online "contact" forms
- [https://pastebin.com/raw/Hk7ngirX](https://pastebin.com/raw/Hk7ngirX)
- [https://rentry.co/r7ie8me6](https://rentry.co/r7ie8me6)

### SDN-00-11-FOMO-Dist-List-US-Newspapers-National-mailto
- [https://pastebin.com/raw/t8mWBBZP](https://pastebin.com/raw/t8mWBBZP)
- [https://rentry.co/dqmo29rz](https://rentry.co/dqmo29rz)

### SDN-00-12-FOMO-Dist-List-US-Newspapers-Local-mailto
- [https://pastebin.com/raw/ZEdTbNm4](https://pastebin.com/raw/ZEdTbNm4)
- [https://rentry.co/ca4c3t72](https://rentry.co/ca4c3t72)

### SDN-00-13-FOMO-Dist-List-US-Agency-mailto
- [https://pastebin.com/raw/kiTd6zLs](https://pastebin.com/raw/kiTd6zLs)
- [https://rentry.co/df65a6fv](https://rentry.co/df65a6fv)

### SDN-00-14-FOMO-Dist-List-US-Foreign-Relations-mailto
- [https://pastebin.com/raw/iARAxHFY](https://pastebin.com/raw/iARAxHFY)
- [https://rentry.co/y6e5uaep](https://rentry.co/y6e5uaep)

### SDN-00-15-FOMO-Dist-List-US-PACS-Right-mailto
- xyz
- xyz

### SDN-00-16-FOMO-Dist-List-US-PACS-Left-mailto
- xyz
- xyz

### SDN-00-17-FOMO-Dist-List-US-Politics-Right-mailto
- xyz
- xyz

### SDN-00-18-FOMO-Dist-List-US-Politics-Left-mailto
- xyz
- xyz

### SDN-00-19-FOMO-Dist-List-US-Companies-mailto
- xyz
- xyz

### SDN-00-20-FOMO-Dist-List-UN-mailto
- xyz
- xyz

### SDN-00-21-FOMO-Dist-List-BOP-mailto
- xyz
- xyz

### SDN-00-22-FOMO-Dist-List-Deans-Poly-Sci-mailto
- [https://pastebin.com/raw/CqmZDWy2](https://pastebin.com/raw/CqmZDWy2)
- [https://rentry.co/4nd6vs3v](https://rentry.co/4nd6vs3v)

-----

-----

