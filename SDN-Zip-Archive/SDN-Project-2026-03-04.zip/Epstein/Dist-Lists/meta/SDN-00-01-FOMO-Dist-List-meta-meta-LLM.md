given the url's list below, fetch the ascii text content from each url and create a comma separated list of email addresses, exclude mailto: text, include a formatted "###" markdown header for each list using the url content 1st line. Place a header for the entire response "SDN-00-01-FOMO-Dist-List-meta-meta-CC" 

### SDN-00-01-FOMO-Dist-List-meta-meta

- 01 - https://pastebin.com/raw/dg185jjy
- 02 - https://pastebin.com/raw/CYEHDXFJ
- 03 - https://pastebin.com/raw/6L8uPdUs
- 04 - https://pastebin.com/raw/v9VS5grJ
- 05 - https://pastebin.com/raw/ArwTH6yX
- 06 - https://pastebin.com/raw/bjrSFZNY
- 07 - https://pastebin.com/raw/w0A5bD9m
- 08 - https://pastebin.com/raw/KK0X9Grz
- 09 - https://pastebin.com/raw/mXXfj5Dz
- 10 - https://pastebin.com/raw/Hk7ngirX
- 11 - https://pastebin.com/raw/t8mWBBZP
- 12 - https://pastebin.com/raw/ZEdTbNm4 
- 13 - https://pastebin.com/raw/kiTd6zLs
- 14 - https://pastebin.com/raw/iARAxHFY
- 22 - https://pastebin.com/raw/CqmZDWy2
