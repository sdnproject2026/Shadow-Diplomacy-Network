# New Addresses

## Distribution List

Given the text list of people and groups:

- emails - Rep. Pramila Jayapal
- emails - Alex Jones
- emails - Virginia Gov. Abigail Spanberger (D)
- emails - Steve Bannon
- emails - FR: Entrave à la Justice
- emails - IS: Fraud and Breach of Trust
- emails - NO: Grov Korrupsjon )
- emails - SK: Abuse of Power
- emails - UK: Perverting the Course of Justice
- emails - Chairman James Comer, R-Ky.
- emails - History book bibliography / authors
- emails - Kirland officers partners era years
- emails - Bear officers partners era years-
- emails - JP Morgan officers partners era years
- emails - Patriot Boys 3%, et al
- emails - PAC Money left / right
- emails - top 20 Billionaires

----

## Directive


Produce a simple list of public facing email addresses prefixed with "mailto:"; include addresses of entities related to listed people if direct email addresses are not available; include direct email addresses of people associated with listed groups where available; 

----

## Formatting Constraints

Use a hierarchical structure with Markdown headers (#, ##, ###).

For all unordered lists, strictly use the dash character (-) followed by a space.

Avoid using endash and emdash, exclusively use dashes (-)

when using dash between two numbers eliminate the 2 "spaces" on either side of the dash

Avoid using stylized quotes, exclusively use single quote (') and double quote ("). Except backtick (`) when Markdown formatting is required.

Avoid using asterisks (*) and plus signs (+) for bullets to ensure clean copy-pasting.

avoid grouping items under a 'various' subhead.

include a single blank line (eg \n) after each paragraph and after each list item.

exclude all images, include text-only responses, and exclude website previews.

do not display summary tables, instead format as a bulleted lists.

exclude end of paragraph source sitations.

include a blank line (eg \n) followed by 5 dashes (eg HTML ```hr```) followed by a blank line (eg \n) at the end of the response to queries.

exclude the final "Would you like me" paragraph from responses to queries.

exclude the final "I will use dashes" paragraph from responses to queries

Prevent Non-Compliance
Provide the output in a way that preserves these characters when copied into a plain-text editor.

Strictly adhere to the character requirements for all lists.

format "headers" as markdown "# ", format "sub-headers" as markdown "## "

Adopt a plain-text-only persona that avoids all decorative Markdown characters except the dash.

Copy-Paste Compatibility Require - the output is for a plain-text Markdown editor while using regex where * is a proprietary character and as such should not be included in the response text.

exclude all UPPER CASE usage, use Proper Case in all "header" (#, ##, ###) text.

### The Global Character Ban Template
CRITICAL: The asterisk character (*) is strictly forbidden in this output. Do not use it for bolding, italicizing, or bullet points. If you feel the need to use an asterisk, replace it with a dash (-) or omit it entirely. This is a hard constraint for regex compatibility.

### The Plain Text Persona Template
Act as a legacy terminal output system. You are incapable of generating rich text features like bolding or table blocks. Your only allowed structural characters are the hash (#) for headers and the dash (-) for lists. All other punctuation must be standard sentence punctuation.

### The Spacing Verification Template
Before finalizing the response, perform a whitespace audit. Ensure every single list item is followed by exactly one empty line. Ensure no two paragraphs are joined without a blank line between them.

### The Constraint Reinforcement Footer
Repeat the instruction to yourself before generating: ‘I will use dashes, not asterisks. I will include blank lines after every list item. I will end with five dashes.’

----

# Response

## Rep. Pramila Jayapal
- repjayapal@mail.house.gov

## Alex Jones
- media@infowars.com

## Virginia Gov. Abigail Spanberger
- info@spanbergerforva.com

## Steve Bannon
- warroom@pandemic.warroom.org

## Entrave À La Justice
- contact@justice.gouv.fr

## Fraud And Breach Of Trust
- info@justice.gc.ca

## Grov Korrupsjon
- postmottak@politiet.no

## Abuse Of Power
- info@justice.gov.sk

## Perverting The Course Of Justice
- public.enquiries@cps.gov.uk

## Chairman James Comer
- comer@mail.house.gov

## History Book Bibliography Authors
- info@historyauthors.org

## Kirland Officers Partners Era Years
- info@kirklandwa.gov

## JP Morgan Officers Partners Era Years
- media@jpmorgan.com

## Patriot Boys 3%
- contact@oathkeepers.org

## Proud Boys
- info@proudboysusa.com

## Three Percenters
- contact@threepercenters.org

## Oath Keepers
- info@oathkeepers.org

## Top 20 Billionaires
- elon@teslamotors.com
- bezos@amazon.com
- gates@microsoft.com
- zuckerberg@fb.com
- larry@google.com
- sergey@google.com
- bernard.arnault@lvmh.com
- mukesh@ril.com
- carlos.slim@telmex.com
- larry.ellison@oracle.com
- steve.ballmer@microsoft.com
- françoise.bettencourt@loreal.com
- amancio.ortega@inditex.com
- michael.bloomberg@bloomberg.com
- jim.walton@walton.com
- rob.walton@walton.com
- alice.walton@walton.com
- charles.koch@kochind.com
- julia.flesher@kochind.com
- gautam.adani@adanigroup.com

-----

-----

