# SDN Sent

## BCC

```
sdnproject2026@onionmail.org, sdnproject2026@mailnesia.com,  sdnproject2026@mailinator.com
```

^ sdnproject2026@mailinator.com Abuse<br>
Please contact support@manybrain.com

----

## No Pitch No Schedule

- Misc Email Addresses

### Protonmail

```
media@infowars.com, warroom@pandemic.warroom.org, repjayapal@mail.house.gov, info@spanbergerforva.com, comer@mail.house.gov, info@historyauthors.org, info@kirklandwa.gov, media@jpmorgan.com, contact@justice.gouv.fr, info@justice.gc.ca, postmottak@politiet.no, info@justice.gov.sk, public.enquiries@cps.gov.uk, tiffany.hsu@nytimes.com, ken.bensinger@nytimes.com
```

### Email Counts

- 15 - Total

## No Pitch No Schedule

- TV Email Addresses

### Protonmail

```
news.tips@abc.com, evening@cbsnews.com, contact.nbcnews@nbcuni.com, tips@cnn.com, foxnewsdesk@foxnews.com, msnbctvinfo@nbcuni.com, cnbctips@nbcuni.com, press@newshour.org, contact@nexstar.tv, comments@sbgi.net, corporatecommunications@tegna.com, info@gray.tv, scrp\_pr@scripps.com, apvideo@ap.org, reuters.newsroom@thomsonreuters.com, washington.bureau@bbc.co.uk, pressoffice@aljazeera.net, 60m@cbsnews.com, desk@cbs2ny.com, nightly@nbc.com, yourcomments@foxnews.com, info@ap.org, access.hollywood@nbcuni.com
```

### Email Counts

- 10 - Total


## No Pitch No Schedule

- Legacy Senators

### Protonmail

```
info@theabrahamgroup.com, info@ashcroftlawfirm.com, info@baucusinstitute.org, president@whitehouse.gov, steyer-taylor@law.stanford.edu, info@mercuryllc.com, info@allen-co.com, info@thencrf.org, clientservices@fennemorelaw.com, info@bipartisanpolicy.org, info@parkstrategies.com, info@afslaw.com, press@atlanticcouncil.org, info@galvanizeclimate.com, communications@tenethealth.com, info@moffitt.org, info@usadf.gov, info@patriotvoices.com, info@snoweleadershipinstitute.org, info@rosemontassociates.com
```

### Email Counts

- 20 - Total

## Next Batch

- US-Govt-Senate - C

### Protonmail

```
press@fischer.senate.gov, press@hirono.senate.gov, press@kaine.senate.gov, press@murphy.senate.gov, press@peters.senate.gov, press@tester.senate.gov, press@warner.senate.gov, press@whitehouse.senate.gov, press_paul@paul.senate.gov, tatum_wallace@cornyn.senate.gov
```

### Email Counts

- 10 - Total

### tutamail

_draft_

- 06 - US-Newspapers-National - B

```
tips@politico.com, oped@politico.com, news-tips@nypost.com, tips@nypost.com, oped@usatoday.com, news@usatoday.com, news-tips@nypost.com, tips@nypost.com, oped@usatoday.com, news@usatoday.com

```

- Streamers A

```
info@joerogan.net, support@tuckercarlson.com, press@dailywire.com, info@bongino.com, info@candaceowens.com, info@devilmaycaremedia.com, tim@timcast.com, info@louderwithcrowder.com, piers@piersmorgan.com, info@valuetainment.com, rachel@msnbc.com, info@crooked.com, brian@briantylercohen.com
```

### Email Counts

- 10 - US-Newspapers-National - B
- 13 - Streamers - A
- 23 - Total

----

# No Schedule

## 2026-03 99

- US-State-AGs - A

```
ConsumerInterest@AlabamaAG.gov, consumerprotection@alaska.gov, attorney.general@alaska.gov, consumerinfo@azag.gov, Attorney.General@azag.gov, consumer@ArkansasAG.gov, Attorney.General@ct.gov, attorney.general@delaware.gov, oag@dc.gov, oagpress@dc.gov, contactag@myfloridalegal.com, consumerprotection@law.ga.gov, hawaiiag@hawaii.gov, idahoag@ag.idaho.gov
```

- US-State-AGs - B

```
PressOffice@ilag.gov, constituent@atg.in.gov, webteam@ag.iowa.gov, consumer.consumer@ag.iowa.gov, info@ag.ks.gov, attorney.general@ag.ky.gov, constituentservices@ag.louisiana.gov, attorney.general@maine.gov, oag@oag.state.md.us, consumer@oag.state.md.us, ago@mass.gov, miag@michigan.gov, attorney.general@ag.state.mn.us, info@ago.state.ms.us
```

- US-State-AGs - C

```
attorney.general@ago.mo.gov, consumer.help@ago.mo.gov, ago.info.help@nebraska.gov, ago.consumer@nebraska.gov, AGInfo@ag.nv.gov, DOJ-CPB@doj.nh.gov, nmag@nmag.gov, ndag@nd.gov, ConsumerProtection@oag.ok.gov, AttorneyGeneral@doj.state.or.us
```

### Email Counts

- 14 - US-State-AGs - A
- 14 - US-State-AGs - B
- 10 - US-State-AGs - C
- 38 - Total

----

## 2026-03 99

- US-State-AGs - D

```
consumerhelp@state.sd.us, scdca@scconsumer.gov, consumerhelp@state.sd.us, uag@agutah.gov, ago.info@vermont.gov, CRC@atg.wa.gov, consumer@wvago.gov, ag.consumer@wyo.gov
```

- US-Govt-Cabinet

```
comments@whitehouse.gov, vice_president@whitehouse.gov, president@whitehouse.gov, newsadmin@whitehouse.gov, press@who.eop.gov, press@state.gov, osd.pa.dutyofficer@mail.mil, press@treasury.gov, press@usdoj.gov, interior_press@ios.doi.gov, press@usda.gov, publicaffairs@doc.gov, press@dol.gov, press@hhs.gov, hudpressoffice@hud.gov, pressoffice@dot.gov
```

### Email Counts

- 08 - US-State-AGs - D
- 15 - US-Govt-Cabinet
- 23 - Total

----

----

# Old Batches

## 2026-03-11

### Protonmail

- MISC

```
sara.guerrero@mail.house.gov, Crgdistrict@mail.house.gov, Raskin.Casework@mail.house.gov, info@summerforpa.com, press@summerforpa.com, melvin.soto@mail.house.gov , Massie.Internship@mail.house.gov, matthew.topolski@mail.house.gov
```

### Protonmail

- ACLU-Lawyers

```
media@aclu.org, aclufl@aclufl.org, media@nyclu.org, media@acluaz.org, media@acludc.org, media@aclum.org
```

### Email Counts

- 08 - MISC
- 06 - ACLU-Lawyers
- 14 - Total

----

## 2026-03-12

- ALL bounced or rate limited

### Protonmail

- US-Media - A

```
msisak@ap.org, adurbin@ap.org, etucker@ap.org, ben@meidastouch.com, ron@meidastouch.com, brett@meidastouch.com, macfarlanes@cbsnews.com, kaia.hubbard@cbsinteractive.com, melissa.quinn@cbsinteractive.com, sfowler@npr.org, jdiaz@npr.org, sneuman@npr.org, llanders@newshour.org, ldesjardins@newshour.org
```

### Protonmail

- US-Media - B

```
mfinnegan@newshour.org, john@other98.com, andy@other98.com, action@other98.com, omar@occupydemocrats.com, omar@tribel.com, rafael@occupydemocrats.com, grant@occupydemocrats.com, news@axios.com, info@axios.com, pips@axios.com, press@axios.com
```

### Email Counts

- 14 - US-Media - A
- 12 - US-Media - B
- 26 - Total

----

## 2026-03-14

### ProtonMail

- US-Victim-Lawyers

^ info@allredmaroko.com 

^ contact@jordanmersonlaw.com

```
info@bsfllp.com, info@jamesmarshlaw.com, info@sokolovelaw.com
```

### ProtonMail

- US-Academics

^ srhbukhari@jrsr.edu

^ mkashif@jrsr.edu

```
aharberg@wbur.org, mdallek@gwu.edu, mtaylor@icjs.org
```

### ProtonMail

- US-Govt-House

```
sara.guerrero@mail.house.gov, Crgdistrict@mail.house.gov, Raskin.Casework@mail.house.gov, info@summerforpa.com, press@summerforpa.com, melvin.soto@mail.house.gov, us@ocasiocortez.com

```

### Email Counts

- 05 - US-Victim-Lawyers
- 05 - US-Academics
- 07 - US-Govt-House
- 17 - Total 

----

## 2026-03-17

### ProtonMail

- Streamers - B

^ jack@humanityprojects.com

^ jessica@houseinhabit.com

^ hasanpikerbiz@gmail.com

^ chaya@libsoftiktok.com

^ liz@lizwheeler.com (delayed)

```
producers@majority.fm, ezrakleinshow@nytimes.com, info@longwellpartners.com, staytuned@cafe.com, info@davidpakman.com, support@tyt.com, hasanpikerbiz@gmail.com, rogan@dcdraino.com
```

### ProtonMail

- Project-2025 - A

^ paul.dans@heritage.org

^ wesley.coopersmith@heritage.org

^ spencer.chretien@heritage.org

^ marla.hess@heritage.org

```
kevin.roberts@heritage.org, steven.groves@heritage.org, roger.severino@heritage.org, derrick.morgan@heritage.org, therese.pennefather@heritage.org, william.poole@heritage.org, jessica.lowther@heritage.org, hellojesslowther@gmail.com, karina.rollins@heritage.org, jordan.embree@heritage.org
```

----

### ProtonMail

- Project-2025 - B

^ jonathan.moy@heritage.org

^ John-Ratcliffe@heritage.org

^ sarah.calvis@heritage.org

^ Chad-Padgett@heritage.org

^ Leah-Pedersen@heritage.org

^ Peter-Navarro@heritage.org

^ rachael.wilfong@heritage.org

```
info@citizensforethics.org, contact@americancornerstone.org, info@heritage.org, daren.bakst@cei.org, info@claremont.org, emma.waters@heritage.org, thepowerhour@heritage.org
```

### Email Counts

 - 13 - Streamers - B
 - 14 - Project-2025 - A
 - 14 - Project-2025 - B
 - 41 - Total

----

### Tuta Mail

- US-Newspapers-National

^ op-ed@washpost.com

^ newseditors@wsj.com

```
newsroom@washpost.com, letters@wsj.com,  news-tips@nytimes.com, oped@nytimes.com
```

### Email Counts

- 06 - US-Newspapers-National - A
- 13 - Streamers - A
- 25 - Total 

----

## 2026-03-18

### ProtonMail

- US-Govt-Senate - A

^ adan_sanchez@lujan.senate.gov

```
allison_biasotti@schumer.senate.gov, angela_ramponi@murkowski.senate.gov, audrey_cook@blackburn.senate.gov, ausan_al-eryani@merkley.senate.gov, bobby_andres@schumer.senate.gov, caty_payette@heinrich.senate.gov, clare_slattery@grassley.senate.gov, david_bader@grassley.senate.gov, emily_hampsten@durbin.senate.gov, HSGACPress_Paul@hsgac.senate.gov
```

- US-Govt-Senate - B

### ProtonMail

^ press@brown.senate.gov

^ press@cardin.senate.gov

^ press@casey.senate.gov

```
josh_sorbe@judiciary-dem.senate.gov, kaleb_froehlich@murkowski.senate.gov, luis_soriano@heinrich.senate.gov, natalie_yezbick@cornyn.senate.gov, paul_schedule@paul.senate.gov, press@baldwin.senate.gov, press@barrasso.senate.gov, press@bennet.senate.gov, press@cantwell.senate.gov, 
```

### Email Counts

- 11 - US-Govt-Senate - A
- 12 - US-Govt-Senate - B
- 22 - Total


