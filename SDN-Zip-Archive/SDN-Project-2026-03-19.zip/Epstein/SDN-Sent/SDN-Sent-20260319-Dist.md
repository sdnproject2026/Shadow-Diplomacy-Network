### SDN-11-Kushner-Family-02-Charities.md

## 2026-03-19

> EFTA00090314 - Jared Kushner - Private Family Financial Distress

- https://www.justice.gov/epstein/files/DataSet%209/EFTA00090314.pdf

## Email Dist List

## To

```
media@infowars.com, repjayapal@mail.house.gov, info@spanbergerforva.com, comer@mail.house.gov, media@jpmorgan.com, contact@justice.gouv.fr, info@justice.gc.ca, public.enquiries@cps.gov.uk

```

08 count

----


```
info@joerogan.net, support@tuckercarlson.com, oagpress@dc.gov, comments@whitehouse.gov, vice_president@whitehouse.gov, press@usdoj.gov, Massie.Internship@mail.house.gov, aclufl@aclufl.org, media@nyclu.org, ezrakleinshow@nytimes.com, liz@lawyeroyer.com, jessica.lowther@heritage.org, oped@nytimes.com

``` 

13 count

```
etucker@ap.org, ben@meidastouch.com, ron@meidastouch.com, macfarlanes@cbsnews.com, kaia.hubbard@cbsinteractive.com, sfowler@npr.org, jdiaz@npr.org, llanders@newshour.org
```

07 count

## BCC

```
sdnproject2026@onionmail.org
```

----

----
