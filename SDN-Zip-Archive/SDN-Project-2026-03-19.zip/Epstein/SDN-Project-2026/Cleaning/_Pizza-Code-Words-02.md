# 910+ Mentions Of "Pizza"

The release of the "Epstein Files" through the Epstein Files Transparency Act (2025-2026) has led to intense digital forensic analysis of over 20,000 documents. 

Within these caches, independent researchers have flagged approximately 910+ mentions of "pizza" or "pizza party." 

While official investigative findings (including those from the 2026 DOJ disclosures) maintain these refer to literal catering, OSINT analysts point to specific incongruities that suggest a coded layer.

## Analysis of Linguistic Incongruity

The "pizza" references in the Epstein-Maxwell-Associate email chains often lack the logical hallmarks of casual food orders.

### Financial Asymmetry

- High-net-worth individuals, who employed world-class private chefs (like those on Little St. James), are seen obsessing over the logistics of $15 pizzas in emails marked with "Urgent" or "High Importance."

### Geographic Mismatch

- Emails discussing "picking up pizza" in locations where the sender is not currently present, or where the specific pizza parlor mentioned does not exist.

### The "Topping" Specificity

- Unusual emphasis on specific toppings or "half-and-half" orders in contexts that align with the arrival of new "guests" or "juniors" on flight manifests.

### After-Hours Logistics

- Requests for "pizza delivery" at 2:00 AM to secure facilities (like the 66th Street townhouse) that had 24/7 security and staff but no recorded external food deliveries during those windows.

## Dictionary 

Speculated "Pizza" Code Phrases

Note: These meanings are derived from OSINT pattern-matching.

### Pizza / Cheese Pizza

- Speculated to refer to a young female victim (or "CP").

### Hot Dog

- Speculated to refer to a young male victim.

### Pizza Party

- Speculated to indicate a gathering where multiple victims are present for guests.

### Extra Sauce / Spicy

- Speculated to refer to victims of a specific (often younger) age or a more "extreme" encounter.

### Gluten-Free / Thin Crust

- Speculated to refer to the physical build or perceived "frailty" of a victim.

### Delivery / Pickup

- Speculated to refer to the transport of a victim from a handler to a client.

### Grape Soda

- Frequently paired with "pizza" in the 2026 logs

- speculated to refer to the use of sedatives (such as Chloral Hydrate) to keep victims compliant.

## Associates

### Key Correspondents And Interests

The following list details the primary authors and recipients of the emails containing these "pizza" references as identified in the 2025-2026 tranches.

### Jeffrey Epstein

- Male

Expressed Interests

- Recruitment logistics, "fertility" projects, and maintaining "blackmail" or social leverage over high-profile political and financial figures.

Tone

- Clinical, terse, and results-oriented.

### Ghislaine Maxwell

- Female

Expressed Interests

- Managing the "household" (victims), scheduling "massages," and acting as the primary logistical interface for the "pizza" deliveries.

Tone

- Professional and maternal, often using "nursery" or "school" metaphors.

### Prince Andrew 

(Duke of York)

- Male

Expressed Interests

- "Annual retreats," homemade family messages, and seeking assistance with personal financial "problems" for his family. 

Incongruity

- His emails often shift abruptly from formal trade envoy business to "playtime" or "treat" requests.

### Leon Black 

Jes Staley (Financial Associates) / et al

- Male

Expressed Interests

- Wealth management, art collecting, and requests for specific "hospitality" items (including "pizza" and "beverages") during stays at Epstein's properties.

Tone

- Highly familiar and grateful for "unparalleled hospitality."

### Michael Wolff / Media Contacts

- Male

Expressed Interests

- Journalistic access and "gossip" regarding political rivals (specifically Donald Trump and Bill Clinton).

Tone

- Transactional

- Epstein's 2019 emails to Wolff allegedly claimed "Trump knew about the girls."

----

----
