# Heather Cox Richardson

## Mar 19, 2026

I was intending to take tonight off, but there’s big news - I mean, aside from all the other big news - that I want to make sure gets attention.

Back on February 23, Daniel Ruetenik, Pat Milton, and Cara Tabachnick of CBS News reported on a newly uncovered document in the Epstein files showing that beginning in December 2010 under the Obama administration, the U.S. Drug Enforcement Agency (DEA) was running an investigation of Jeffrey Epstein and fourteen other people for drug trafficking, prostitution, and money laundering.

The document showed the investigation, called “Chain Reaction,” was still underway in 2015. But the investigation disappeared, although the document suggested that it was a significant investigation and that the government was on the verge of indictments.

As soon as the story broke, Senator Ron Wyden of Oregon, the top-ranking Democrat on the Senate Finance Committee, said: “It appears Epstein was involved in criminal activity that went way beyond pedophilia and sex trafficking, which makes it even more outrageous that [Attorney General] Pam Bondi is sitting on several million unreleased files.”

Wyden has been investigating the finances behind Epstein’s criminal sex-trafficking organization: it was his investigation that turned up the information that JPMorgan Chase neglected to report more than $1 billion in suspicious financial transactions linked to Epstein. Wyden has pushed hard for Treasury Secretary Scott Bessent to produce the records of those suspicious transactions for the Senate Finance Committee, but Bessent refuses.

On February 25, two days after the story of the DEA investigation broke, Wyden wrote to Terrance C. Cole, administrator of the DEA, noting that “[t]he fact that Epstein was under investigation by the DOJ’s [organized crime drug enforcement] task force suggests that there was ample evidence indicating that Epstein was engaged in heavy drug trafficking and prostitution as part of cross-border criminal conspiracy. This is incredibly disturbing and raises serious questions as to how this investigation by the DEA was handled.”

He noted that Epstein and the fourteen co-conspirators were never charged for drug trafficking or financial crimes, and wrote: “I am concerned that the DEA and DOJ during the first Trump Administration moved to terminate this investigation in order to protect pedophiles.” He also noted that the heavy redactions in the document appear to go far beyond anything authorized by the Epstein Files Transparency Act and that since the document was not classified, “there is no reason to withhold an unredacted version of this document from the U.S. Congress.”

Wyden asked Cole to produce a number of documents by March 13, 2026, including an unredacted copy of the memo in the files, information about what triggered the investigation, what types of drugs Epstein and his fourteen associates were buying or selling, when Operation Chain Reaction concluded and what was its result, why no one was charged, and why the names of the fourteen co-conspirators were redacted.

Today Wyden sent a letter to Deputy Attorney General Todd Blanche, Trump’s former personal lawyer, saying: “It is my understanding that shortly after I requested an unredacted copy” of the document in the Epstein files, the Department of Justice “stepped in to prevent DEA from complying with my request. According to a confidential tip received by my staff, DEA Administrator Terry Cole was ready to provide an unredacted copy of the memorandum, but you stepped in to prevent him from doing so. My staff inquired with the DEA about the status of the production of this document and the DEA responded by directing questions to your office.”

The letter continued: “Your alleged interference in this matter is highly disturbing, not just because it continues the DOJ’s long-running obstruction of my investigation, but also because of your bizarrely favorable treatment of Ghislaine Maxwell, one of Epstein’s closest criminal associates. I should not have to explain the significance of the fact that Epstein was a target of [this high-level DEA] investigation. It suggests the government had ample evidence indicating he was engaged in large scale drug trafficking and prostitution as part of cross-border criminal conspiracy and that Epstein was likely pumping his victims, including underage girls, with incapacitating drugs to facilitate abuse. I am at a loss to understand why you are blocking further investigation of this matter.”

Noting that the document in the files was “clearly marked as ‘unclassified’ at the top of every single page,” Wyden noted: “There is absolutely no reason to withhold an unredacted version of this document from the U.S. Congress.” He added: “In order to assist my investigation into this matter, I demand that you immediately authorize the release of this document.”

Wyden also posted today on social media: “HUGE: Deputy Attorney General Todd Blanche - Trump’s former personal lawyer who was also responsible for Ghislaine Maxwell’s transfer to a cushy club fed - has intervened to block the DEA from providing details of a mysterious Epstein investigation to my Finance Committee team…. This is stunning interference. The document I’m after literally says ‘unclassified’ at the top. The investigation it details is closed. Given Blanche’s close personal ties to Donald Trump, this reeks of a continued coverup to protect key names in the Trump administration.”

Wyden’s post echoes the September 13, 2019, letter from then-chair of the House Intelligence Committee Adam Schiff (D-CA) to Acting Director of National Intelligence Joseph Maguire, in which Schiff called out Maguire for illegally withholding a whistleblower complaint.

In that 2019 letter, Schiff warned: “The Committee can only conclude…that the serious misconduct at issue involves the President of the United States and/or other senior White House or Administration officials. This raises grave concerns that your office, together with the Department of Justice and possibly the White House, are engaged in an unlawful effort to protect the President and conceal from the Committee information related to his possible ‘serious or flagrant’ misconduct, abuse of power, or violation of law.”

Schiff was right: the whistleblower had flagged Trump’s July 2019 phone call with newly elected Ukraine president Volodymyr Zelensky, demanding Zelensky smear Joe Biden’s son Hunter before Trump would release the money Congress had appropriated for Ukraine to fight off the Russian invasion that had begun in 2014. That information led to the story that Trump’s White House was running its own secret operation in Ukraine, apart from the State Department, for Trump’s own benefit. That story led to Trump’s first impeachment by the House of Representatives for abuse of power and obstruction of Congress.

Schiff was the lead impeachment manager of the impeachment trial in the Senate, and in his closing argument, he implored Senate Republicans to bring accountability to “a man without character.” “You will not change him. You cannot constrain him. He is who he is. Truth matters little to him. What’s right matters even less, and decency matters not at all.”

“You can’t trust this president to do the right thing. Not for one minute, not for one election, not for the sake of our country,” Schiff said. “You just can’t. He will not change and you know it.” “A man without character or ethical compass will never find his way.”

But Republican senators stood behind Trump. They acquitted him of abuse of power, by a vote of 48 for conviction to 52 for acquittal. Senator Mitt Romney of Utah crossed the aisle to vote with the Democratic minority. Senate Republicans were unanimous in their vote to acquit Trump of obstruction of Congress.

And here we are.

## Sources

- https://heathercoxrichardson.substack.com/p/march-18-2026?triedRedirect=true

- https://www.cbsnews.com/news/jeffrey-epstein-files-dea-document-drug-trafficking-investigation/

- https://www.finance.senate.gov/ranking-members-news/continuing-epstein-investigation-wyden-releases-new-analysis-detailing-how-top-jpmorgan-chase-executives-enabled-epsteins-sex-trafficking-operation

- https://www.finance.senate.gov/ranking-members-news/new-wyden-bill-would-force-treasury-to-turn-over-epstein-files

- https://www.finance.senate.gov/ranking-members-news/epstein-survivors-announce-support-for-wyden-bill-that-would-force-treasury-to-turn-over-epstein-bank-records#:~:text=Later%20that%20year%20Senator%20Wyden,of%20this%20release%20is%20here

- http://bloomberg.com/news/newsletters/2025-11-07/reagan-era-crime-unit-officially-shut-down-by-doj#:~:text=They%20confirmed%20that%20the%20task,forces%20would%20cease%20to%20exist

- https://www.cbsnews.com/news/jeffrey-epstein-dea-drug-trafficking-investigation-senator-wyden/?ftag=CNM-00-10aab7e&linkId=911961965

- https://www.wsj.com/us-news/law/doj-to-review-whether-epstein-files-about-trump-were-improperly-withheld-bc8af73c?gaa_at=eafs&gaa_n=AWEtsqeyWVLCoD4ypQJKSiYKIePyANnGSyeizFhhYFm8SliF9W0B3UHieelaE55t3-0%3D&gaa_ts=69a20bb2&gaa_sig=z_wT9NzJEikEVFxa5LZ3VokQfQ8SvP6ncpYzvDIBlM5JS71Q0yleYhCrpgtKtWanX5QEEh6jnZ8qFQFpm9YotQ%3D%3D

- https://www.bloomberg.com/news/articles/2026-03-18/senator-accuses-blanche-of-blocking-release-of-unredacted-epstein-document

- https://s3.documentcloud.org/documents/6409559/20190913-Chm-Schiff-Letter-to-Acting-Dni-Re.pdf

- https://www.nbcnews.com/politics/trump-impeachment-inquiry/closing-argument-democrats-say-not-removing-trump-would-render-him-n1128766

- https://www.finance.senate.gov/imo/media/doc/letter_from_senator_wyden_to_dag_todd_blanche.pdf

- https://www.yahoo.com/news/f-ked-book-reveals-gop-110011623.html

Bluesky:

- https://bsky.app/profile/wyden.senate.gov/post/3mftyu6do2k2l

- https://bsky.app/profile/wyden.senate.gov/post/3mhdnj4rxf22i

- https://heathercoxrichardson.substack.com/p/march-18-2026?utm_source=substack&utm_medium=email&utm_content=share&action=share