Here are the media contact addresses and websites from the provided text, with additional direct "Contact Us" URLs where they were previously missing.

## Email

- news.tips@abc.com
- evening@cbsnews.com
- contact.nbcnews@nbcuni.com
- tips@cnn.com
- foxnewsdesk@foxnews.com
- msnbctvinfo@nbcuni.com
- cnbctips@nbcuni.com
- press@newshour.org
- contact@nexstar.tv
- comments@sbgi.net
- corporatecommunications@tegna.com
- info@gray.tv
- scrp\_pr@scripps.com
- apvideo@ap.org
- reuters.newsroom@thomsonreuters.com
- washington.bureau@bbc.co.uk
- pressoffice@aljazeera.net
- 60m@cbsnews.com
- desk@cbs2ny.com
- nightly@nbc.com
- yourcomments@foxnews.com
- info@ap.org
- access.hollywood@nbcuni.com

-----

## Websites

- ABC News Feedback
    - https://abc.com/feedback
- NBC News Help Center/Tips
    - https://www.nbcnews.com/tips/
- CNBC Contact Form
    - https://contact.cnbc.com
- CNN Feedback/Tips
    - https://help.cnn.com/us/feedback
- MSNBC Contact/Feedback
    - https://nbcnews.zendesk.com/hc/en-us
- CBS New York Contact
    - https://www.cbsnews.com/newyork/contact-us/
- General Media Directory
    - https://www.tvtaping.com/articles/news-media-contacts

