# TV Email Addresses

```
news.tips@abc.com, evening@cbsnews.com, contact.nbcnews@nbcuni.com, tips@cnn.com, foxnewsdesk@foxnews.com, msnbctvinfo@nbcuni.com, cnbctips@nbcuni.com, press@newshour.org, contact@nexstar.tv, comments@sbgi.net, corporatecommunications@tegna.com, info@gray.tv, scrp\_pr@scripps.com, apvideo@ap.org, reuters.newsroom@thomsonreuters.com, washington.bureau@bbc.co.uk, pressoffice@aljazeera.net, 60m@cbsnews.com, desk@cbs2ny.com, nightly@nbc.com, yourcomments@foxnews.com, info@ap.org, access.hollywood@nbcuni.com
```

----

----
