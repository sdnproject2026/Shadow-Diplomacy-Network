# Reddit AMA

- Charlie Kirk expendable
- Ms Kirk suspect
- Russian "Assets"
- Israeli "Assets"
- British "Assets"
- Saudi "Assets"
- Epstein China Links
- Epstein drug cartel links
- Epstein New Mexico ranch
- Crypto money laundering
- Tangential CIA Operations 