### SDN-00-27-FOMO-Dist-List-Billionaires

- mailto:elon@teslamotors.com
- mailto:bezos@amazon.com
- mailto:gates@microsoft.com
- mailto:zuckerberg@fb.com
- mailto:larry@google.com
- mailto:sergey@google.com
- mailto:bernard.arnault@lvmh.com
- mailto:mukesh@ril.com
- mailto:carlos.slim@telmex.com
- mailto:larry.ellison@oracle.com
- mailto:steve.ballmer@microsoft.com
- mailto:françoise.bettencourt@loreal.com
- mailto:amancio.ortega@inditex.com
- mailto:michael.bloomberg@bloomberg.com
- mailto:jim.walton@walton.com
- mailto:rob.walton@walton.com
- mailto:alice.walton@walton.com
- mailto:charles.koch@kochind.com
- mailto:julia.flesher@kochind.com
- mailto:gautam.adani@adanigroup.com

----
