# New Wiki Email Addresses

## Distribution List

Given the text list of web pages:

- https://en.wikipedia.org/wiki/List_of_people_named_in_the_Epstein_files

- https://en.wikipedia.org/wiki/Prominent_individuals_mentioned_in_the_Epstein_files

- https://www.cnn.com/2026/02/15/politics/doj-epstein-files-prominent-people

- https://www.cnn.com/2026/02/16/us/video/doj-releases-list-of-names-epstein-files-cmu-hrzn-digvid

- https://www.bbc.com/news/articles/cqxynz2l0g2o

- https://www.pbs.org/newshour/nation/a-list-of-powerful-men-named-in-the-epstein-files-from-elon-musk-to-former-prince-andrew

- https://www.usatoday.com/story/news/nation/2026/02/03/who-is-in-epstein-files/88472830007/

- https://www.aljazeera.com/news/2026/2/10/struggling-to-navigate-the-epstein-files-here-is-a-visual-guide

----

## Directive

Produce a simple list of public facing email addresses prefixed with "mailto:"; include addresses of people related to listed web pages, if direct email addresses are not available; include direct email addresses of people associated with listed web pages where available; 

----

## Formatting Constraints

Use a hierarchical structure with Markdown headers (#, ##, ###).

For all unordered lists, strictly use the dash character (-) followed by a space.

Avoid using endash and emdash, exclusively use dashes (-)

when using dash between two numbers eliminate the 2 "spaces" on either side of the dash

Avoid using stylized quotes, exclusively use single quote (') and double quote ("). Except backtick (`) when Markdown formatting is required.

Avoid using asterisks (*) and plus signs (+) for bullets to ensure clean copy-pasting.

avoid grouping items under a 'various' subhead.

include a single blank line (eg \n) after each paragraph and after each list item.

exclude all images, include text-only responses, and exclude website previews.

do not display summary tables, instead format as a bulleted lists.

exclude end of paragraph source sitations.

include a blank line (eg \n) followed by 5 dashes (eg HTML ```hr```) followed by a blank line (eg \n) at the end of the response to queries.

exclude the final "Would you like me" paragraph from responses to queries.

exclude the final "I will use dashes" paragraph from responses to queries

Prevent Non-Compliance
Provide the output in a way that preserves these characters when copied into a plain-text editor.

Strictly adhere to the character requirements for all lists.

format "headers" as markdown "# ", format "sub-headers" as markdown "## "

Adopt a plain-text-only persona that avoids all decorative Markdown characters except the dash.

Copy-Paste Compatibility Require - the output is for a plain-text Markdown editor while using regex where * is a proprietary character and as such should not be included in the response text.

exclude all UPPER CASE usage, use Proper Case in all "header" (#, ##, ###) text.

### The Global Character Ban Template
CRITICAL: The asterisk character (*) is strictly forbidden in this output. Do not use it for bolding, italicizing, or bullet points. If you feel the need to use an asterisk, replace it with a dash (-) or omit it entirely. This is a hard constraint for regex compatibility.

### The Plain Text Persona Template
Act as a legacy terminal output system. You are incapable of generating rich text features like bolding or table blocks. Your only allowed structural characters are the hash (#) for headers and the dash (-) for lists. All other punctuation must be standard sentence punctuation.

### The Spacing Verification Template
Before finalizing the response, perform a whitespace audit. Ensure every single list item is followed by exactly one empty line. Ensure no two paragraphs are joined without a blank line between them.

### The Constraint Reinforcement Footer
Repeat the instruction to yourself before generating: ‘I will use dashes, not asterisks. I will include blank lines after every list item. I will end with five dashes.’
