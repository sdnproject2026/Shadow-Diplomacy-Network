# New Email Addresses

# Right

## Alex Jones
- mailto:media@infowars.com

## Steve Bannon
- mailto:warroom@pandemic.warroom.org

# Left

## Rep. Pramila Jayapal
- mailto:repjayapal@mail.house.gov

## Virginia Gov. Abigail Spanberger
- mailto:info@spanbergerforva.com

# Misc

## Chairman James Comer
- mailto:comer@mail.house.gov

## History Book Bibliography Authors
- mailto:info@historyauthors.org

## Kirland Officers Partners Era Years
- mailto:info@kirklandwa.gov

## JP Morgan Officers Partners Era Years
- mailto:media@jpmorgan.com

# Foreign

## Entrave À La Justice
- mailto:contact@justice.gouv.fr

## Fraud And Breach Of Trust
- mailto:info@justice.gc.ca

## Grov Korrupsjon
- mailto:postmottak@politiet.no

## Abuse Of Power
- mailto:info@justice.gov.sk

## Perverting The Course Of Justice
- mailto:public.enquiries@cps.gov.uk


-----

-----

