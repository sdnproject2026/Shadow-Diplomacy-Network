# SDN Unfinished Business

## Unexplored
- 6+ new root "sources" lists documented
- partial "reveals"

## Undocumented
- Scotland Yard SDN and JEp files
- Mandate for Leadership database vetted staff
- Mandate 100 partner organizations
- if perp knows others, RICO, Misprision of Felony?
- French bans Charles Kushner diplomat
- Ghislaine Maxwell’s “TerraMar” UN NGO
- Secrets of Robert Maxwell / PROMIS

## Backgrounders

- Pam Bondi FL professional details
    - add to SDN "Legal" doc
    - relation to Judge D. Cannon
- Adnan Khashoggi “fixer” in Saudi Arabia
    - add to SDN "Khashoggi Family" doc
    - Lockheed
    - Northrop
    - Raytheon
- Ohio State University connections late 1900s
    - Sigma Alpha Mu fraternity
- Pompeo / Barr
    - add to SDN "Barr Family" doc
    - "seth rich" murdered
    - wikileaks
    - J. Assange

## Misc

- World Liberty ponzi scheme Don'T bro's
- where are the parents
- cabinet Members... family trees
- "pizza" code language - Clintons blamed

## Tech

- iCalendar format
    - JWorld "calendar" meetings
    - JEp travel locations
    - JEp arrest record
    - ALL perps dates / locations 
    - cross ref with emails, logs, pix, vid

## Reddit

- AMA... Trump Secret Documents case, players
- AMA... Trump family grifting crime$ billions
- AMA... Past admins kicked the SDN can
- AMA... NY NJ Organized crime families etc

## Transcribe

comment
- https://www.facebook.com/share/v/14SQjma16HE/

comment
- https://www.facebook.com/share/v/1ALgYMm5Hp/

comment
- https://www.facebook.com/share/r/18bdDPaKch/

comment
- https://www.facebook.com/share/v/1AhedCJz4Z/

comment
- https://www.facebook.com/share/v/173nM8oS5K/

comment
- https://www.facebook.com/share/r/19t4Q3txwv/

comment
- https://www.facebook.com/share/r/1CQhgxCSVc/

comment
- https://www.facebook.com/share/v/1DqatF1uE6/

deaths
- https://www.facebook.com/share/v/14VYQwtpMeZ/

cia
- https://www.facebook.com/share/r/1K8a1SjviU/

cartel
- https://www.facebook.com/share/r/1BB5mho7eK/

ranch
- https://www.facebook.com/share/v/14TSx17VNEP/

cocaine
- https://www.facebook.com/share/r/1AGGaAuepK/

leon
- https://www.facebook.com/share/r/1F1cVtQFDD/

Dalton
- https://www.facebook.com/share/r/1821hi8Tcb/

suns cartel
- https://www.facebook.com/share/r/17VthkB23p/

rogan jep isrl
- https://www.facebook.com/share/r/1GNx3z71Pu/

rob max
- https://www.facebook.com/share/r/1DkMbYNLSi/

isrl 911
- https://www.facebook.com/share/r/16ms8zXuoE/

apart
- https://www.facebook.com/share/r/19urAdKJjF/

emails isrl leak
- https://www.facebook.com/share/r/1C1tX3SV6r/

apaic mtg
- https://www.facebook.com/share/v/1BPbMvgsun/

nadia
- https://www.facebook.com/share/r/19zNGbrBWM/

sterns money
- https://www.facebook.com/share/v/17xSSCs8go/

biog
- https://www.facebook.com/share/v/17xxG9tDdy/

greenland
- https://www.facebook.com/share/v/1HH3k1xQKB/

john barron
- https://www.facebook.com/share/v/18B8JYPEw4/

----

----
