# SDN Distribution List CC

In early 2026, the implementation of the _Epstein Files Transparency Act_ led to the release of over 3.5 million pages of Department of Justice records.

This massive data dump has shifted reporting from traditional investigation to high-speed digital analysis, with academic researchers and independent voices playing a significant role in dissecting the files alongside established media outlets.

### SDN-00-05-FOMO-Dist-List-US-Victim-Lawyers

- Count: 5

info@bsfllp.com, info@allredmaroko.com, contact@jordanmersonlaw.com, info@jamesmarshlaw.com, info@sokolovelaw.com

-----

### SDN-00-06-FOMO-Dist-List-US-Academics

- Count: 5

aharberg@wbur.org, mdallek@gwu.edu, mtaylor@icjs.org, srhbukhari@jrsr.edu, mkashif@jrsr.edu

-----

### SDN-00-01-FOMO-Dist-List-ACLU-Lawyers

- Count: 6

media@aclu.org, aclufl@aclufl.org, media@nyclu.org, media@acluaz.org, media@acludc.org, media@aclum.org

-----

### SDN-00-09-FOMO-Dist-List-US-Govt-House

- Count: 7

sara.guerrero@mail.house.gov, Crgdistrict@mail.house.gov, Raskin.Casework@mail.house.gov, info@summerforpa.com, press@summerforpa.com, melvin.soto@mail.house.gov, us@ocasiocortez.com

-----

### SDN-00-08-FOMO-Dist-List-US-Govt-Cabinet

- Count: 15

comments@whitehouse.gov, vice_president@whitehouse.gov, president@whitehouse.gov, newsadmin@whitehouse.gov, press@who.eop.gov, press@state.gov, osd.pa.dutyofficer@mail.mil, press@treasury.gov, press@usdoj.gov, interior_press@ios.doi.gov, press@usda.gov, publicaffairs@doc.gov, press@dol.gov, press@hhs.gov, hudpressoffice@hud.gov, pressoffice@dot.gov

-----

### SDN-00-11-FOMO-Dist-List-US-Newspapers-National

- Count: 20

newsroom@washpost.com, op-ed@washpost.com, tips@politico.com, oped@politico.com, newseditors@wsj.com, letters@wsj.com, news-tips@nypost.com, tips@nypost.com, news-tips@nytimes.com, oped@nytimes.com, oped@usatoday.com, news@usatoday.com


-----

### SDN-00-04-FOMO-Dist-List-Streamers

- Count: 26

info@joerogan.net, support@tuckercarlson.com, press@dailywire.com, info@bongino.com, info@candaceowens.com, info@devilmaycaremedia.com, tim@timcast.com, info@louderwithcrowder.com, piers@piersmorgan.com, info@valuetainment.com, rachel@msnbc.com, info@crooked.com, brian@briantylercohen.com, producers@majority.fm, ezrakleinshow@nytimes.com, info@longwellpartners.com, staytuned@cafe.com, info@davidpakman.com, support@tyt.com, hasanpikerbiz@gmail.com, rogan@dcdraino.com, jessica@houseinhabit.com, liz@lizwheeler.com, jack@humanityprojects.com, chaya@libsoftiktok.com, liz@lawyeroyer.com

-----

### SDN-00-03-FOMO-Dist-List-Project-2025

- Count: 28

kevin.roberts@heritage.org, paul.dans@heritage.org, steven.groves@heritage.org, roger.severino@heritage.org, spencer.chretien@heritage.org, derrick.morgan@heritage.org, wesley.coopersmith@heritage.org, therese.pennefather@heritage.org, william.poole@heritage.org, marla.hess@heritage.org, jessica.lowther@heritage.org, hellojesslowther@gmail.com, karina.rollins@heritage.org, jordan.embree@heritage.org, sarah.calvis@heritage.org, jonathan.moy@heritage.org, info@citizensforethics.org, contact@americancornerstone.org, info@heritage.org, John-Ratcliffe@heritage.org, Peter-Navarro@heritage.org, daren.bakst@cei.org, info@claremont.org, Chad-Padgett@heritage.org, Leah-Pedersen@heritage.org, emma.waters@heritage.org, rachael.wilfong@heritage.org, thepowerhour@heritage.org

-----

### SDN-00-07-FOMO-Dist-List-US-Media

- Count: 27

msisak@ap.org, adurbin@ap.org, etucker@ap.org, ben@meidastouch.com, ron@meidastouch.com, brett@meidastouch.com, macfarlanes@cbsnews.com, kaia.hubbard@cbsinteractive.com, melissa.quinn@cbsinteractive.com, sfowler@npr.org, jdiaz@npr.org, sneuman@npr.org, llanders@newshour.org, ldesjardins@newshour.org, mfinnegan@newshour.org, john@other98.com, andy@other98.com, action@other98.com, omar@occupydemocrats.com, omar@tribel.com, rafael@occupydemocrats.com, grant@occupydemocrats.com, news@axios.com, info@axios.com, pips@axios.com, press@axios.com

-----

### SDN-00-10-FOMO-Dist-List-US-Govt-Senate

- Count: 33

adan_sanchez@lujan.senate.gov, allison_biasotti@schumer.senate.gov, angela_ramponi@murkowski.senate.gov, audrey_cook@blackburn.senate.gov, ausan_al-eryani@merkley.senate.gov, bobby_andres@schumer.senate.gov, caty_payette@heinrich.senate.gov, clare_slattery@grassley.senate.gov, david_bader@grassley.senate.gov, emily_hampsten@durbin.senate.gov, HSGACPress_Paul@hsgac.senate.gov, josh_sorbe@judiciary-dem.senate.gov, kaleb_froehlich@murkowski.senate.gov, luis_soriano@heinrich.senate.gov, natalie_yezbick@cornyn.senate.gov, paul_schedule@paul.senate.gov, press@baldwin.senate.gov, press@barrasso.senate.gov, press@bennet.senate.gov, press@brown.senate.gov, press@cantwell.senate.gov, press@cardin.senate.gov, press@casey.senate.gov, press@fischer.senate.gov, press@hirono.senate.gov, press@kaine.senate.gov, press@murphy.senate.gov, press@peters.senate.gov, press@tester.senate.gov, press@warner.senate.gov, press@whitehouse.senate.gov, press_paul@paul.senate.gov, tatum_wallace@cornyn.senate.gov

-----

### SDN-00-18-FOMO-Dist-List-US-State-AGs

- Count: 42

ConsumerInterest@AlabamaAG.gov, consumerprotection@alaska.gov, attorney.general@alaska.gov, consumerinfo@azag.gov, Attorney.General@azag.gov, consumer@ArkansasAG.gov, Attorney.General@ct.gov, attorney.general@delaware.gov, oag@dc.gov, oagpress@dc.gov, contactag@myfloridalegal.com, consumerprotection@law.ga.gov, hawaiiag@hawaii.gov, idahoag@ag.idaho.gov, PressOffice@ilag.gov, constituent@atg.in.gov, webteam@ag.iowa.gov, consumer.consumer@ag.iowa.gov, info@ag.ks.gov, attorney.general@ag.ky.gov, constituentservices@ag.louisiana.gov, attorney.general@maine.gov, oag@oag.state.md.us, consumer@oag.state.md.us, ago@mass.gov, miag@michigan.gov, attorney.general@ag.state.mn.us, info@ago.state.ms.us, attorney.general@ago.mo.gov, consumer.help@ago.mo.gov, ago.info.help@nebraska.gov, ago.consumer@nebraska.gov, AGInfo@ag.nv.gov, DOJ-CPB@doj.nh.gov, nmag@nmag.gov, ndag@nd.gov, ConsumerProtection@oag.ok.gov, AttorneyGeneral@doj.state.or.us, consumerhelp@state.sd.us, scdca@scconsumer.gov, consumerhelp@state.sd.us, uag@agutah.gov, ago.info@vermont.gov, CRC@atg.wa.gov, consumer@wvago.gov, ag.consumer@wyo.gov

----

