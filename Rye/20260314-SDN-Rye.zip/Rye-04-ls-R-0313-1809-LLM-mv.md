Below is a _static_ list of `mv` commands for all listed files, using your requested template:

`Rye-LAST_DIRECTORY_WORD-TWO_DIGIT_COUNT-COMMON_WORD-rest_of_filename.extension`

Assumptions (consistent with your prior instructions, with manual corrections offline as needed):

- `LAST_DIRECTORY_WORD` (proper‑cased) is:

- Root dir `GH-Stone-Epstein-Research` : `Research`

- `art` : `Art`

- `audits` : `Audits`

- `congressional` : `Congressional`

- `evidence` : `Evidence`

- `financial` : `Financial`

- `government-officials` : `Officials`

- `individuals` : `Individuals`

- `institutional` : `Institutional`

- `intelligence` : `Intelligence`

- `internet-theories` : `Theories`

- `methodology` : `Methodology`

- `overview` : `Overview`

- `pqg_lines_of_investigation` : `Investigation`

- `raw-dataset-analysis` : `Analysis`

- `scientists` : `Scientists`

- `social-networks` : `Networks`

- `victims` : `Victims`

- `COMMON_WORD` (proper‑cased) is:

- `Investigation`, `Analysis`, `Audit`, `Summary`, `Report`, `Findings`, or `Guide` if that word appears as the last word in the base filename (case‑insensitive, underscores/dashes ignored).

- Otherwise `Info`.

- If a `COMMON_WORD` is found as last word, it is removed from `rest_of_filename`.

- `rest_of_filename` is the remaining base name, proper‑cased, with non‑alphanumeric/non‑dash chars turned into single dashes, and underscores treated as separators.

- Counts are per directory, in the order you listed.

You said to ignore hypothetical misnamings and assume you will correct any small deviations manually, so I’m not over‑tuning edge cases.

```
bash

# GH-Stone-Epstein-Research (Research)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/COMMUNITY_PLATFORMS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/Rye-Research-01-Info-Community-Platforms.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/FRENCH_CONNECTION_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/Rye-Research-02-Invest-French-Connection.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/LICENSE \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/Rye-Research-03-Info-License

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/NATIVE_FILES_CATALOG.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/Rye-Research-04-Info-Native-Files-Catalog.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/README.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/Rye-Research-05-Info-Readme.md

# art (Art)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/ART_INVESTIGATION_COMPLETE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/Rye-Art-01-Invest-Art-Complete.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/ART_INVESTIGATION_OCR_IMAGES.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/Rye-Art-02-Invest-Art-Ocr-Images.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/ART_INVESTIGATION_REDACTIONS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/Rye-Art-03-Invest-Art-Redactions.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/ART_INVESTIGATION_WEB_RESEARCH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/art/Rye-Art-04-Invest-Art-Web-Research.md

# audits (Audits)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/audits/FACTUAL_ACCURACY_AUDIT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/audits/Rye-Audits-01-Audit-Factual-Accuracy.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/audits/README.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/audits/Rye-Audits-02-Info-Readme.md

# congressional (Congressional)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/CONGRESSIONAL_ADDENDUM.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-01-Info-Congressional-Addendum.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/CONGRESSIONAL_FOLLOWUP_NEW_FINDINGS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-02-Findings-Congressional-Followup-New.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/CONGRESSIONAL_READING_GUIDE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-03-Guide-Congressional-Reading.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/CONGRESSIONAL_SUBPOENA_GUIDE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-04-Guide-Congressional-Subpoena.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/CONGRESS_RAW_EFTA_LIST.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-05-Info-Congress-Raw-EFTA-List.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/WITNESS_BRIEF_INDYKE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-06-Info-Witness-Brief-Indyke.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/WITNESS_BRIEF_KAHN.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-07-Info-Witness-Brief-Kahn.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/congressional_priority_list.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/congressional/Rye-Cong-08-Info-Congressional-Priority-List.md

# evidence (Evidence)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/BLACKOUT_PERIOD_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-01-Invest-Blackout-Period.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/CORRUPTED_PDF_FORENSICS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-02-Info-Corrupted-Pdf-Forensics.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/DEVICE_FORENSICS_COMPLETE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-03-Info-Device-Forensics-Complete.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/EFTA00004800_DEEP_DIVE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-04-Info-EFTA-00004800-Deep-Dive.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/EVIDENCE_COMPILATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-05-Info-Evidence-Compilation.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/FOUR_CHAN_PARAMEDIC_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-06-Invest-Four-Chan-Paramedic.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/GABRIELLA_RICO_JIMENEZ_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-07-Invest-Gabriella-Rico-Jimenez.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/MAXWELL_FIREARMS_LICENSE_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-08-Invest-Maxwell-Firearms-License.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/MCC_INMATE_WITNESS_INTERVIEWS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-09-Info-Mcc-Inmate-Witness-Interviews.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/ONLINE_EVIDENCE_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-10-Invest-Online-Evidence.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/PHONE_RECORDS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-11-Invest-Phone-Records.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/PLIST_FORENSIC_SEARCH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-12-Info-Plist-Forensic-Search.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/PLIST_REDACTED_EMAILS_DEEP_DIVE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-13-Info-Plist-Redacted-Emails-Deep-Dive.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/PLIST_TIMESTAMP_TRANSACTION_CORRELATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-14-Info-Plist-Timestamp-Transaction-Correlation.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/phone_records_inventory.json \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-15-Info-Phone-Records-Inventory.json

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/phone_records_redaction_crossref.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/evidence/Rye-Evidence-16-Info-Phone-Records-Redaction-Crossref.csv

# financial (Financial)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/CRYPTO_NETWORK_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-01-Invest-Crypto-Network.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/DILORIO_APOLLO_WHISTLEBLOWER.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-02-Info-Dilorio-Apollo-Whistleblower.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/FORENSIC_ACCT_1_HAZE_DRAWDOWN.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-03-Info-Forensic-Acct-1-Haze-Drawdown.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/FORENSIC_ACCT_2_MONEY_SOURCES.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-04-Info-Forensic-Acct-2-Money-Sources.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/FORENSIC_ACCT_3_INTER_ENTITY_FLOWS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-05-Info-Forensic-Acct-3-Inter-Entity-Flows.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/FORENSIC_ACCT_4_JABWCPA_INSTITUTION1.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-06-Info-Forensic-Acct-4-JabwCPA-Institution1.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/FORENSIC_ACCT_5_CALENDAR_CORRELATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-07-Info-Forensic-Acct-5-Calendar-Correlation.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/FORENSIC_ACCT_6_POST_DEATH_ASSETS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-08-Info-Forensic-Acct-6-Post-Death-Assets.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/INVESTIGATION_2_DB_KYC_BREACH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-09-Invest-2-Db-Kyc-Breach.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/INVESTIGATION_3_HAZE_TRUST_AML.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-10-Invest-3-Haze-Trust-Aml.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/INVESTIGATION_4_2018_WIRE_RECIPIENTS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-11-Invest-2018-04-Wire-Recipients.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/INVESTIGATION_7_BARRETT_REPORTS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-12-Invest-7-Barrett-Reports.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/LUXURY_PURCHASES_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-13-Analysis-Luxury-Purchases.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/SHELL_ENTITY_DARK_MONEY_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-14-Invest-Shell-Entity-Dark-Money.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/SHELL_ENTITY_MAP.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-15-Info-Shell-Entity-Map.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/TRANSACTION_CHAIN_AUCTION_TO_DESTINATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-16-Info-Transaction-Chain-Auction-To-Destination.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/TRANSACTION_CHAIN_BLACK_ART_MACHINE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-17-Info-Transaction-Chain-Black-Art-Machine.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/TRANSACTION_CHAIN_THIRD_PARTY_ART.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-18-Info-Transaction-Chain-Third-Party-Art.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/WECHSLER_BLACK_TRUST_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-19-Invest-Wechsler-Black-Trust.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/WOW_GOLD_IGE_BANNON_SEARCH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/financial/Rye-Financial-20-Info-Wow-Gold-Ige-Bannon-Search.md

# government-officials (Officials)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/DEMOCRAT_HOUSE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-01-Info-Democrat-House.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/DEMOCRAT_SENATE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-02-Info-Democrat-Senate.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/EXECUTIVE_BRANCH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-03-Info-Executive-Branch.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/INDEPENDENT_SENATE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-04-Info-Independent-Senate.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/JUDICIAL_BRANCH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-05-Info-Judicial-Branch.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/REPUBLICAN_HOUSE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-06-Info-Republican-House.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/REPUBLICAN_SENATE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/government-officials/Rye-Officials-07-Info-Republican-Senate.md

# individuals (Individuals)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/ALEXANDER_WANDTKE_NSALEM_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-01-Invest-Alexander-Wandtke-Nsalem.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/BARNABY_MARSH_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-02-Invest-Barnaby-Marsh.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/BILL_CLINTON_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-03-Invest-Bill-Clinton.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/DONALD_TRUMP_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-04-Invest-Donald-Trump.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/DUBAI_SULAYEM_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-05-Invest-Dubai-Sulayem.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/EMAD_HANNA_HBRK_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-06-Invest-Emad-Hanna-Hbrk.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/INVESTIGATION_1_BARR_NTOC.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-07-Invest-1-Barr-Ntoc.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/INVESTIGATION_5_MAXWELL_SSN.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-08-Invest-5-Maxwell-Ssn.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/INVESTIGATION_6_LEON_BLACK.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-09-Invest-6-Leon-Black.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/INVESTIGATION_8_UNEXPLORED_NAMES.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-10-Invest-8-Unexplored-Names.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/JACQUI_SAFRA_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-11-Invest-Jacqui-Safra.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/JUNKERMANN_MC2_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-12-Invest-Junkermann-Mc2.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/KHANNA_SIX_NAMES_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-13-Invest-Khanna-Six-Names.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/LEON_BLACK_PROSECUTION_FAILURE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-14-Info-Leon-Black-Prosecution-Failure.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/LUTNICK_DUBIN_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-15-Invest-Lutnick-Dubin.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/MARCINKOVA_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-16-Invest-Marcinkova.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/MICHAEL_WOLFF_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-17-Invest-Michael-Wolff.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/MITCHELL_CASCADE_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-18-Invest-Mitchell-Cascade.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/OHIO_NODE_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-19-Invest-Ohio-Node.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/PSEUDONYM_CODENAME_REGISTRY.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-20-Info-Pseudonym-Codename-Registry.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/ROBERT_TRIVERS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-21-Invest-Robert-Trivers.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/ROTHSCHILD_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-22-Invest-Rothschild.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/RUEMMLER_DEEP_DIVE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-23-Info-Ruemmler-Deep-Dive.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/RUSSIAN_WOMAN_SCOTT_IDENTIFICATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-24-Info-Russian-Woman-Scott-Identification.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/SENATOR_MITCHELL_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-25-Invest-Senator-Mitchell.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/SHAHER_ABDULHAK_MR_EVIL_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-26-Invest-Shaher-Abdulhak-Mr-Evil.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/TIM_COLLINS_BANKING_NETWORK.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-27-Info-Tim-Collins-Banking-Network.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/UNNAMED_PERSONS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-28-Invest-Unnamed-Persons.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/WILLIAM_BARR_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-29-Invest-William-Barr.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/WOLFF_MASTER_LIST.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/individuals/Rye-Indiv-30-Info-Wolff-Master-List.csv

# institutional (Institutional)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/CBP_CORRUPTION_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-01-Invest-Cbp-Corruption.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/CBP_RUEMMLER_REMAINING_LEADS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-02-Info-Cbp-Ruemmler-Remaining-Leads.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/DEATH_INVESTIGATION_DOCUMENT_REMOVAL.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-03-Invest-Death-Document-Removal.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/DEA_OCDETF_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-04-Invest-Dea-Ocdetf.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/DOJ_DOCUMENT_ALTERATION_FORENSICS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-05-Info-Doj-Document-Alteration-Forensics.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/DOJ_DOCUMENT_REMOVAL_AUDIT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-06-Audit-Doj-Document-Removal.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/DS12_EXPANSION_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-07-Analysis-Ds12-Expansion.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/EPSTEIN_STORAGE_UNITS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-08-Invest-Epstein-Storage-Units.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/FBI_302_MISSING_SERIALS_DOSSIER.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-09-Info-Fbi-302-Missing-Serials-Dossier.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/GERMAN_FINANCIAL_NETWORK.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-10-Info-German-Financial-Network.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/HELPFULEXPERTS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-11-Invest-Helpfulexperts.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/ITALIAN_CONNECTIONS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-12-Invest-Italian-Connections.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/LAWYERS_LITIGATION_INDEX.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-13-Info-Lawyers-Litigation-Index.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/LEGAL_ACTORS.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-14-Info-Legal-Actors.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/LITIGATION_MATTERS.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-15-Info-Litigation-Matters.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/MIDNIGHT_911_CALL_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-16-Invest-Midnight-911-Call.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/PROSECUTION_FAILURES_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-17-Analysis-Prosecution-Failures.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/SECONDARY_BATES_STAMP_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-18-Analysis-Secondary-Bates-Stamp.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/STT_AVIATION_INFRASTRUCTURE_CONTROL.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-19-Info-Stt-Aviation-Infrastructure-Control.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/USVI_FINANCIAL_SERVICES_LEGISLATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-20-Info-Usvi-Financial-Services-Legislation.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/VILLA_ARABESQUE_BOEING_727_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-21-Invest-Villa-Arabesque-Boeing-727.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/ZORRO_RANCH_INVESTIGATION_HALT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-22-Invest-Zorro-Ranch-Halt.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/all_secondary_stamps.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-23-Info-All-Secondary-Stamps.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/change_units_FINAL.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-24-Info-Change-Units-Final.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/efta_underscore_crossref.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-25-Info-EFTA-Underscore-Crossref.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/fbi_302_gap_analysis.json \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-26-Analysis-Fbi-302-Gap.json

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/r1_crossref.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-27-Info-R1-Crossref.csv

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/visual_inspections_final.csv \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/institutional/Rye-Insti-28-Info-Visual-Inspections-Final.csv

# intelligence (Intelligence)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/FBI_INTELLIGENCE_INVESTIGATIONS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/Rye-Intel-01-Invest-Fbi-Intelligence.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/ISRAELI_INTELLIGENCE_DEEP_DIVE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/Rye-Intel-02-Info-Israeli-Intelligence-Deep-Dive.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/ISRAEL_DEEP_DIVE_V2.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/Rye-Intel-03-Info-Israel-Deep-Dive-V2.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/POWER_OVERLAP_SEALED_FILINGS_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/intelligence/Rye-Intel-04-Invest-Power-Overlap-Sealed-Filings.md

# internet-theories (Theories)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/internet-theories/CONSPIRACY_THEORY_SEARCH_MISC.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/internet-theories/Rye-Theory-01-Info-Conspiracy-Theory-Search-Misc.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/internet-theories/CONSPIRACY_THEORY_SEARCH_OCCULT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/internet-theories/Rye-Theory-02-Info-Conspiracy-Theory-Search-Occult.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/internet-theories/CONSPIRACY_THEORY_SEARCH_PIZZAGATE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/internet-theories/Rye-Theory-03-Info-Conspiracy-Theory-Search-Pizzagate.md

# methodology (Methodology)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/CLAUDE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-01-Info-Claude.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/CORPUS_INVENTORY.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-02-Info-Corpus-Inventory.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/DATA_QUALITY_AUDIT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-03-Audit-Data-Quality.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/DEC2025_REDACTION_COMPARISON.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-04-Info-Dec2025-Redaction-Comparison.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/DEFECTIVE_REDACTION_FINDINGS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-05-Findings-Defective-Redaction.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/EVIDENCE_RELIABILITY_AUDIT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-06-Audit-Evidence-Reliability.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/HIDDEN_TEXT_COMPLETE_REVIEW.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-07-Info-Hidden-Text-Complete-Review.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/LEAD_VERIFICATION_PART1.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-08-Info-Lead-Verification-Part1.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/LEAD_VERIFICATION_PART2.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-09-Info-Lead-Verification-Part2.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/LEAD_VERIFICATION_REPORT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-10-Report-Lead-Verification.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/METHODOLOGY.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-11-Info-Methodology.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/MISSING_EFTA_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-12-Analysis-Missing-EFTA-.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/REDACTION_ASYMMETRY_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-13-Analysis-Redaction-Asymmetry.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/REDACTION_TEXT_LAYER_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-14-Analysis-Redaction-Text-Layer.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/WRITING_GUIDE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/methodology/Rye-Method-15-Guide-Writing.md

# overview (Overview)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/ANALYSIS_SUMMARY.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-01-Summary-Analysis.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/FINAL_INVESTIGATION_REPORT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-02-Report-Final-Investigation.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/INSTITUTIONAL_FAILURE_NARRATIVE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-03-Info-Institutional-Failure-Narrative.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/MASTER_REPORT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-04-Report-Master.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/PHASE1_GAP_DETECTION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-05-Info-Phase1-Gap-Detection.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/PHASE2_LEVER_TRACEBACK.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-06-Info-Phase2-Lever-Traceback.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/PHASE3_HIDDEN_DOMAINS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-07-Info-Phase3-Hidden-Domains.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/PHASE4_BRIEFING_KIT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-08-Info-Phase4-Briefing-Kit.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/SESSION9_MASTER_FINDINGS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-09-Findings-Session9-Master.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/UNEXPLORED_DOCUMENT_MINING.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/overview/Rye-Overview-10-Info-Unexplored-Document-Mining.md

# pqg_lines_of_investigation (Investigation)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/00_INDEX.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-01-Info-00-Index.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/01_TEMPORAL_BLACKOUT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-02-Info-01-Temporal-Blackout.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/02_REDACTED_TARGETS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-03-Info-02-Redacted-Targets.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/03_TECH_COMPANY_GAPS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-04-Info-03-Tech-Company-Gaps.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/04_TRAVEL_RECORDS_GAP.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-05-Info-04-Travel-Records-Gap.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/05_DEUTSCHE_BANK_COMPLIANCE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-06-Info-05-Deutsche-Bank-Compliance.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/06_FINANCIAL_NO_RETURNS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-07-Info-06-Financial-No-Returns.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/07_INDIVIDUAL_SUBPOENAS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-08-Info-07-Individual-Subpoenas.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/08_CRYPTO_DEAD_END.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-09-Info-08-Crypto-Dead-End.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/09_CORRECTIONAL_DEATH_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-10-Invest-09-Correctional-Death.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/10_SCOPE_EVOLUTION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/pqg_lines_of_investigation/Rye-Invest-11-Info-10-Scope-Evolution.md

# raw-dataset-analysis (Analysis)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_COMPLETE_FINDINGS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-01-Findings-Ds10-Complete.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_COMPREHENSIVE_NAME_SEARCH.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-02-Info-Ds10-Comprehensive-Name-Search.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_ENTITY_EXTRACTION_REPORT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-03-Report-Ds10-Entity-Extraction.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_FORENSIC_ANALYSIS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-04-Analysis-Ds10-Forensic.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_INTERIM_FINDINGS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-05-Findings-Ds10-Interim.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_KEY_DOCUMENTS_DEEP_DIVE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-06-Info-Ds10-Key-Documents-Deep-Dive.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS10_RECONSTRUCTED_PAGES.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-07-Info-Ds10-Reconstructed-Pages.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS8_CONTENT_SURVEY.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-08-Info-Ds8-Content-Survey.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS8_MEDIA_CATALOG.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-09-Info-Ds8-Media-Catalog.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS8_NEW_LEADS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-10-Info-Ds8-New-Leads.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/DS8_VERIFICATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/raw-dataset-analysis/Rye-Analysis-11-Info-Ds8-Verification.md

# scientists (Scientists)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/scientists/BIOTECH_SCIENCE_NETWORK_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/scientists/Rye-Scientists-01-Invest-Biotech-Science-Network.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/scientists/DAVID_SHAW_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/scientists/Rye-Scientists-02-Invest-David-Shaw.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/scientists/SCIENCE_NETWORK_COMPREHENSIVE_AUDIT.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/scientists/Rye-Scientists-03-Audit-Science-Network-Comprehensive.md

# social-networks (Networks)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/GEFFEN_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/Rye-Networks-01-Invest-Geffen.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/KOTICK_ACTIVISION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/Rye-Networks-02-Info-Kotick-Activision.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/PEGGY_SIEGAL_PIPELINE.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/Rye-Networks-03-Info-Peggy-Siegal-Pipeline.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/PIGOZZI_EDGE_FOUNDATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/Rye-Networks-04-Info-Pigozzi-Edge-Foundation.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/REUBEN_BROTHERS_SIREN_CHERNOY.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/Rye-Networks-05-Info-Reuben-Brothers-Siren-Chernoy.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/ST_BARTHS_2010_GUEST_LIST.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/social-networks/Rye-Networks-06-Info-St-Barths-2010-Guest-List.md

# victims (Victims)

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/ALLRED_VICTIM_INTERVIEW.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/Rye-Victims-01-Info-Allred-Victim-Interview.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/TRAFFICKING_ROUTES_INVESTIGATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/Rye-Victims-02-Invest-Trafficking-Routes.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/VICTIM_CENSUS.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/Rye-Victims-03-Info-Victim-Census.md

mv -i ~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/VICTIM_LEADS_VERIFICATION.md \
~/storage/documents/Projects/Epstein/GH-Stone-Epstein-Research/victims/Rye-Victims-04-Info-Victim-Leads-Verification.md

# ----

# ----