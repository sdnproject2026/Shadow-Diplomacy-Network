#!/usr/bin/env bash

# Common words to promote; if none found, use "info"
COMMON_WORDS=("investigation" "analysis" "audit" "summary" "report" "findings" "guide")

# Proper-case helper: "FOO_BAR" -> "Foo-Bar"
proper_case() {
  local in="$1"
  echo "$in" \
    | tr '_' ' ' \
    | awk '{
        for (i=1; i<=NF; i++) {
          $i = tolower($i)
          sub(".", toupper(substr($i,1,1)), $i)
        }
        print
      }' \
    | tr ' ' '-'
}

# Last subdirectory word:
# take last path element, split on [-_/], take last non-empty piece, proper-case it
last_subdir_word() {
  local dirpath="$1"
  local last="${dirpath%/}"
  last="${last##*/}"
  local IFS='-_/'
  read -ra parts <<< "$last"
  local w="${parts[${#parts[@]}-1]}"
  w="$(proper_case "$w")"
  echo "$w"
}

# Promote common word
promote_common_word() {
  local base_noext="$1"
  local lower
  lower="$(echo "$base_noext" | tr 'A-Z' 'a-z')"
  local promoted=""
  local modified="$base_noext"

  local spaced
  spaced="$(echo "$lower" | tr '_-.' '   ')"

  for cw in "${COMMON_WORDS[@]}"; do
    if grep -qiE "(^| )${cw}( |$)" <<< "$spaced"; then
      promoted="$cw"
      local lastword="${spaced##* }"
      if [[ "$lastword" == "$cw" ]]; then
        modified="$(echo "$base_noext" | sed -E "s/[-_]*(${cw}|${cw^^}|${cw^})$//")"
      fi
      break
    fi
  done

  if [[ -z "$promoted" ]]; then
    promoted="info"
  fi

  echo "$promoted" "$modified"
}

declare -A dir_counts

while IFS= read -r path; do
  [[ -z "$path" ]] && continue
  [[ -d "$path" ]] && continue

  dir="${path%/*}"
  file="${path##*/}"

  if [[ -z "${dir_counts[$dir]}" ]]; then
    dir_counts[$dir]=1
  else
    dir_counts[$dir]=$(( dir_counts[$dir] + 1 ))
  fi
  count=$(printf "%02d" "${dir_counts[$dir]}")

  base="${file%.*}"
  ext="${file##*.}"
  if [[ "$file" == "$ext" ]]; then
    ext=""
  fi

  read promoted rest_base <<< "$(promote_common_word "$base")"

  subword="$(last_subdir_word "$dir")"
  rest_pc="$(proper_case "$rest_base")"
  middle="${subword}-${rest_pc}"
  middle="$(echo "$middle" | sed -E 's/[^A-Za-z0-9-]+/-/g' | sed -E 's/-+/-/g' | sed -E 's/^-+|-+$//g')"

  promoted_pc="$(proper_case "$promoted")"

  if [[ -n "$ext" && "$ext" != "$file" ]]; then
    newfile="Rye-${promoted_pc}-${count}-${middle}.${ext}"
  else
    newfile="Rye-${promoted_pc}-${count}-${middle}"
  fi

  newfile="$(echo "$newfile" | sed -E 's/[^A-Za-z0-9.-]+/-/g' | sed -E 's/-+/-/g' | sed
