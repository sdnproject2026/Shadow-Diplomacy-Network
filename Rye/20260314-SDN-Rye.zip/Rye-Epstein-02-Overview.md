# Epstein Files

## Investigation Report Library

- https://epstein-data.com/reports/README.html

### Published Time

2026-02-18 18:16:54-05:00

Rye - UConn.edu

Independent Analysis of the 218GB DOJ Jeffrey Epstein File Release

## Disclaimer

I am not an investigative journalist, I am a data scientist.

_All_ content within this repo which feeds the frontend site at

- https://epstein-data.com/

must be taken with a grain of salt: it has not been independently verified by a human.

It is primarily the result of Claude Opus 4.6 reviewing the searchable database I have established at:

- https://github.com/rhowardstone/Epstein-research-data

Remember, there is a _reason_ why journalists and investigators are so heavily trained and trusted.

There are extensive protocols they take in order to ensure the information they put out is vetted.

The average person does _not_ have these skills.

Do not reach _any_ conclusions based solely on the content in this repo.

The underlying data is available, and all source documents should be linked directly.

If you see any inaccuracies, broken links, or anything else fishy - please don't hesitate to reach out by opening an issue, or posting a comment at the end of the report on the website.

Similarly, _please_ remember to take care of yourself if you choose review these things.

Be very careful when looking through this stuff.

There is extensive training that people go through who do this for a living to make sure they properly self-care, decompress, and take breaks.

It is _very_ easy to get carried away, very easy to have emotional reactions.

For example, data scientists who read CSAM-adjacent material are subject to mandatory maximum shift lengths, mandatory group therapy and debrief sessions with others who are going through the same data.

Be good to yourself, be with friends, and _do not just pour through it without taking solid breaks_.

The content is intended _only for people 18+_, and only _at your own peril_.

I am hoping a structured, indexed, organized set of documents makes the "click-bait jump scares" less traumatizing than those we are seeing on social media.

Second-hand PTSD is a real phenomenon, and you do not want to live with some of the descriptions and images within this dataset in your head for the rest of time.

### About This Repository

This repository contains 165+ investigation reports derived from the US
Department of Justice's release of Jeffrey Epstein investigation files - 218 GB across 12 datasets (plus FBI Vault and House Oversight materials), comprising 1,385,916 documents (2,771,231 pages), plus 3,864 non-PDF native files (video, audio, spreadsheets).

The analysis involved full-text extraction and FTS5 indexing of every page, 2,587,102 redaction records, 1,628 audio/video transcripts, a 1,614-person entity registry, and cross-referenced entity relationships (606 entities, 2,302 connections).

Every factual claim in these reports traces back to specific EFTA document numbers (Epstein Files Task Force Archive).

Click any linked EFTA number to attempt to view the original PDF on justice.gov.

_This is not opinion or speculation._ These reports synthesize what the documents themselves say, with sourcing.

Where conclusions are drawn, the supporting evidence chain is cited.

Where evidence is ambiguous, that is noted.

If you notice any problems, please raise an ISSUE on this repository or post a comment on the report page at https://epstein-data.com/reports, and it will be attended to promptly.

### Install the full AI-powered Investigator

## You can also install my full Claude-powered Epstein Investigator setup yourself, by following the directions for the

- https://epstein-data.com/investigate

or

- https://epstein-data.com/investigate_cli

### How to Read EFTA Citations

Every `EFTA` number is a unique DOJ document identifier.

Throughout these reports, EFTA numbers are hyperlinked to the DOJ's original PDF hosting location:

```
https://www.justice.gov/epstein/files/DataSet%20{N}/EFTA{########}.pdf
```

See

- https://epstein-data.com/reports/README.html#efta-number-to-dataset-mapping

at the bottom of this file to determine which dataset contains a given EFTA number.

Investigation Reports

Browse the

- https://epstein-data.com/reports/

for the complete catalog, or explore by ca>tegory below.

### Overview & Executive Summaries - 10 reports

- https://epstein-data.com/reports/overview/

Early investigation syntheses, gap detection, hidden domain analysis, and congressional briefing materials from the first sweep of the 2.73M-page corpus.

Start with the

- https://epstein-data.com/reports/overview/FINAL_INVESTIGATION_REPORT.html

 (400+ EFTA citations, $755M traced, 30+ named individuals) or

- https://epstein-data.com/reports/overview/INSTITUTIONAL_FAILURE_NARRATIVE.html

 (7-chapter prosecutorial failure timeline, 1996–2024).

### Financial Analysis - 20 reports

- https://epstein-data.com/reports/financial/

## Financial analysis of Epstein's financial architecture

95+ shell entities, $755M+ traced, Deutsche Bank KYC failures, Haze Trust drawdown, the Leon Black art-money pipeline, and post-death estate disposition.

Highlights:

 -

- https://epstein-data.com/reports/financial/SHELL_ENTITY_MAP.html

 - complete map of 95+ entities across 10 categories under RM CODE 82289

 -

- https://epstein-data.com/reports/financial/TRANSACTION_CHAIN_BLACK_ART_MACHINE.html

 - 15 transaction chains tracing $168M Black-to-Epstein, art pipeline and trafficking pipeline as one structure

 -

- https://epstein-data.com/reports/financial/FORENSIC_ACCT_4_JABWCPA_INSTITUTION1.html

 - de-redacted the FBI's pseudonymized CPA and bank via DS9

### Named Individuals - 28 reports

- https://epstein-data.com/reports/individuals/

Investigation dossiers on specific named persons in the Epstein corpus.

Covers prosecution failures, financial entanglements, corroborated victim testimony, and de-redacted identities.

Highlights:

 -

- https://epstein-data.com/reports/individuals/LEON_BLACK_PROSECUTION_FAILURE.html

 - SDNY + Manhattan DA failed to charge despite 4+ victims, FBI 302s, $62.5M USVI settlement

##  -

- https://epstein-data.com/reports/individuals/WILLIAM_BARR_INVESTIGATION.html

 - 55+ documents

NTOC tip, father hired Epstein at Dalton, Kirkland & Ellis conflict, split recusal, death investigation oversight

 -

- https://epstein-data.com/reports/individuals/TIM_COLLINS_BANKING_NETWORK.html

 - Ripplewood Holdings founder brokered European banking partnerships linking Prince Andrew, Jes Staley, Peter Mandelson, and Ehud Barak through Epstein's network

 -

- https://epstein-data.com/reports/individuals/KHANNA_SIX_NAMES_INVESTIGATION.html

 - the six men whose names were redacted by the FBI and read onto the House floor

Also includes the

- https://epstein-data.com/reports/individuals/PSEUDONYM_CODENAME_REGISTRY.html

 - 273 EFTA-cited pseudonyms and code names mapped to real identities.

- https://epstein-data.com/reports/social-networks/

## How Epstein's social circles overlapped and reinforced each other

Peggy Siegal as the access broker into Manhattan society, David Geffen's art-world orbit, Bobby Kotick's Activision-era contacts, the St.

Barths 2010 New Year's guest list, Reuben Brothers/Siren/Chernoy oligarch connections, and Jean Pigozzi's Edge Foundation pipeline.

### Intelligence Connections - 4 reports

- https://epstein-data.com/reports/intelligence/

## Israeli intelligence links, FBI Confidential Human Source reports, Ehud Barak's 3,756-document footprint, Carbyne/Reporty surveillance tech, and power overlap analysis.

Key document

- https://epstein-data.com/EFTA00090314

 - FBI CHS states Epstein "belonged to both US
and allied intelligence services" and "trained as a spy under" former Israeli PM Barak.

See the

- https://epstein-data.com/reports/intelligence/ISRAEL_DEEP_DIVE_V2.html

 for full analysis.

### Institutional Failures - 19 reports

- https://epstein-data.com/reports/institutional/

## How institutions failed, enabled, or actively participated

prosecution failures, DOJ document removals and alterations, CBP corruption, secondary Bates stamp analysis revealing 1.46M pages withheld, FBI 302 missing serials, German financial network architecture, USVI financial services legislation, DEA/OCDETF connections, and more.

Highlights:

##  -

- https://epstein-data.com/reports/institutional/DOJ_DOCUMENT_ALTERATION_FORENSICS.html

 - 212,730 change units detected

names removed, emails deleted, surveillance records altered after publication

 -

- https://epstein-data.com/reports/institutional/DOJ_DOCUMENT_REMOVAL_AUDIT.html

 - ~64,259 PDFs removed from justice.gov after initial publication (67,784 confirmed 404, adjusted for ~5% false-positive rate)

 -

- https://epstein-data.com/reports/institutional/SECONDARY_BATES_STAMP_ANALYSIS.html

 - six pre-production numbering systems reveal 57% of FBI device extractions never made it into the public release

 -

- https://epstein-data.com/reports/institutional/DS12_EXPANSION_ANALYSIS.html

 - 23 new documents quietly added to justice.gov in March 2026, including the proposed 60-count indictment that became the NPA

 -

- https://epstein-data.com/reports/institutional/CBP_CORRUPTION_INVESTIGATION.html

 - de-redacted the officer who cleared Epstein's aircraft at St.

Thomas for 7+ years

### Evidence & Digital Analysis - 13 reports

- https://epstein-data.com/reports/evidence/

Device forensics (70+ devices, a 2005 computer image never examined by federal authorities), Apple Mail PLIST metadata, corrupted PDF byte-level recovery, FBI evidence binder analysis, MCC death investigation evidence, and online evidence trails.

Highlights:

 -

- https://epstein-data.com/reports/evidence/DEVICE_FORENSICS_COMPLETE.html

 - DVR failure 12 days pre-death, 6 machines unexported Oct 2020

 -

- https://epstein-data.com/reports/evidence/CORRUPTED_PDF_FORENSICS.html

 - recovered Apple Address Book with 8 contacts and an iPhone 5s photo from Little Saint James, Aug 2014

### Scientists & Academic Network - 3 reports

- https://epstein-data.com/reports/scientists/

## Epstein's science funding pipeline through the Brockman/Edge Foundation

35+ scientists, 10,000+ documents, 8 Nobel laureates, Martin Nowak ($6.5M), Noam Chomsky (trust management), Danny Hillis (Zorro Ranch), Biden Science Advisor Eric Lander, Nathan Wolfe (Global Viral/Metabiota), and FBI FinCEN investigation of Robert Trivers.

See the

- https://epstein-data.com/reports/scientists/SCIENCE_NETWORK_COMPREHENSIVE_AUDIT.html

.

### Victim Analysis - 4 reports

- https://epstein-data.com/reports/victims/

Victim census, trafficking routes, FBI evidence packages, and lead verification.

Minimum 60–80 individually identified victims, likely 200+, USVI civil suit says "hundreds." Privacy protections strictly enforced - no real names, pseudonyms only.

See

- https://epstein-data.com/reports/victims/TRAFFICKING_ROUTES_INVESTIGATION.html

 for the aircraft fleet, weekly cycling routes, MC2 recruitment (ages 13–20), and CBP bypass mechanics.

### Art World - 4 reports

- https://epstein-data.com/reports/art/

$30.5M in auction proceeds traced through Haze Trust, Leon Black's $2.7B collection, 54 named art world figures, Sotheby's and Christie's transaction chains.

The

- https://epstein-data.com/reports/art/ART_INVESTIGATION_COMPLETE.html

 (80KB, 100+ EFTA citations) covers it all, with supporting sub-reports on OCR/image evidence, redaction records, and open-source intelligence.

### Government Officials - 7 reports

- https://epstein-data.com/reports/government-officials/

## Full-corpus search of all 537 current members of Congress (119th), 77 executive branch officials, and 503 Article III federal judges.

Every name searched as an exact phrase across all 1.38M documents.

Key finding in

- https://epstein-data.com/reports/government-officials/EXECUTIVE_BRANCH.html

William Burns (future CIA Director) had direct email exchanges with Epstein in 2014; Epstein brokered a Burns-Thiel introduction.

### International Investigations

## *

- https://epstein-data.com/reports/FRENCH_CONNECTION_INVESTIGATION.html

 - Epstein's operations in France

Brunel/MC2/Karin Models recruitment pipeline, 22 Avenue Foch, Jack Lang & Prytanee LLC, UN diplomat Fabrice Aidan, Deutsche Bank wires through French banks.

Written as a guide for French investigators.

### Internet Theories - 3 reports

- https://epstein-data.com/reports/internet-theories/

## Exhaustive corpus searches for popular internet theories

Pizzagate, satanic rituals, adrenochrome, blood drinking, and miscellaneous claims.

_All returned NEGATIVE._ Zero supporting evidence across 3.5M+ records and 519,438 PDFs.

### Methodology & Data Quality - 12 reports + 2 audits

- https://epstein-data.com/reports/methodology/

 and

- https://epstein-data.com/reports/audits/

Evidence chain documentation, redaction analysis, data quality audits, lead verification, and corrections.

Start with:

##  -

- https://epstein-data.com/reports/methodology/CORPUS_INVENTORY.html

 - the master evidence chain

what data exists, where it came from, and how to verify any finding

 -

- https://epstein-data.com/reports/methodology/MISSING_EFTA_ANALYSIS.html

 - all 2,731,783 page-numbers accounted for, 100% complete

 -

- https://epstein-data.com/reports/audits/FACTUAL_ACCURACY_AUDIT.html

 - 225 issues across ~50 reports in 43 phases, every correction documented

### Raw Dataset Analysis - 11 reports

- https://epstein-data.com/reports/raw-dataset-analysis/

Per-dataset deep dives into DS8 and DS10 - the two datasets containing the bulk of newly released material.

Entity extraction (107,422 entities from 529,061 records), name searches, key document deep dives, and 39,588 reconstructed pages from spatially-ordered redaction fragments.

### Prosecutorial Query Graph - 11 reports

- https://epstein-data.com/reports/pqg_lines_of_investigation/

Structured analysis of 257 grand jury subpoenas decomposed into 2,018 individual demand clauses, matched against production records.

48.2% of subpoenas have no identifiable return in the corpus.

Covers the 524-day subpoena gap, 27 fully-redacted targets, tech company gaps, Deutsche Bank compliance, crypto dead ends, and correctional death investigation gaps.

See the

- https://epstein-data.com/reports/pqg_lines_of_investigation/00_INDEX.html

 for methodology.

EFTA Number to Dataset Mapping
------------------------------

Use this table to determine which DOJ dataset contains a given EFTA number, or to construct the DOJ URL manually.

| Dataset | EFTA Range Start | EFTA Range End | URL Pattern |
| --- | --- | --- | --- |
| 1 |

- https://epstein-data.com/EFTA00000001

 |

- https://epstein-data.com/EFTA00003158

 | `DataSet%201/EFTA{########}.pdf` |
| 2 |

- https://epstein-data.com/EFTA00003159

 |

- https://epstein-data.com/EFTA00003857

 | `DataSet%202/EFTA{########}.pdf` |
| 3 |

- https://epstein-data.com/EFTA00003858

 |

- https://epstein-data.com/EFTA00005586

 | `DataSet%203/EFTA{########}.pdf` |
| 4 |

- https://epstein-data.com/EFTA00005705

 |

- https://epstein-data.com/EFTA00008320

 | `DataSet%204/EFTA{########}.pdf` |
| 5 |

- https://epstein-data.com/EFTA00008409

 |

- https://epstein-data.com/EFTA00008528

 | `DataSet%205/EFTA{########}.pdf` |
| 6 |

- https://epstein-data.com/EFTA00008529

 |

- https://epstein-data.com/EFTA00008998

 | `DataSet%206/EFTA{########}.pdf` |
| 7 |

- https://epstein-data.com/EFTA00009016

 |

- https://epstein-data.com/EFTA00009664

 | `DataSet%207/EFTA{########}.pdf` |
| 8 |

- https://epstein-data.com/EFTA00009676

 |

- https://epstein-data.com/EFTA00039023

 | `DataSet%208/EFTA{########}.pdf` |
| 9 |

- https://epstein-data.com/EFTA00039025

 |

- https://epstein-data.com/EFTA01262781

 | `DataSet%209/EFTA{########}.pdf` |
| 10 |

- https://epstein-data.com/EFTA01262782

 |

- https://epstein-data.com/EFTA02205654

 | `DataSet%2010/EFTA{########}.pdf` |
| 11 |

- https://epstein-data.com/EFTA02205655

 |

- https://epstein-data.com/EFTA02730264

 | `DataSet%2011/EFTA{########}.pdf` |
| 12 |

- https://epstein-data.com/EFTA02730265

 |

- https://epstein-data.com/EFTA02858497

 | `DataSet%2012/EFTA{########}.pdf` |
_Base URL:_`https://www.justice.gov/epstein/files/`

_Note:_ EFTA numbers are assigned _per page_, not per document.

A multi-page document consumes consecutive EFTA numbers - e.g.,

- https://epstein-data.com/EFTA00008320

 (89 pages) covers Bates numbers 00008320–00008408, and Dataset 5 begins at

- https://epstein-data.com/EFTA00008409

.

There are _no gaps_ between datasets; every apparent gap is accounted for by multi-page documents at dataset boundaries.

_DS12 Expansion (March 2026):_ 23 additional documents were added to the Dataset 12 URL path with EFTA numbers beyond the original range (02731783→02858497).

These include Operation Leap Year prosecution memos (the proposed 60-count federal indictment that was dismantled before the NPA), a 582-page FBI case file, FBI 302 victim interviews, MCC death investigation materials, and FBI intelligence reports.

Methodology
-----------

All analysis was performed locally against databases derived from the raw PDF corpus.

No documents were uploaded to cloud services or third-party APIs.

| Database | Size | Records | Contents |
| --- | --- | --- | --- |
| full_text_corpus.db | 6.3 GB | 1,385,916 docs / 2,771,231 pages | Full text of every page of every document (PyMuPDF extraction + invisible OCR text layers) |
| redaction_analysis_v2.db | 0.95 GB | 2,587,102 redactions / 849,655 docs | Spatial redaction analysis with text at each redaction's coordinates |
| transcripts.db | 2.5 MB | 1,628 entries (435 with speech) | GPU-transcribed audio/video (faster-whisper large-v3 on A100) |
| persons_registry.json | - | 1,614 persons | Unified entity registry from 9 sources |
| knowledge_graph.db | - | 606 entities / 2,302 connections | Cross-referenced entity relationships |
**

- https://epstein-data.com/reports/NATIVE_FILES_CATALOG.csv

** - Complete inventory of all 3,864 non-PDF native files (video, audio, spreadsheets, images) across the DOJ release.

Every non-PDF file has a corresponding PDF placeholder on DOJ; native files include MCC surveillance videos, grand jury audio, prison phone calls, FBI interview recordings, and financial spreadsheets.

For the complete evidence chain - what data exists, where it came from, and how to verify any finding - see

- https://epstein-data.com/reports/methodology/CORPUS_INVENTORY.html

.

## Processed data collection

https://github.com/rhowardstone/Epstein-research-data

See **

- https://epstein-data.com/reports/COMMUNITY_PLATFORMS.html

** for a directory of 78+ platforms, tools, and resources for searching and analyzing the Epstein files - government sources, search platforms, network visualization tools, AI/RAG tools, datasets, and community hubs.

Processing Tools
----------------

## All processing scripts (36+ Python tools) used to build the databases live in the data repo

**

- https://github.com/rhowardstone/Epstein-research-data/tree/main/tools

**

Disclaimer
----------

These reports constitute independent analysis of publicly released government documents.

They are not legal advice, not government publications, and not affiliated with any law enforcement agency.

All findings are derived from documents released by the US
Department of Justice and are cited to specific EFTA document numbers that can be independently verified.

Where the evidence is ambiguous or inconclusive, that is stated explicitly.

Where claims from prior reporting were found to be incorrect upon verification, corrections are documented (see Lead Verification reports).

Negative findings (searches that returned zero results) are reported with equal rigor to positive findings.

This repository does not contain any original source documents, victim-identifying information, or classified material.

It contains only analysis and citations.