# Synopsis

## Rye-Insti-14-Info-Legal-Actors

Based on the data provided in the referenced URL

- https://pastebin.com/raw/cRzXMKVn

and, formatting the response according to content of

- https://pastebin.com/raw/mXvZn7tk

and the parameters for the **Rye-Insti-14** information project, here is the enumerated analysis of legal actors and documentation.

(Gemini LLM)

## Cases

- 1:15-cv-07433-LAP (S.D.N.Y.)

- 9:08-cv-80736 (S.D. Fla.)

- 1:19-cv-03377 (S.D.N.Y.)

- 08-80110-CR-Marra (S.D. Fla.)

- 2008-CF-009149-AXX (Palm Beach County)

- 09-80025-CR-Ryskamp (S.D. Fla.)

- In re Courtney Wild, 994 F. 3d 1244 (11th Cir. 2021)

## NPA Persons

- Jeffrey Epstein

- Ghislaine Maxwell

- Sarah Kellen (Vickers)

- Adriana Ross

- Lesley Groff

- Nadia Marcinkova

- Alexander Acosta

- Marie Villafaña

## Jurisdictions

- Southern District of New York (S.D.N.Y.)

- Southern District of Florida (S.D. Fla.)

- 11th Circuit Court of Appeals

- Palm Beach County, Florida

- United States Virgin Islands (USVI)

## EFTA Titles & Doc Numbers

- EFTA00605803

- EFTA00605804

- EFTA02731783

- EFTA02858497

- EFTA Pub. L. 119-38

- _Operation Leap Year_ Prosecution Memos


## Settled

- Jeffrey Epstein 
    - (Settled with State of Florida/USAO)

- Prince Andrew 
    - (Settled with Virginia Giuffre)

- Alan Dershowitz 
    - (Settled with Virginia Giuffre)

- JPMorgan Chase 
    - (Settled with USVI/Victims)

- Deutsche Bank 
    - (Settled with Victims)

## Associates

- **Perp:** Jeffrey Epstein

- **Associate:** Ghislaine Maxwell

- **Associate:** Jean-Luc Brunel

- **Associate:** Leslie Wexner

- **Co-conspirator:** Sarah Kellen

- **Co-conspirator:** Adriana Ross

- **Co-conspirator:** Nadia Marcinkova

## Deaths

- Jeffrey Epstein (Suicide/Deceased 2019)

- Alfredo Rodriguez (Cancer/Deceased 2014)

- Jean-Luc Brunel (Suicide/Deceased 2022)



## Unsealed NPA / Federal Documents



- https://www.justice.gov/epstein/files/



- https://epstein-docs.github.io/


- https://info.publicintelligence.net/EpsteinDocs-Batch5.pdf



- https://vault.fbi.gov/jeffrey-epstein


## Rodriguez "Black Book" Content



- https://epstein-data.com/reports



- https://www.plainsite.org/documents/4ue1v2be/usdoj-epstein-files-document-efta00605803/



- https://github.com/rhowardstone/Epstein-research