### Rye-Insti-14-Info-Legal-Actors-list

# Persons

## Darren Indyke
- ```OF``` NA
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- General counsel
- co-executor
- trustee of 1953 Trust
- EFTA02171955
- Most-mentioned lawyer in corpus by wide margin

## Richard Kahn
- ```OF``` NA
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- Co-executor
- trustee
- financial administration
- Most-mentioned individual after Epstein himself.
- Raw 'Kahn' count inflated 2x - 5x by financial record collisions

## Kathryn Ruemmler
- ```OF``` Latham & Watkins, Goldman Sachs
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- Backup executor
- removed before death
- former White House Counsel (2011-2014
- Goldman Sachs GC 2021-2026
- announced departure Feb 2026 effective June 30 2026 following EFTA email revelations

## Erika Kellerhals
- ```OF``` NA
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- USVI tax law
- USVI immigration
- Received $23M+ in documented payments

## Robert Glassman
- ```OF``` NA
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- Personal / business counsel

## Alan Grubman
- ```OF``` Grubman Shire
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- Entertainment / media lawyer
- Personal relationship

## Dlugash
- ```OF``` NA
- ```IS``` Associate
- ```FOR``` Perp
### Notes:
- Estate planning
- tax
- EFTA01917842
- Full name varies in corpus
- settlement agreement from 2000

## Alan Dershowitz
- ```OF``` NA
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- Criminal appellate
- constitutional law
- 08-80736
- 08-80736-CIV-MARRA
- EFTA00009116
- Harvard Law professor.
- Threatened Acosta re prosecutorial overreach
- Later named as abuser by Giuffre
- denied allegations

## Kenneth Starr
- ```OF``` Kirkland & Ellis
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- Former Solicitor General
- former independent counsel
- Whitewater
- 08-80736
- EFTA01659896
- Argued against federal prosecution in letters to SDFL.
- Died September 2022.

## Jay Lefkowitz
- ```OF``` Kirkland & Ellis
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- Former deputy assistant to the President
- 08-80736
- 08-80736-CIV-MARRA
- EFTA00013811
- Negotiated NPA drafts with AUSA Villafana
- Argued insufficient evidence Epstein targeted minors

## Gerald Lefcourt
- ```OF``` NA
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- Criminal defense
- 08-80736
- NY criminal defense attorney

## Jack Goldberger
- ```OF``` Atterbury Goldberger Weiss, P.A.
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- FL criminal defense
- 08-80736
- CF 09454
- 08-80736-CIV-MARRA
- EFTA01659770
- Primary FL defense counsel
- Firm: 1877 docs

## Roy Black
- ```OF``` Black Srebnick Kornspan & Stumpf, P.A.
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- FL criminal defense
- 08-80736
- 08-80736-CIV-MARRA
- Miami's best criminal defense lawyer
- Firm: 994 docs
- Listed on CVRA Certificates of Service as Criminal Defense Counsel

## Lilly Ann Sanchez
- ```OF``` Fowler White Burnett, P.A.
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- FL defense
- 08-80736
- CF 09454
- EFTA02171955
- Managed privilege logs per email reminders

## Guy Lewis
- ```OF``` Lewis Tein, P.L.
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- Former USAO chief
- SDFL
- 08-80736
- EFTA00009116
- Acosta: prosecutors that formerly worked in the US Attorney's Office

## Joseph Ackerman
- ```OF``` Fowler White Burnett, P.A.
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- FL defense
- 08-80736
- CF 09454
- 50 2009CA040800XXXXMB AG
- EFTA00592983
- Signed Certificates of Service in victim civil suits
- Firm: 2116 docs

## Reid Weingarten
- ```OF``` Steptoe & Johnson
- ```IS``` SDNY Defense
- ```FOR``` Perp
### Notes:
- Criminal defense
- 19-cr-490
- Lead criminal defense counsel
- SDNY 2019
- Firm: 802 docs

## Martin Weinberg
- ```OF``` NA
- ```IS``` NPA Defense
- ```FOR``` Perp
### Notes:
- Criminal defense
- 08-80736
- 08-80736-CIV-MARRA
- 19-cr-490
- Served on both NPA-era and SDNY 2019 defense teams

## Marc Fernich
- ```OF``` NA
- ```IS``` SDNY Defense
- ```FOR``` Perp
### Notes:
- Criminal defense
- 19-cr-490
- SDNY 2019 co-counsel

## Bruce Barket
- ```OF``` Barket Epstein Kearon
- ```IS``` SDNY Defense
- ```FOR``` Perp
### Notes:
- Criminal defense
- 19-cr-490
- SDNY 2019 co-counsel

## Joseph Nascimento
- ```OF``` Ross Amsel Raben
- ```IS``` SDNY Defense
- ```FOR``` Perp
### Notes:
- Criminal defense
- 19-cr-490
- SDNY 2019 co-counsel

## Laura Menninger
- ```OF``` Haddon Morgan Foreman
- ```IS``` maxwell defense
- ```FOR``` Perp
### Notes:
- Lead trial counsel
- 20-cr-330
- 15-cv-7433
- Firm: 1447 docs

## Jeffrey Pagliuca
- ```OF``` Haddon Morgan Foreman
- ```IS``` maxwell defense
- ```FOR``` Perp
### Notes:
- Co-counsel
- 20-cr-330
- 15-cv-7433

## Christian Everdell
- ```OF``` Cohen & Gresser
- ```IS``` maxwell defense
- ```FOR``` Perp
### Notes:
- Co-counsel
- 20-cr-330
- Firm: 1495 docs

## Bobby Sternheim
- ```OF``` Sternheim & Sternheim
- ```IS``` maxwell defense
- ```FOR``` Perp
### Notes:
- Co-counsel
- 20-cr-330

## David Bruck
- ```OF``` NA
- ```IS``` maxwell defense
- ```FOR``` Perp
### Notes:
- Sentencing specialist
- 20-cr-330

## Brad Edwards
- ```OF``` Edwards & Pottinger, later Edwards Henderson
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Lead Attorney
- CVRA pioneer
- 08-80736-CIV-MARRA
- 50 2009CA040800XXXXMB AG
- Counter-sued by Epstein (§1.6).
- Firm: 555 docs

## Paul Cassell
- ```OF``` University of Utah, pro bono
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- CVRA specialist
- constitutional law scholar
- 08-80736-CIV-MARRA
- Filed original CVRA challenge to NPA

## Jack Scarola
- ```OF``` Searcy Denney Scarola Barnhart & Shipley
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Victim civil suits
- EFTA01480957
- Told Judge Crow all lawsuits settled for very substantial sums.
- Firm: 1817 docs

## Sigrid McCawley
- ```OF``` Boies Schiller Flexner
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- lead counsel
- 15-cv-7433
- Lead counsel for Virginia Giuffre in defamation suit

## David Boies
- ```OF``` Boies Schiller Flexner
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Giuffre v. Maxwell
- 15-cv-7433
- Chairman of BSF. 
- Embroiled in 2019 Patrick Kessler affair
- reported contact to FBI
- no criminal charges.
- Firm: 1423 docs

## Stan Pottinger
- ```OF``` Edwards & Pottinger
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Victim attorney
- Also involved in Kessler affair. 
- Kessler was a fraud. 
- No criminal charges filed. 
- Pottinger later died (age 84).

## Gloria Allred
- ```OF``` Allred Maroko & Goldberg
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## Jeanne Christensen
- ```OF``` Wigdor LLP
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Leon Black victims
- EFTA02731473
- Emailed SDNY: it is outrageous that criminal charges have not been brought against Black
- Firm: 84 docs

## Spencer Kuvin
- ```OF``` Leopold Kuvin, formerly Ricci Leopold
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- FL victim civil suits

## Theodore Leopold
- ```OF``` Ricci Leopold, P.A., now Leopold Kuvin
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## Stuart Mermelstein
- ```OF``` Mermelstein & Horowitz, P.A.
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation
- Firm: 362 docs

## Adam Horowitz
- ```OF``` Mermelstein & Horowitz, P.A.
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## Jeffrey Herman
- ```OF``` Herman Law
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## Jay Howell
- ```OF``` Jay Howell & Associates
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## Kara Rockenbach
- ```OF``` Link & Rockenbach / Burlington & Rockenbach
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Appellate counsel

## Scott Link
- ```OF``` Link & Rockenbach
- ```IS``` FL Defense
- ```FOR``` Perp
### Notes:
- Appellate counsel
- Listed in §2.4 but role is Epstein defense
- appellate

## Brittany Henderson
- ```OF``` Edwards Pottinger LLC
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## David Vitale
- ```OF``` Searcy Denney Scarola
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Legal Representation

## Gary Farmer Jr.
- ```OF``` Farmer Jaffe Weissing Edwards Fistos & Lehrman
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Edwards defense counsel
- Epstein v. Edwards
- 50 2009CA040800XXXXMB AG
- Defended Brad Edwards when Epstein counter-sued

## Kevin Boyle
- ```OF``` Panish Shea & Boyle
- ```IS``` Attorney
- ```FOR``` Victim
### Notes:
- Maxwell victim representation

## Geoffrey S. Berman
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- US Attorney
- SDNY
- 2018-2020
- 19-cr-490

## Audrey Strauss
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- Acting US Attorney
- 2020-2021
- 20-cr-330

## Maurene Comey
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- lead trial prosecutor
- 19-cr-490
- 20-cr-330

## Alison Moe
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- co-prosecutor
- 19-cr-490
- 20-cr-330

## Alexander Rossmiller
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- co-prosecutor
- 19-cr-490
- 20-cr-330

## Nicolas Roos
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- BOP interviews
- 20-cr-330

## Rebekah Donaleski
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- MCC interviews
- 20-cr-330

## Damian Williams
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- US Attorney
- 2021-2025
- 20-cr-330

## Jason Swergold
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- MCC conditions / FOIA

## Lara Pomerantz
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA

## Andrew Rohrbach
- ```OF``` SDNY USAO
- ```IS``` SDNY prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA

## R. Alexander Acosta
- ```OF``` SDFL USAO
- ```IS``` SDFL prosecutor
- ```FOR``` Gov't
### Notes:
- US Attorney
- SDFL
- 08-80736
- EFTA00009116
- Resigned as Secretary of Labor July 2019 over NPA controversy

## A. Marie Villafana
- ```OF``` SDFL USAO
- ```IS``` SDFL prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- lead investigator
- 08-80736
- Name frequently OCR-garbled as Villafalia or Villafaila

## Andrew Lourie
- ```OF``` SDFL USAO
- ```IS``` SDFL prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- 08-80736

## Dexter Lee
- ```OF``` SDFL USAO
- ```IS``` SDFL prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA
- 08-80736
- 08-80736-CIV-MARRA

## Bruce Reinhart
- ```OF``` NA
- ```IS``` SDFL prosecutor
- ```FOR``` Gov't
### Notes:
- AUSA (1996-2008
- then private attorney
- then Magistrate Judge
- 08-80736
- EFTA01657803
- Resigned USAO Jan 01 2008
- retained by Epstein next day to represent Kellen / co-conspirators. 
- Appointed Magistrate March 2018. 
- OPR investigated.

## Barry Krischer
- ```OF``` State Attorney Office, Palm Beach County
- ```IS``` state prosecutor
- ```FOR``` Gov't
### Notes:
- State Attorney
- Palm Beach County
- CF 09454

## Denise George
- ```OF``` USVI AG Office
- ```IS``` state prosecutor
- ```FOR``` Gov't
### Notes:
- Attorney General
- USVI
- Filed USVI v. Epstein Estate Jan 2020. 
- Fired Dec 31 2022 by Governor Bryan.

## David Aronberg
- ```OF``` State Attorney Office
- ```IS``` state prosecutor
- ```FOR``` Gov't
### Notes:
- State Attorney
- 15th Judicial Circuit FL

## Bruce Colton
- ```OF``` State Attorney Office
- ```IS``` state prosecutor
- ```FOR``` Gov't
### Notes:
- State Attorney
- 19th Judicial Circuit FL
- DeSantis appointee
- CF 09454
- Reassigned by executive order

## Cy Vance
- ```OF``` Manhattan DA Office
- ```IS``` state prosecutor
- ```FOR``` Gov't
### Notes:
- Manhattan DA

## Kenneth A. Marra
- ```OF``` SDFL
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- CVRA enforcement
- victim civil suits
- 08-80736-CIV-MARRA
- 10-80015-CR-MARRA
- Most-referenced Epstein-case judge. 
- Raw name count 6451 but 228 as full reference.

## Alison J. Nathan
- ```OF``` SDNY
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Maxwell trial
- ruled on victim anonymity
- 20-cr-330

## Richard M. Berman
- ```OF``` SDNY
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Epstein bail hearing
- death aftermath
- 19-cr-490

## Colleen McMahon
- ```OF``` SDNY, Chief
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Ex parte proceedings
- Government obtained Giuffre deposition
- Maxwell defense alleged government misled McMahon

## Loretta Preska
- ```OF``` SDNY
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Giuffre v. Maxwell unsealing
- 15-cv-7433
- Took over after Judge Sweet's death

## Robert W. Sweet
- ```OF``` SDNY
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Original Giuffre v. Maxwell judge
- 15-cv-7433
- Deceased

## Paul Engelmayer
- ```OF``` SDNY
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Grand jury records unsealing

## Linnea R. Johnson
- ```OF``` SDFL, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Marra case referrals
- 08-80736-CIV-MARRA

## Barbara Moses
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Signed Epstein arrest warrant
- July 6 2019
- 19-cr-490
- Also signed first search warrant for 9 East 71st St

## Henry B. Pitman
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Additional NYC residence search
- July 11 2019
- 19-cr-490

## Kevin Nathaniel Fox
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Electronic device search warrants
- July 14 2019
- 19-cr-490

## Ruth Miller
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- USVI search warrant
- 19-cr-490
- Little Saint James search warrant

## Sarah Netburn
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Sealed proceedings
- unsealing rulings

## James L. Cott
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Warrants
- Dennis cyberstalker complaint

## Debra Freeman
- ```OF``` SDNY, magistrate
- ```IS``` federal judge
- ```FOR``` Judge
### Notes:
- Maxwell civil stays
- 20-cr-330

## Deborah Dale Pucillo
- ```OF``` 15th Judicial Circuit, FL
- ```IS``` state judge
- ```FOR``` Judge
### Notes:
- Accepted Epstein FL guilty plea
- CF 09454

## Jeffrey Colbath
- ```OF``` 15th Judicial Circuit, FL
- ```IS``` state judge
- ```FOR``` Judge
### Notes:
- Unsealed NPA / federal deal documents
- CF 09454

## David Crow
- ```OF``` 15th Judicial Circuit, FL
- ```IS``` state judge
- ```FOR``` Judge
### Notes:
- Settlement matters

## Sandra K. McSorley
- ```OF``` 15th Judicial Circuit, FL
- ```IS``` state judge
- ```FOR``` Judge
### Notes:
- Probation / work release orders
- CF 09454

## Bill Berger
- ```OF``` 15th Judicial Circuit, FL, former
- ```IS``` state judge
- ```FOR``` Judge
### Notes:
- Former judge turned victim advocate
- Everybody was in on this deal except the victims and the public

## Luis Delgado
- ```OF``` FL Circuit
- ```IS``` state judge
- ```FOR``` Judge
### Notes:
- Unsealed NPA-era documents
- 2024-2025
- Referenced but no doc count

## Brad Karp
- ```OF``` Paul, Weiss, Rifkind, Wharton & Garrison
- ```IS``` estate trust
- ```FOR``` Perp
### Notes:
- Estate litigation defense
- personal advisor
- Chairman of Paul Weiss. 
- Also retained by Leon Black for fee disputes with Epstein.
- Firm: 2805 docs

## Alan Halperin
- ```OF``` Paul, Weiss, Rifkind, Wharton & Garrison
- ```IS``` estate trust
- ```FOR``` Perp
### Notes:
- Estate / GRAT valuations

## Matthew Menchel
- ```OF``` Kobre & Kim
- ```IS``` estate trust
- ```FOR``` Perp
### Notes:
- International asset recovery / offshore
- Firm: 970 docs

## Deborah Pechet Quinan
- ```OF``` Riemer & Braunstein, RIW
- ```IS``` estate trust
- ```FOR``` Perp
### Notes:
- Trusts & Estates

## Carlyn McCaffrey
- ```OF``` McDermott Will & Emery
- ```IS``` estate trust
- ```FOR``` Perp
### Notes:
- Trusts & Estates

## Robert Josefsberg
- ```OF``` Podhurst Orseck, P.A.
- ```IS``` estate trust
- ```FOR``` Other
### Notes:
- NPA
- 08-80736
- Court-appointed Special Master

## Gary Bloxsome
- ```OF``` Blackfords LLP
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Prince Andrew UK counsel
- EFTA00019885
- Systematic obstruction of SDNY interview requests.
- Firm: 57 docs

## Peter Mandelson
- ```OF``` Global Counsel LLP
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Political consulting / legal advisory
- Former UK First Secretary of State. 
- Firm: 833 docs 
- reference Global Counsel. 
- Nature of legal work for Epstein undetermined.

## Aileen Josephs
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Perp
### Notes:
- Immigration attorney
- USVI immigration matters

## Arda Beskardes
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Perp
### Notes:
- Immigration lawyer
- NY-based

## Marc Nurik
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Defense counsel
- Rothstein
- 50 2009CA040800XXXXMB AG
- Represented Scott Rothstein in Epstein v. Edwards / Rothstein

## Martin O'Connor
- ```OF``` O'Connor, Morss & O'Connor, P.C.
- ```IS``` 3rd Party
- ```FOR``` Perp
### Notes:
- NJ estate / property matters

## Erica Dubno
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Perp
### Notes:
- Appellate counsel

## Thomas Scott
- ```OF``` Cole, Scott & Kissane, P.A.
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Dershowitz defense counsel
- Giuffre v. Dershowitz

## Steven Safra
- ```OF``` Cole, Scott & Kissane, P.A.
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Dershowitz defense counsel
- Giuffre v. Dershowitz

## Benito Romano
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Former US Attorney SDNY

## Lanna Belohlavek
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Gov't
### Notes:
- Assistant State Attorney
- Palm Beach County
- CF 09454

## Jeffrey Sloman
- ```OF``` SDFL USAO
- ```IS``` 3rd Party
- ```FOR``` Gov't
### Notes:
- US Attorney
- SDFL
- successor to Acosta

## Michael Genovese
- ```OF``` NA
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Referenced in legal filings

## Robert Critton
- ```OF``` Burman Critton Luttier & Coleman
- ```IS``` FL Defense
- ```FOR``` Perp
### Notes:
- FL defense counsel in victim civil suits
- Appears on Certificates of Service.
- Firm: 1663 docs

## Michael Pike
- ```OF``` Burman Critton Luttier & Coleman
- ```IS``` FL Defense
- ```FOR``` Perp
### Notes:
- FL defense counsel in victim civil suits
- Appears on Certificates of Service

## Tonja Haddad Coleman
- ```OF``` Tonja Haddad, P.A.
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Appears in defense and victim civil dockets
- Role not fully attributed

## Fred Haddad
- ```OF``` Fred Haddad, P.A.
- ```IS``` 3rd Party
- ```FOR``` Other
### Notes:
- Appears in defense and victim civil dockets
- Role not fully attributed

## Ghislaine Maxwell
- ```OF``` NA
- ```IS``` Co-conspirator
- ```FOR``` Perp
### Notes:
- 20-cr-330
- Convicted Dec 29 2021 - 5 of 6 counts
- sentenced June 28 2022 to 20 years

## Sarah Kellen
- ```OF``` NA
- ```IS``` Co-conspirator
- ```FOR``` Perp
### Notes:
- 08-80736
- EFTA01654937
- EFTA01625916
- Named accomplice in 2008 plea deal
- NPA immunity
- two proffer sessions Nov-Dec 2019

## Nadia Marcinkova
- ```OF``` NA
- ```IS``` Co-conspirator
- ```FOR``` Perp
### Notes:
- 08-80736
- Named in NPA immunity provision

## Lesley Groff
- ```OF``` NA
- ```IS``` Co-conspirator
- ```FOR``` Perp
### Notes:
- 08-80736
- EFTA01656152
- Explicitly named in NPA text

## Adriana Ross
- ```OF``` NA
- ```IS``` Co-conspirator
- ```FOR``` Perp
### Notes:
- 08-80736
- Named in NPA immunity provision

## Alfredo Rodriguez
- ```OF``` NA
- ```IS``` Cooperator
- ```FOR``` Perp
### Notes:
- 10-80015-CR-MARRA
- EFTA00207048
- Household manager. 
- Convicted of obstruction for attempting to sell black book for $50K. 
- Died of cancer while serving sentence.

## Steven Hoffenberg
- ```OF``` NA
- ```IS``` Co-conspirator
- ```FOR``` Other
### Notes:
- 93-B41558
- 18-cv-07580
- EFTA01386750
- EFTA01334040
- Named Epstein as uncharged co-conspirator in TFC fraud. 
- Served 18 years. 
- Died August 2022.

----

----



