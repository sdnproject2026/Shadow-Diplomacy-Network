### Rye-Insti-14-Info-Legal-Actors-table

| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| name | entity_type | firm | role_category | side | specialty | doc_count | doc_count_confidence | cases | key_eftas | notes | report_section |
| Darren Indyke | person | Indyke (solo) | inner_circle | epstein | General counsel, co-executor, trustee of 1953 Trust | 25719 | high |  | EFTA02171955 | Most-mentioned lawyer in corpus by wide margin | 2.1 |
| Richard Kahn | person |  | inner_circle | epstein | Co-executor, trustee, financial administration | 53083 | low |  |  | Most-mentioned individual after Epstein himself. Raw 'Kahn' count inflated 2-5x by financial record collisions | 2.1 |
| Kathryn Ruemmler | person | Latham & Watkins; Goldman Sachs | inner_circle | epstein | Backup executor (removed before death); former White House Counsel (2011-2014) | 9164 | high |  |  | Goldman Sachs GC 2021-2026; announced departure Feb 2026 effective June 30 2026 following EFTA email revelations | 2.1 |
| Erika Kellerhals | person | Solo (USVI tax law) | inner_circle | epstein | USVI immigration/tax | 4809 | high |  |  | Received $23M+ in documented payments | 2.1 |
| Robert Glassman | person |  | inner_circle | epstein | Personal/business counsel | 634 | medium |  |  |  | 2.1 |
| Alan Grubman | person | Grubman Shire | inner_circle | epstein | Entertainment/media lawyer | 205 | high |  |  | Personal relationship | 2.1 |
| Dlugash | person |  | inner_circle | epstein | Estate planning, tax | 1251 | medium |  | EFTA01917842 | Full name varies in corpus; settlement agreement from 2000 | 2.1 |
| Alan Dershowitz | person | Kirkland & Ellis; later solo | npa_defense | epstein | Criminal appellate, constitutional law | 2212 | high | 08-80736;08-80736-CIV-MARRA | EFTA00009116 | Harvard Law professor. Threatened Acosta re prosecutorial overreach. Later named as abuser by Giuffre; denied allegations. | 2.2 |
| Kenneth Starr | person | Kirkland & Ellis | npa_defense | epstein | Former Solicitor General, former independent counsel (Whitewater) | 1395 | high | 08-80736 | EFTA01659896 | Argued against federal prosecution in letters to SDFL. Died September 2022. | 2.2 |
| Jay Lefkowitz | person | Kirkland & Ellis | npa_defense | epstein | Former deputy assistant to the President | 1652 | high | 08-80736;08-80736-CIV-MARRA | EFTA00013811 | Negotiated NPA drafts with AUSA Villafana. Argued insufficient evidence Epstein targeted minors. | 2.2 |
| Gerald Lefcourt | person | Lefcourt (solo) | npa_defense | epstein | Criminal defense | 670 | high | 08-80736 |  | NY criminal defense attorney | 2.2 |
| Jack Goldberger | person | Atterbury Goldberger Weiss, P.A. | npa_defense | epstein | FL criminal defense | 4560 | high | 08-80736;CF 09454;08-80736-CIV-MARRA | EFTA01659770 | Primary FL defense counsel. Firm: 1877 docs. | 2.2 |
| Roy Black | person | Black Srebnick Kornspan & Stumpf, P.A. | npa_defense | epstein | FL criminal defense | 1546 | high | 08-80736;08-80736-CIV-MARRA |  | Miami's best criminal defense lawyer. Firm: 994 docs. Listed on CVRA Certificates of Service as Criminal Defense Counsel. | 2.2 |
| Lilly Ann Sanchez | person | Fowler White Burnett, P.A. | npa_defense | epstein | FL defense | 1006 | high | 08-80736;CF 09454 | EFTA02171955 | Managed privilege logs per email reminders | 2.2 |
| Guy Lewis | person | Lewis Tein, P.L. | npa_defense | epstein | Former USAO chief (SDFL) | 169 | high | 08-80736 | EFTA00009116 | Acosta: prosecutors that formerly worked in the U.S. Attorney's Office | 2.2 |
| Joseph Ackerman | person | Fowler White Burnett, P.A. | npa_defense | epstein | FL defense | 1107 | high | 08-80736;CF 09454;50 2009CA040800XXXXMB AG | EFTA00592983 | Signed Certificates of Service in victim civil suits. Firm total: 2116 docs. | 2.2 |
| Reid Weingarten | person | Steptoe & Johnson | sdny_defense | epstein | Criminal defense | 2393 | high | 19-cr-490 |  | Lead criminal defense counsel, SDNY 2019. Steptoe & Johnson: 802 docs. | 1.1 |
| Martin Weinberg | person | Weinberg P.C. (solo) | npa_defense | epstein | Criminal defense | 1933 | high | 08-80736;08-80736-CIV-MARRA;19-cr-490 |  | Served on both NPA-era and SDNY 2019 defense teams | 2.2 |
| Marc Fernich | person |  | sdny_defense | epstein | Criminal defense | 91 | high | 19-cr-490 |  | SDNY 2019 co-counsel | 1.1 |
| Bruce Barket | person | Barket Epstein Kearon | sdny_defense | epstein | Criminal defense | 162 | high | 19-cr-490 |  | SDNY 2019 co-counsel | 1.1 |
| Joseph Nascimento | person | Ross Amsel Raben | sdny_defense | epstein | Criminal defense | 95 | high | 19-cr-490 |  | SDNY 2019 co-counsel | 1.1 |
| Laura Menninger | person | Haddon Morgan Foreman | maxwell_defense | epstein | Lead trial counsel | 1156 | high | 20-cr-330;15-cv-7433 |  | Firm total: 1447 docs | 2.3 |
| Jeffrey Pagliuca | person | Haddon Morgan Foreman | maxwell_defense | epstein | Co-counsel | 1098 | high | 20-cr-330;15-cv-7433 |  |  | 2.3 |
| Christian Everdell | person | Cohen & Gresser | maxwell_defense | epstein | Co-counsel | 1058 | high | 20-cr-330 |  | Firm total: 1495 docs | 2.3 |
| Mark Cohen | person | Cohen & Gresser | maxwell_defense | epstein | Lead counsel (pre-trial) | 166 | low | 20-cr-330 |  | Extremely common name; firm count (1495) more reliable | 2.3 |
| Bobby Sternheim | person | Sternheim & Sternheim | maxwell_defense | epstein | Co-counsel | 804 | high | 20-cr-330 |  |  | 2.3 |
| David Bruck | person |  | maxwell_defense | epstein | Sentencing specialist | 210 | high | 20-cr-330 |  |  | 2.3 |
| Brad Edwards | person | Edwards & Pottinger (later Edwards Henderson) | victim_attorney | victim | Lead victim attorney, CVRA pioneer | 3317 | high | 08-80736-CIV-MARRA;50 2009CA040800XXXXMB AG |  | Counter-sued by Epstein (§1.6). Firm: 555 docs. | 2.4 |
| Paul Cassell | person | University of Utah (pro bono) | victim_attorney | victim | CVRA specialist, constitutional law scholar | 2895 | high | 08-80736-CIV-MARRA |  | Filed original CVRA challenge to NPA | 2.4 |
| Jack Scarola | person | Searcy Denney Scarola Barnhart & Shipley | victim_attorney | victim | Victim civil suits | 1972 | high |  | EFTA01480957 | Told Judge Crow all lawsuits settled for very substantial sums. Firm: 1817 docs. | 2.4 |
| Sigrid McCawley | person | Boies Schiller Flexner | victim_attorney | victim | Giuffre v. Maxwell lead counsel | 736 | high | 15-cv-7433 |  | Lead counsel for Virginia Giuffre in defamation suit | 2.4 |
| David Boies | person | Boies Schiller Flexner | victim_attorney | victim | Giuffre v. Maxwell | 370 | high | 15-cv-7433 |  | Chairman of BSF. Embroiled in Patrick Kessler affair (2019); reported contact to FBI; no criminal charges. Firm: 1423 docs. | 2.4 |
| Stan Pottinger | person | Edwards & Pottinger | victim_attorney | victim | Victim attorney | 633 | high |  |  | Also involved in Kessler affair. Kessler was a fraud. No criminal charges filed. Pottinger later died (age 84). | 2.4 |
| Gloria Allred | person | Allred Maroko & Goldberg | victim_attorney | victim | Victim representation | 285 | high |  |  |  | 2.4 |
| Jeanne Christensen | person | Wigdor LLP | victim_attorney | victim | Leon Black victims | 41 | high |  | EFTA02731473 | Emailed SDNY: outrageous that criminal charges have not been brought against [Black]. Firm: 84 docs. | 2.4 |
| Spencer Kuvin | person | Leopold Kuvin (formerly Ricci Leopold) | victim_attorney | victim | FL victim civil suits | 565 | high |  |  |  | 2.4 |
| Theodore Leopold | person | Ricci Leopold, P.A. (now Leopold Kuvin) | victim_attorney | victim | Victim representation | 533 | high |  |  |  | 2.4 |
| Stuart Mermelstein | person | Mermelstein & Horowitz, P.A. | victim_attorney | victim | Victim representation | 670 | high |  |  | Firm: 362 docs | 2.4 |
| Adam Horowitz | person | Mermelstein & Horowitz, P.A. | victim_attorney | victim | Victim representation | 529 | high |  |  |  | 2.4 |
| Jeffrey Herman | person | Herman Law | victim_attorney | victim | Victim representation | 226 | high |  |  |  | 2.4 |
| Jay Howell | person | Jay Howell & Associates | victim_attorney | victim | Victim representation | 282 | high |  |  |  | 2.4 |
| Kara Rockenbach | person | Link & Rockenbach / Burlington & Rockenbach | victim_attorney | victim | Appellate counsel | 457 | high |  |  |  | 2.4 |
| Scott Link | person | Link & Rockenbach | fl_defense | epstein | Appellate counsel | 474 | high |  |  | Listed in §2.4 but role is Epstein defense (appellate) | 2.4 |
| Brittany Henderson | person | Edwards Pottinger LLC | victim_attorney | victim | Victim representation | 246 | high |  |  |  | 2.4 |
| David Vitale | person | Searcy Denney Scarola | victim_attorney | victim | Victim representation | 212 | high |  |  |  | 2.4 |
| Gary Farmer Jr. | person | Farmer Jaffe Weissing Edwards Fistos & Lehrman | victim_attorney | victim | Edwards defense counsel (Epstein v. Edwards) | 250 | high | 50 2009CA040800XXXXMB AG |  | Defended Brad Edwards when Epstein counter-sued | 2.4 |
| Kevin Boyle | person | Panish Shea & Boyle | victim_attorney | victim | Maxwell victim representation | 19 | high |  |  |  | 2.4 |
| Motley Rice LLC | firm | Motley Rice LLC | victim_attorney | victim | USVI victim claims | 19 | high |  |  | Firm entry — no individual attributed | 2.4 |
| Geoffrey S. Berman | person | SDNY USAO | sdny_prosecutor | government | U.S. Attorney, SDNY (2018-2020) | 461 | high | 19-cr-490 |  |  | 2.5 |
| Audrey Strauss | person | SDNY USAO | sdny_prosecutor | government | Acting U.S. Attorney (2020-2021) | 756 | high | 20-cr-330 |  |  | 2.5 |
| Maurene Comey | person | SDNY USAO | sdny_prosecutor | government | AUSA, lead trial prosecutor | 394 | high | 19-cr-490;20-cr-330 |  |  | 2.5 |
| Alison Moe | person | SDNY USAO | sdny_prosecutor | government | AUSA, co-prosecutor | 423 | high | 19-cr-490;20-cr-330 |  |  | 2.5 |
| Alexander Rossmiller | person | SDNY USAO | sdny_prosecutor | government | AUSA, co-prosecutor | 173 | high | 19-cr-490;20-cr-330 |  |  | 2.5 |
| Nicolas Roos | person | SDNY USAO | sdny_prosecutor | government | AUSA, BOP interviews | 46 | high | 20-cr-330 |  |  | 2.5 |
| Rebekah Donaleski | person | SDNY USAO | sdny_prosecutor | government | AUSA, MCC interviews | 31 | high | 20-cr-330 |  |  | 2.5 |
| Damian Williams | person | SDNY USAO | sdny_prosecutor | government | U.S. Attorney (2021-2025) | 310 | high | 20-cr-330 |  |  | 2.5 |
| Jason Swergold | person | SDNY USAO | sdny_prosecutor | government | AUSA, MCC conditions/FOIA | 13 | high |  |  |  | 2.5 |
| Lara Pomerantz | person | SDNY USAO | sdny_prosecutor | government | AUSA | 315 | high |  |  |  | 2.5 |
| Andrew Rohrbach | person | SDNY USAO | sdny_prosecutor | government | AUSA | 327 | high |  |  |  | 2.5 |
| R. Alexander Acosta | person | SDFL USAO | sdfl_prosecutor | government | U.S. Attorney, SDFL | 2290 | high | 08-80736 | EFTA00009116 | Resigned as Secretary of Labor July 2019 over NPA controversy | 2.5 |
| A. Marie Villafana | person | SDFL USAO | sdfl_prosecutor | government | AUSA, lead investigator | 826 | high | 08-80736 |  | Name frequently OCR-garbled as Villafalia or Villafaila | 2.5 |
| Andrew Lourie | person | SDFL USAO | sdfl_prosecutor | government | AUSA | 51 | high | 08-80736 |  |  | 2.5 |
| Dexter Lee | person | SDFL USAO | sdfl_prosecutor | government | AUSA | 376 | high | 08-80736;08-80736-CIV-MARRA |  |  | 2.5 |
| Bruce Reinhart | person | SDFL USAO; later solo; later SDFL Magistrate | sdfl_prosecutor | government | AUSA (1996-2008), then private attorney, then Magistrate Judge | 323 | high | 08-80736 | EFTA01657803 | Resigned USAO Jan 1 2008; retained by Epstein next day to represent Kellen/co-conspirators. Appointed Magistrate March 2018. OPR investigated. | 2.5 |
| Barry Krischer | person | State Attorney Office, Palm Beach County | state_prosecutor | government | State Attorney, Palm Beach County | 368 | high | CF 09454 |  |  | 2.5 |
| Denise George | person | USVI AG Office | state_prosecutor | government | Attorney General, USVI | 47 | high |  |  | Filed USVI v. Epstein Estate Jan 2020. Fired Dec 31 2022 by Governor Bryan. | 2.5 |
| David Aronberg | person | State Attorney Office, 15th Judicial Circuit FL | state_prosecutor | government | State Attorney, 15th Judicial Circuit FL | 7 | high |  |  |  | 2.5 |
| Bruce Colton | person | State Attorney Office, 19th Judicial Circuit FL | state_prosecutor | government | State Attorney, 19th Judicial Circuit FL (DeSantis appointee) | 4 | high | CF 09454 |  | Reassigned by executive order | 2.5 |
| Cy Vance | person | Manhattan DA Office | state_prosecutor | government | Manhattan DA | 83 | high |  |  |  | 2.5 |
| Kenneth A. Marra | person | SDFL | federal_judge | judicial | CVRA enforcement, victim civil suits | 228 | medium | 08-80736-CIV-MARRA;10-80015-CR-MARRA |  | Most-referenced Epstein-case judge. Raw name count 6451 but 228 as full reference. | 2.6 |
| Alison J. Nathan | person | SDNY | federal_judge | judicial | Maxwell trial; ruled on victim anonymity | 1265 | high | 20-cr-330 |  |  | 2.6 |
| Richard M. Berman | person | SDNY | federal_judge | judicial | Epstein bail hearing, death aftermath | 264 | high | 19-cr-490 |  |  | 2.6 |
| Colleen McMahon | person | SDNY (Chief) | federal_judge | judicial | Ex parte proceedings | 71 | high |  |  | Government obtained Giuffre deposition; Maxwell defense alleged government misled McMahon | 2.6 |
| Loretta Preska | person | SDNY | federal_judge | judicial | Giuffre v. Maxwell unsealing | 135 | high | 15-cv-7433 |  | Took over after Judge Sweet's death | 2.6 |
| Robert W. Sweet | person | SDNY | federal_judge | judicial | Original Giuffre v. Maxwell judge | 17 | high | 15-cv-7433 |  | Deceased | 2.6 |
| Paul Engelmayer | person | SDNY | federal_judge | judicial | Grand jury records unsealing | 4 | high |  |  |  | 2.6 |
| Linnea R. Johnson | person | SDFL | magistrate | judicial | Marra case referrals | 119 | high | 08-80736-CIV-MARRA |  |  | 2.6 |
| Barbara Moses | person | SDNY | magistrate | judicial | Signed Epstein arrest warrant (July 6 2019) | 95 | high | 19-cr-490 |  | Also signed first search warrant for 9 East 71st St | 2.6 |
| Henry B. Pitman | person | SDNY | magistrate | judicial | Additional NYC residence search (July 11 2019) | 59 | high | 19-cr-490 |  |  | 2.6 |
| Kevin Nathaniel Fox | person | SDNY | magistrate | judicial | Electronic device search warrants (July 14 2019) | 19 | high | 19-cr-490 |  |  | 2.6 |
| Ruth Miller | person | SDNY | magistrate | judicial | USVI search warrant | 27 | high | 19-cr-490 |  | Little Saint James search warrant | 2.6 |
| Sarah Netburn | person | SDNY | magistrate | judicial | Sealed proceedings, unsealing rulings | 29 | high |  |  |  | 2.6 |
| James L. Cott | person | SDNY | magistrate | judicial | Warrants | 8 | high |  |  | Dennis cyberstalker complaint | 2.6 |
| Debra Freeman | person | SDNY | magistrate | judicial | Maxwell civil stays | 18 | high | 20-cr-330 |  |  | 2.6 |
| Deborah Dale Pucillo | person | 15th Judicial Circuit, FL | state_judge | judicial | Accepted Epstein FL guilty plea | 178 | high | CF 09454 |  |  | 2.6 |
| Jeffrey Colbath | person | 15th Judicial Circuit, FL | state_judge | judicial | Unsealed NPA/federal deal documents | 64 | high | CF 09454 |  |  | 2.6 |
| David Crow | person | 15th Judicial Circuit, FL | state_judge | judicial | Settlement matters | 65 | high |  |  |  | 2.6 |
| Sandra K. McSorley | person | 15th Judicial Circuit, FL | state_judge | judicial | Probation/work release orders | 36 | high | CF 09454 |  |  | 2.6 |
| Bill Berger | person | 15th Judicial Circuit, FL (former) | state_judge | judicial | Former judge turned victim advocate | 42 | high |  |  | Everybody was in on this deal except the victims and the public | 2.6 |
| Luis Delgado | person | FL Circuit | state_judge | judicial | Unsealed NPA-era documents (2024-2025) | 0 | high |  |  | Referenced but no doc count | 2.6 |
| Brad Karp | person | Paul, Weiss, Rifkind, Wharton & Garrison | estate_trust | epstein | Estate litigation defense, personal advisor | 1898 | high |  |  | Chairman of Paul Weiss. Also retained by Leon Black for fee disputes with Epstein. Firm: 2805 docs. | 2.7 |
| Alan Halperin | person | Paul, Weiss, Rifkind, Wharton & Garrison | estate_trust | epstein | Estate/GRAT valuations | 2039 | high |  |  |  | 2.7 |
| Matthew Menchel | person | Kobre & Kim | estate_trust | epstein | International asset recovery/offshore | 937 | high |  |  | Firm: 970 docs | 2.7 |
| Deborah Pechet Quinan | person | Riemer & Braunstein (RIW) | estate_trust | epstein | Trusts & Estates | 558 | high |  |  |  | 2.7 |
| Carlyn McCaffrey | person | McDermott Will & Emery | estate_trust | epstein | Trusts & Estates | 533 | high |  |  |  | 2.7 |
| Robert Josefsberg | person | Podhurst Orseck, P.A. | estate_trust | third_party | Special Master (NPA) | 1004 | high | 08-80736 |  | Court-appointed Special Master | 2.7 |
| Weil Gotshal & Manges | firm | Weil Gotshal & Manges | estate_trust | epstein | Estate-related | 78 | high |  |  | Firm entry — no individual attributed | 2.7 |
| Cooley LLP | firm | Cooley LLP | estate_trust | epstein | Estate-related | 115 | high |  |  | Firm entry — no individual attributed | 2.7 |
| Gary Bloxsome | person | Blackfords LLP | third_party | third_party | Prince Andrew UK counsel | 45 | high |  | EFTA00019885 | Systematic obstruction of SDNY interview requests. Firm: 57 docs. | 2.8 |
| Peter Mandelson | person | Global Counsel LLP | third_party | third_party | Political consulting/legal advisory | 5530 | medium |  |  | Former UK First Secretary of State. 833 docs reference Global Counsel. Nature of legal work for Epstein undetermined. | 2.8 |
| Aileen Josephs | person |  | third_party | epstein | Immigration attorney | 18 | high |  |  | USVI immigration matters | 2.8 |
| Arda Beskardes | person |  | third_party | epstein | Immigration lawyer (NY-based) | 738 | high |  |  |  | 2.8 |
| Marc Nurik | person |  | third_party | third_party | Defense counsel (Rothstein) | 928 | high | 50 2009CA040800XXXXMB AG |  | Represented Scott Rothstein in Epstein v. Edwards/Rothstein | 2.8 |
| Martin O'Connor | person | O'Connor, Morss & O'Connor, P.C. | third_party | epstein | NJ estate/property matters | 311 | high |  |  |  | 2.8 |
| Erica Dubno | person |  | third_party | epstein | Appellate counsel | 505 | high |  |  |  | 2.8 |
| Thomas Scott | person | Cole, Scott & Kissane, P.A. | third_party | third_party | Dershowitz defense counsel (Giuffre v. Dershowitz) | 127 | high |  |  |  | 2.8 |
| Steven Safra | person | Cole, Scott & Kissane, P.A. | third_party | third_party | Dershowitz defense counsel (Giuffre v. Dershowitz) | 75 | high |  |  |  | 2.8 |
| Benito Romano | person |  | third_party | third_party | Former U.S. Attorney SDNY | 253 | high |  |  |  | 2.8 |
| Lanna Belohlavek | person |  | third_party | government | Assistant State Attorney, Palm Beach County | 340 | high | CF 09454 |  |  | 2.8 |
| Jeffrey Sloman | person | SDFL USAO | third_party | government | U.S. Attorney, SDFL (successor to Acosta) | 134 | high |  |  |  | 2.8 |
| Michael Genovese | person |  | third_party | third_party | Referenced in legal filings | 53 | medium |  |  |  | 2.8 |
| Sullivan & Cromwell | firm | Sullivan & Cromwell | third_party | unknown | Role undetermined — likely financial institution counsel | 425 | high |  |  | Firm entry — no individual attributed | 2.8 |
| Akin Gump | firm | Akin Gump | third_party | unknown | Role undetermined | 433 | high |  |  | Firm entry — no individual attributed | 2.8 |
| Skadden Arps | firm | Skadden Arps | third_party | unknown | Role undetermined | 194 | high |  |  | Firm entry — no individual attributed | 2.8 |
| Davis Polk | firm | Davis Polk | third_party | unknown | Role undetermined | 172 | high |  |  | Firm entry — no individual attributed | 2.8 |
| Dechert LLP | firm | Dechert LLP | third_party | third_party | Apollo independent report | 77 | high |  |  | Firm entry — no individual attributed | 2.8 |
| Robert Critton | person | Burman Critton Luttier & Coleman | fl_defense | epstein | FL defense counsel in victim civil suits | 2037 | high |  |  | Appears on Certificates of Service. Firm: 1663 docs. | 2.9 |
| Michael Pike | person | Burman Critton Luttier & Coleman | fl_defense | epstein | FL defense counsel in victim civil suits | 991 | high |  |  | Appears on Certificates of Service | 2.9 |
| Burman Critton Luttier & Coleman | firm | Burman Critton Luttier & Coleman | fl_defense | epstein | FL defense in victim civil suits | 1663 | high |  |  | Robert Critton (2037 docs) and Michael Pike (991 docs) identified as attorneys | 2.9 |
| Rothstein Rosenfeldt Adler | firm | Rothstein Rosenfeldt Adler | third_party | third_party | Ponzi scheme firm (disbarred) | 1665 | high | 50 2009CA040800XXXXMB AG |  | Scott Rothstein pleaded guilty to Ponzi scheme (2010), sentenced 50 years. Brad Edwards was initially at this firm. | 2.9 |
| Tonja Haddad Coleman | person | Tonja Haddad, P.A. | third_party | unknown | Appears in defense and victim civil dockets | 1184 | medium |  |  | Role not fully attributed | 2.9 |
| Fred Haddad | person | Fred Haddad, P.A. | third_party | unknown | Appears in defense and victim civil dockets | 1599 | medium |  |  | Role not fully attributed | 2.9 |
| Ghislaine Maxwell | person |  | co_conspirator | epstein |  | 0 | high | 20-cr-330 |  | Convicted Dec 29 2021 (5 of 6 counts); sentenced June 28 2022 to 20 years | 2.10 |
| Sarah Kellen | person |  | co_conspirator | epstein |  | 0 | high | 08-80736 | EFTA01654937;EFTA01625916 | Named accomplice in 2008 plea deal; NPA immunity; two proffer sessions Nov-Dec 2019 | 2.10 |
| Nadia Marcinkova | person |  | co_conspirator | epstein |  | 0 | high | 08-80736 |  | Named in NPA immunity provision | 2.10 |
| Lesley Groff | person |  | co_conspirator | epstein |  | 0 | high | 08-80736 | EFTA01656152 | Explicitly named in NPA text | 2.10 |
| Adriana Ross | person |  | co_conspirator | epstein |  | 0 | high | 08-80736 |  | Named in NPA immunity provision | 2.10 |
| Alfredo Rodriguez | person |  | cooperator | epstein |  | 0 | high | 10-80015-CR-MARRA | EFTA00207048 | Household manager. Convicted of obstruction for attempting to sell black book for $50K. Died of cancer while serving sentence. | 2.10 |
| Steven Hoffenberg | person |  | co_conspirator | third_party |  | 0 | high | 93-B41558;18-cv-07580 | EFTA01386750;EFTA01334040 | Named Epstein as uncharged co-conspirator in TFC fraud. Served 18 years. Died August 2022. | 2.10 |

----

----
