# epsteinexposed-mcp

[![CI](https://github.com/releasetheepsteinfiles/epsteinexposed-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/releasetheepsteinfiles/epsteinexposed-mcp/actions/workflows/ci.yml)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/37b6e2a72472442aa30e5ada23533598)](https://app.codacy.com/gh/releasetheepsteinfiles/epsteinexposed-mcp?utm_source=github.com&utm_medium=referral&utm_content=releasetheepsteinfiles/epsteinexposed-mcp&utm_campaign=Badge_Grade)
[![codecov](https://codecov.io/gh/releasetheepsteinfiles/epsteinexposed-mcp/graph/badge.svg)](https://codecov.io/gh/releasetheepsteinfiles/epsteinexposed-mcp)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![MCP](https://img.shields.io/badge/protocol-MCP-purple)](https://modelcontextprotocol.io/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

**Model Context Protocol server exposing the [Epstein Exposed](https://epsteinexposed.com) public API as AI-agent tool calls.**

Plug directly into any MCP-compatible client (Claude Desktop, Cursor, SmolAgents, etc.) to search persons, documents, flight logs, and emails from the Epstein case files.

[![epsteinexposed-mcp](https://raw.githubusercontent.com/releasetheepsteinfiles/epsteinexposed-mcp/main/promo/mcp-poster.png)](https://raw.githubusercontent.com/releasetheepsteinfiles/epsteinexposed-mcp/main/promo/mcp-16x9.mp4)

> **Disclaimer:** Inclusion in the Epstein Exposed database does not imply guilt or wrongdoing. All data is derived from publicly released government records.

## Tools

| Tool | Description |
|---|---|
| `search_persons` | Search/filter persons of interest by name and category |
| `get_person` | Get full detail for a person by slug (bio, aliases, stats) |
| `search_documents` | FTS5 full-text search across case documents |
| `search_flights` | Search flight logs by passenger, year, origin, destination |
| `cross_search` | Search across documents and emails simultaneously |

## Quick Start

```bash
# Install
pip install -e ".[dev]"

# Run via stdio (for MCP clients)
python -m src.server

# Or via the MCP CLI
mcp run src/server.py
```

## MCP Client Configuration

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "epstein-files": {
      "command": "epsteinexposed-mcp",
      "args": []
    }
  }
}
```

### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "epstein-files": {
      "command": "epsteinexposed-mcp",
      "args": []
    }
  }
}
```

## Architecture

```
MCP Client (Claude, Cursor, SmolAgents)
    │
    │  JSON-RPC 2.0 (stdio / SSE)
    ▼
epsteinexposed-mcp (FastMCP)
    │
    │  AsyncEpsteinExposed (curl_cffi)
    ▼
epsteinexposed.com/api/v1
```

Powered by the [`epsteinexposed`](https://github.com/releasetheepsteinfiles/epsteinexposed) Python package.

## Development

```bash
git clone https://github.com/releasetheepsteinfiles/epsteinexposed-mcp.git
cd epsteinexposed-mcp
pip install -e ".[dev]"
pytest -v
```

## Documentation

Full docs available at the [docs site](https://releasetheepsteinfiles.github.io/epsteinexposed-mcp) (VitePress).

## The toolchain

This repository is one of four that share a data source and a design system:

| Repo | Role |
|---|---|
| [`epsteinexposed`](https://github.com/releasetheepsteinfiles/epsteinexposed) | Python client for the public API |
| [`epsteinexposed-mcp`](https://github.com/releasetheepsteinfiles/epsteinexposed-mcp) | MCP server — structured search *(this repo)* |
| [`epstein-files-rag-mcp`](https://github.com/releasetheepsteinfiles/epstein-files-rag-mcp) | MCP server — semantic search *(in development)* |
| [`epsteinexplorer`](https://github.com/releasetheepsteinfiles/epsteinexplorer) | Natural-language chat app |

A 20-second overview of how the four fit together:

[![Epstein Files toolchain](https://raw.githubusercontent.com/releasetheepsteinfiles/epsteinexposed-mcp/main/promo/suite-poster.png)](https://raw.githubusercontent.com/releasetheepsteinfiles/epsteinexposed-mcp/main/promo/suite-16x9.mp4)

## Design system

All four repositories share the **"Declassified"** visual language — a dark
archival palette with a single ember accent, monospace structure and Inter
prose. The canonical tokens live in [`brand/tokens.css`](brand/tokens.css)
and the rationale in [`brand/DESIGN.md`](brand/DESIGN.md); both files are
byte-identical across the four repos.

The VitePress theme maps `--vp-*` onto that palette in
`docs/.vitepress/theme/custom.css`.

## License

MIT
