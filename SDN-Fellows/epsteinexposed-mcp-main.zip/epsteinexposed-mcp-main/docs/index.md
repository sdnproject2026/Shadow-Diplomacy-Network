---
layout: home

hero:
  name: "epsteinexposed-mcp"
  text: "The Epstein Files, at your fingertips."
  tagline: An MCP server that exposes the Epstein Exposed public API as tool calls for AI agents.
  actions:
    - theme: brand
      text: Get Started
      link: /guide/getting-started
    - theme: alt
      text: Tools API
      link: /api/tools
    - theme: alt
      text: GitHub
      link: https://github.com/releasetheepsteinfiles/epsteinexposed-mcp

# File-numbered markers instead of emoji: the palette carries one
# accent and emoji drag in arbitrary colour. See brand/DESIGN.md.
features:
  - icon: "01"
    title: Search Persons
    details: Query the Epstein files by name — full or partial matches across all released documents.
  - icon: "02"
    title: Browse Documents
    details: List and retrieve documents by ID or category — flight logs, depositions, and more.
  - icon: "03"
    title: MCP Native
    details: Built on the Model Context Protocol — plug directly into any MCP-compatible AI agent.
  - icon: "04"
    title: Async & Fast
    details: Powered by curl_cffi and FastMCP — non-blocking I/O with clean tool interfaces.
---
