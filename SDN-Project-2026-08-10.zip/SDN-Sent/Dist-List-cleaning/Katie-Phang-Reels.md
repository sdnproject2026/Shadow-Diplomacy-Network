# Katie Phang

Professional Information & Transcript Sources

## Official Contact Information

- General Inquiry Email:

  info@katiephang.com

- Direct Professional Email:

  katie@katiephang.com

- Official Firm:

  Katie Phang Trial Attorneys & Media Consultants

- Office Phone:

  (305) 614-1223

- Corporate Mailing Address:

  2 S Biscayne Blvd, Suite 1600 

  Miami, FL 33131-1824

# Florida Bar

Katie Phang is an active Florida attorney. 

Attorney registration and disciplinary information can be verified through The Florida Bar:

- Florida Bar Profile:

  https://www.floridabar.org/about/cert/profile/?num=348650

- Florida Bar Number:

  348650

# Media & Video Sources

## Website

- https://katiephang.com/

## Substack

- https://katiephang.substack.com/

## Instagram

- https://www.instagram.com/katiephang/

## YouTube Search / Video Source

- https://www.youtube.com/results?search_query=Katie+Phang

# Video Transcript Availability

## Current Status

No official public archive was located containing:

- Complete transcripts of Katie Phang Instagram Reels

- A downloadable transcript database

- Raw transcript URLs for all published videos

- An official transcript repository

# Transcript Sources

## YouTube Captions / Transcripts

For videos uploaded with captions, transcripts may be available through YouTube's transcript feature:

- https://support.google.com/youtube/answer/15930243

# Workflow

1. Collect public video URLs:

   - Instagram Reels:

     https://www.instagram.com/katiephang/

   - YouTube videos:

     https://www.youtube.com/results?search_query=Katie+Phang

2. Extract available captions/transcripts.

3. Store transcripts with metadata:

   - Video title

   - Publication date

   - Platform

   - Original URL

   - Transcript text

# Source URLs

- https://katiephang.com/contact/

- https://katiephang.substack.com/about

- https://www.floridabar.org/about/cert/profile/?num=348650

- https://www.instagram.com/katiephang/

- https://www.youtube.com/results?search_query=Katie+Phang

- https://support.google.com/youtube/answer/15930243