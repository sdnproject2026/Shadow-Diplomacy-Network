# Katie Phang

- https://katiephang.com/contact/

- https://katiephang.substack.com/about
 
- General Inquiry Email
    - info@katiephang.com

- Direct Professional Email: 
    - katie@katiephang.com

- Official Firm Website: 
    - Katie Phang Trial Attorneys & Media Consultants

- Office Phone Number: 
    - (305) 614-1223

- Physical Corporate Mailing Address:

    - 2 S Biscayne Blvd, Suite 1600

    - Miami, FL 33131-1824

Her status as an active, practicing attorney in Florida means her information is heavily regulated and maintained for public consumer protection. 

You can always cross-reference or pull her up-to-date credentialing profile using the public

## Sources

- https://www.floridabar.org/about/cert/profile/?num=348650

- bar number 348650

- https://www.floridabar.org/about/cert/profile/?num=348650

- https://katiephang.com/contact/

- https://katiephang.substack.com/about

