# Victim - Reporter F

## Title

Jeffrey Epstein case: the billionaire is alleged to have continued assaulting women while serving a modified prison sentence

## Raw URL

https://www.sudouest.fr/faits-divers/affaire-epstein/affaire-jeffrey-epstein-le-milliardaire-aurait-continue-a-violer-des-femmes-pendant-qu-il-purgeait-une-peine-de-prison-amenagee-29048302.php

## Author

SudOuest.fr

## Date 

13/05/2026 à 16h56

## Text

Five women reported the abuse they suffered during a parliamentary hearing in the United States, while calling for legislative reform regarding statutes of limitations for sexual violence.

New testimonies have emerged in the sprawling Jeffrey Epstein case. Five women, along with the family of a sixth victim who died in 2025, testified Tuesday in the United States before Democratic members of the parliamentary commission investigating the case and its ramifications


-----

- sudouest-publicite@sudouest.fr 
    - Advertising / commercial

- investigacao@sabado.pt 
    - Investigation / editorial

- catarina@sabado.pt 
    - Catarina (editorial contact)

-----

