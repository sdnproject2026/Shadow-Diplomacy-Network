# Victim - Reporter C

## Title

Vítima de Epstein desaba a chorar ao recordar abusos sexuais

## Author 

Sónia Dias

- https://www.cmjornal.pt/vidas/detalhe/vitima-de-epstein-desabata-a-chorar-ao-recordar-abusos-sexuais

## Date

13 de maio de 2026 às 11:03

## Text

Democrats on the U.S. House Oversight Committee and members of the Florida government are holding a series of public hearings in Palm Beach County as part of an investigation into Jeffrey Epstein’s crimes and how the Department of Justice released the related files.

The hearings are chaired by Congressman Robert Garcia. Early this month, the committee’s Republican chair, Congressman James Comer, accused Democrats of manipulating the proceedings.

This Tuesday, disturbing images surfaced showing Roza, an Epstein survivor, breaking down in tears during her testimony. She recalled sexual abuse and said Epstein bragged about having sex with girls while he was imprisoned.

Roza said Epstein’s former associate, Jean-Luc Brunel, introduced her to Epstein. Brunel—a French modeling agent who founded MC2 Model Management with Epstein’s support—was later found hanged in a Paris prison while awaiting trial for rape.

She said Brunel brought her from Uzbekistan to the U.S. in 2008, when she was 18. In 2009, she was taken to Epstein’s Palm Beach mansion, during the period when he was under house arrest for soliciting a minor for prostitution.

Roza said Epstein used the names of powerful politicians to demonstrate influence. She added that he presented himself as an investor in the same agency that promised her a career, and he spoke about his imprisonment as if it were a joke—boasting about visits from girls and his ties to authorities.

She said Epstein later offered her a job at his scientific foundation to help her repay a $10,000 debt she owed to the modeling agency. “One day, his masseuse called me into the room, where I was raped for the first time by Jeffrey,” she said.

Roza added that the modeling agency moved her to Miami while Epstein was under house arrest so she could stay near Palm Beach. She said she was only allowed to return to New York after he completed his sentence.

She said it took years for her to report the abuse, and she kept her identity secret. Her name became public only after the disastrous release of Epstein’s files, where the perpetrators’ names were carefully omitted but the victims’ names were exposed.

----

- geral@cmjornal.pt 
    - General editorial / news desk

- portal@cmjornal.pt 
    - Multiplatform / online portal

- geral@cmjornal.pt 
    - Tips / suggestions
  
----
