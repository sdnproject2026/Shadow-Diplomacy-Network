# Victim - Reporter J

## Title

Epstein abuse victim speaks out for the first time: “The masseur called me into his room and I was raped”

## Raw URL

https://www.record.pt/fora-de-campo/detalhe/vitima-de-epstein-fala-pela-primeira-vez-a-massagista-chamou-me-para-o-quarto-dele-e-fui-violada

## Author

Sábado

## Text

Roza, a survivor of Jeffrey Epstein’s abuse, said she is speaking out for the first time to describe how the late sexual offender allegedly abused her while he was under house arrest for abusing a minor.

She told the House Oversight Committee how she met Jean‑Luc Brunel in 2008, when she was only 18. Brunel had recruited her from Uzbekistan as a teenager and promised her “a modeling career beyond anything imaginable.” She said that, coming from a family with financial difficulties, she was the “perfect target” for coercion.

According to the account, Roza later described that the masseur called her into his room, where she was raped.

-----

  - investigacao@sabado.pt

    - Investigation / editorial (Portuguese)

  - catarina@sabado.pt

    - Catarina (editorial contact)

  - mespada@sabado.pt

    - Mes P. / editorial contact

  - anataborda@sabado.pt

    - Ana T. Borda / editorial contact

  - angelamarques@sabado.pt

    - Angela Marques / editorial contact

  - cstorres@sabado.pt

    - C. Torres / editorial contact

  - eduardodamaso@cmjornal.pt

    - Eduardo Damaso / editorial contact

----

----
