
## Set J

### nikkei.com
- help@nikkei.com
- contact@nikkei.com

### repubblica.it
- redazione@repubblica.it

### theneweuropean.co.uk
- info@theneweuropean.co.uk

## Set M

### bloomberg.com
- info@bloomberg.com

### microsoft.com
- media@microsoft.com
- press@microsoft.com

### oracle.com
- press@oracle.com

## Set N

### loreal.com
- contact@loreal.com

### bloomberg.com
- info@bloomberg.com

### microsoft.com
- media@microsoft.com
- press@microsoft.com

### tesla.com
- NA

----

----
