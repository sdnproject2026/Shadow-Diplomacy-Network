# Victim - Reporter A

## Title

Epstein Victim Speaks for the First Time: “The Masseuse Called Me to His Room and I Was Raped”

## Raw URL

https://www.sabado.pt/mundo/detalhe/vitima-de-epstein-fala-pela-primeira-vez-a-massagista-chamou-me-para-o-quarto-dele-e-fui-violada

## Author

Luana Augusto

## Text

Roza, a survivor of Jeffrey Epstein recruited as a teenager in Uzbekistan by the modeling agent Jean-Luc Brunel, said for the first time how she was abused by Epstein while he was under house arrest for abusing a minor.

She told the House Oversight Committee that she met Brunel in 2008, when she was 18, and that he promised her an extraordinary modeling career. Coming from a financially struggling family, she said she was an easy target for coercion.

Roza was later introduced to Epstein in May 2009 at his home in West Palm Beach while the financier was under house arrest. According to her account, he offered her work to help with financial problems and promised her a position at the Florida Science Foundation.

She said that one day, Epstein’s masseuse called her to his room, where she was raped by Jeffrey Epstein for the first time. Over the next three years, she said, she was raped repeatedly.

Roza said the abuse during Epstein’s house arrest made justice “impossible,” but also gave her the courage to seek help at last. She added that she was traumatized again when her name was accidentally published in Epstein files released by the Department of Justice, while “the rich and powerful remain protected.”

According to her statement, the mistake led journalists from around the world to contact her, forcing her to live in a constant state of alert. The U.S. Department of Justice said it takes victim protection very seriously and removed the files from its site where compromised victims’ names appeared, saying the errors were due to technical or human failures.

Another survivor, Maria Farmer, also testified before Democrats in a recorded statement. She said she first reported the abuse in 1996 and accused authorities of ignoring her complaint.

The statements come as the committee, which has a Republican majority, investigates Jeffrey Epstein’s crimes.

----

- investigacao@sabado.pt
    - Investigation / editorial

- catarina@sabado.pt
    - Catarina (direction secretary / editorial)

- mespada@sabado.pt
    - Mes P. (executive director / editorial)

- anataborda@sabado.pt
    - Ana Taborda (chief of newsroom / editorial)

- angelamarques@sabado.pt
    - Angela Marques (executive editor / editorial)

- cstorres@sabado.pt
    - Carlos Torres (executive editor / editorial)

- luanaaugusto@sabado.pt
    - Luana Augusto (journalist / editorial)


----

