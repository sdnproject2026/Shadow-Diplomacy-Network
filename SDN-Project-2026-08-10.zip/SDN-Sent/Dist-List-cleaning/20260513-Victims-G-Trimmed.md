# Victim - Reporter G

## Title

Epstein abused me while under house arrest, survivor tells US lawmakers

## Raw URL

https://www.bbc.com/news/articles/clypr378l2wo

## Author

Amy Walker

## Text

A survivor of Jeffrey Epstein’s abuse has described how he sexually abused her while he was under house arrest for soliciting prostitution involving a minor.

Roza, who was recruited from Uzbekistan as a teenager by Epstein associate and modelling agent Jean-Luc Brunel, spoke publicly for the first time alongside other victims during a field hearing organised by House Democrats.

She said she met Brunel in July 2009, was introduced to Epstein by Brunel, was offered work by Epstein “to help me with my financial troubles”, and that Epstein then subjected her to rape over a period of three years.

Democratic lawmaker Robert Garcia said the informal hearing was held in West Palm Beach, Florida, where Epstein’s crimes “first came to light”, and noted it was also close to Donald Trump’s Mar-a-Lago residence. It was organised by Democrats from the House Oversight Committee and local Democratic members.

The committee, which has a Republican majority, is investigating Epstein’s crimes, and Democratic members have focused on examining how the Trump administration handled the Epstein files.

While the hearing has no legal force, Democrats said it was intended to keep the case in the spotlight and highlight how Epstein and his accomplices avoided accountability and how victims were repeatedly let down by the justice system.

Roza said she was 18 when she met Brunel in 2008 and was promised a modelling career. She said that coming from a financially unstable background made her a target for coercion. She told lawmakers that by May 2009 she was in New York on a visa, and in July she met Epstein at his house in West Palm Beach while he was under house arrest.

She said Epstein offered her a role at his Florida Science Foundation, and that while she was there, his masseuse called her into his room where she was molested for the first time. She said that for the next three years she was subjected to ongoing rape.

Epstein died in a New York prison cell on 10 August 2019 while awaiting trial on sex trafficking charges. His 2008 conviction was for soliciting prostitution from a minor, for which he was registered as a sex offender.

A report released by Democratic oversight committee members on Tuesday said a plea deal negotiated by Epstein’s lawyer in 2008 allowed him to “continue his abuse and trafficking activities for almost another decade”.

Roza said the abuse Epstein carried out while under house arrest made justice feel impossible, but she eventually found the courage to seek help. She also said she was retraumatised after her name was accidentally published in Epstein files released by the US Department of Justice, while “the rich and powerful remained protected by redaction”.

She said reporters from around the world now contact her and she cannot live without constantly looking over her shoulder, and she fears the long-term impact of the “mistake” on her life.

The DOJ has said it “takes victim protection very seriously” and that it removed some Epstein-related files from its website after victims said their identities had been compromised due to flawed redactions. The DOJ said the mistakes resulted from “technical or human error”.

Another Epstein survivor, Maria Farmer, also gave evidence to the lawmakers by recorded message, saying she first reported Epstein’s abuse in 1996 and accusing law enforcement agencies of repeatedly failing to act. She said the government “needs to start telling the truth”.

----

- yourvoice@bbc.co.uk

- newswatch@bbc.co.uk

- bbcnewsline@bbc.co.uk

----

