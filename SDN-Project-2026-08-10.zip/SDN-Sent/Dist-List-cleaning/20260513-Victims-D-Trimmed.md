# Victim - Reporter D

## Title

First Epstein victim speaks publicly, alleging the sex offender harassed her for three years

## Raw URL

https://telex.hu/kulfold/2026/05/13/jeffrey-epstein-aldozat-amerika-demokrata-part-meghallgatas

## Author

Flachner Balázs

## Text

Roza, an Epstein victim, spoke publicly for the first time during a Wednesday hearing organized by the U.S. Democratic Party. She said Epstein sexually abused her for three years. She testified that she first met Epstein in 2009, when he was under house arrest after being convicted a year earlier for sex crimes against minors.

Roza also said that after the U.S. Department of Justice released the Epstein files, her name was not redacted, which she said added another layer of trauma.

The Uzbek-born Roza testified that she was 18 when she met Epstein in 2008 through the model recruiter Jean-Luc Brunelle, who promised her a way into a modeling career. She said that because she came from a difficult background, she was easier to target. She said that by May 2009 she had traveled to New York and that in July she met Epstein at his home.

She said Epstein then offered her a job at his scientific foundation. She also described an incident where his masseur brought her to Epstein, where she said he first harassed her. According to Roza, Epstein then repeatedly raped her over the next three years. She said she long believed it was impossible to get justice because Epstein’s abuse occurred while he was under house arrest, but that she eventually found the courage to seek help.

Roza said the files ultimately published by the Department of Justice did not redact her name, which she believes could have “unforeseeable consequences” for the rest of her life.

The hearing where Roza spoke was not a formal legal proceeding. It was organized by Democratic members of the House Oversight Committee together with local Democrats, and it was held deliberately in West Palm Beach, Florida, which the organizers described as Epstein’s main location for his crimes. The organizers said the goal was to keep the issue in view rather than produce legal consequences.

----

- ugyelet@telex.hu 
    - Editorial / news duty

- press@telex.hu 
    - Press / media inquiries

- tamogatas@telex.hu 
    - Support / help

- telexhu@protonmail.com 
    - Confidential info mailbox

----
