# Given 

invalid email addresses, prefixed with \^ char, and sets of comma separated email address lists, respond retain structure and formatting, remove each invalid email address from a comma separated email address list and create an invalid email address list, prefixed with ^ char, below the appropriate ## Set... header and above the sets of comma separated email address lists. add ### Count NN - after each comma separated email address lists, include invalid and comma separated email addresses in count total.

-----

### Invalid Email Addresses

-----

^ tips@washingtonpost.com

^ press@cnn.com

^ news@deadline.com

^ press@deadline.com

-----

### Comma Separated Email Address Lists

-----

## Set G

^ support@pressreader.io

```
tips@thr.com, news@metro.co.uk, cnbctips@nbcuni.com, tips@nytimes.com, tips@nbcuni.com, press@google.com, news@skynews.com, info@ap.org, news.tips@abc.com, letters@theatlantic.com, tips@axios.com, haveyoursay@bbc.co.uk, tips@billboard.com, feedback@boston.com, news@bostonherald.com, letters@csmonitor.com, tips@thedailybeast.com, tips@cnn.com, press@cnn.com, tips@washingtonpost.com, news@deadline.com, press@deadline.com, viewer@c-span.org, events@c-span.org, tips@chicagotribune.com
```

-----

-----

